/*
  General Code to handle the member data, such as
  the server, username, and password, default activity,
  etc.
  
  Handles requests for those resources as well as syncing
  and updating them on GUI changes.
*/

// Constants
var TIMEOUT_TIME  = 10*1000;
var SORT_ALPHA    = 0;
var SORT_RECENT   = 1;
var SORT_PRIORITY = 2;


// Globals
var server, username, password, sort, max_num = null;
var httpFeedRequest, activityListRequest, createRequest = null;
var todoFeedUrl = 'service/atom2/todos?sortfields=lastmod&sortorder=1&completedTodos=yes&count=100'
var todoForActivityUrl = 'service/atom2/activity?ps=100&nodetype=todo&activityUuid=';
var activityListUrl = 'service/atom2/activities?ps=50';
var activityUrl = 'service/html/mainpage#activitypage,';
var activitiesList  = [];
var authError = false;
var todoHash = { keys: [] };
var completedTodoHash = { keys: [] };
var currentTodoListReqNum = 0;
var currentActivityListReqNum = 0;
var selectedActivity = null;
var okayToCache = false;
var no_connection = false;
var priorityHash = {};


/************ MEMBER DATA FUNCTIONS ************/

//
// Function: refreshSettings()
// Reloads all the settings from the back
// and returns true if there was a change in
// either the server, username, or password
//
function refreshSettings() {
    
    // Check for a modification in server settings
    var change = false;
    if ( username != getUsername() ||
         password != getPassword() ||
         server   != getServer()   ||
         sort     != getSort()     ||
         max_num  != getMax() ) {
         change = true;
    }

    // Update the old values
    username = getUsername();
    password = getPassword();
    server = getServer();
    max_num = getMax();
    sort = getSort();

    // If there was a change
    return change;
}


// Getters
function getMax() { return document.getElementById('sliderCompleted').value; }
function getUsername() { return document.getElementById('textLoginName').value; }
function getPassword() { return document.getElementById('textPassword').value; }
function getSort() {
	if ( document.getElementById('radio_sort1').checked ) {
		return SORT_ALPHA;
	} else if ( document.getElementById('radio_sort2').checked ) {
		return SORT_RECENT;
	} else {
		return SORT_PRIORITY;
	}
}
function getServer() {
    var textServer = document.getElementById('textServer').value;
    if (textServer.charAt(textServer.length-1) != '/') { textServer += '/'; }
    return textServer;
}
        

/************ AJAX FUNCTIONS ************/

//
// Function: buildRequest()
// Creates and initializes settings for a request
//
function buildRequest(url) {
	var req = new XMLHttpRequest();
	req.overrideMimeType("text/xml");
    req.open("GET", server + url);
    var loginString = Base64.encode(username + ':' + password);
    req.setRequestHeader("Authorization", 'Basic ' + loginString);
	req.setRequestHeader("Cache-Control", "no-cache");
	return req;
}


//
// Function: updateTodoList()
// Starts loading the feed source.
// processFeedDocument() will be called when it finishes loading.
//
function updateTodoList() {

    // Clear the list
    todoHash = { keys: [] };
    completedTodoHash = { keys: [] };

	// Abort any pending request before starting a new one
	if (httpFeedRequest != null) {
		httpFeedRequest.abort();
		httpFeedRequest = null;
	}
	
    // -----
	// New Request (build the URL based on the constant)
    // TODO: If it is no longer a constant, but a preference update here too!
    // -----
    var url = '';
    if ( allActivitesSelected ) {
        url = todoFeedUrl;
        okayToCache = true;
    } else {
        url = todoForActivityUrl + selectedActivity.uuid;
        okayToCache = false;
    }
    
    // The Request
    httpFeedRequest = buildRequest(url);
    httpFeedRequest.onload = function (xml) {

		// Debug - Server Response
		alert( "TODO LIST RESPONSE: " + httpFeedRequest.status );

		// Not successful
		if ( httpFeedRequest.status != 200 ) {
            alert( "Error :(" );
			return;
		}
        
        // Connection is good
        no_connection = false;

		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( httpFeedRequest.responseXML ) {
			feedRootElement = httpFeedRequest.responseXML.documentElement;
		}
                		
		// Process the Feed
		parseTodoFeed(feedRootElement);
        lastLoadTimestamp = new Date();
		drawTodoList();
        
        // Write to the cache
        if ( okayToCache ) {
            var str = httpFeedRequest.responseText;
            httpFeedRequest = null;
            cacheIfNeeded();
        } else {
            httpFeedRequest = null;
        }

	}
    
	// Show loading state and send the request
    showLoadingImage();
    var temp = ++currentTodoListReqNum;
	httpFeedRequest.send(null);
    setTimeout( function(){timeoutForTodoList(temp)}, TIMEOUT_TIME );	
}


//
// Function: updateActivitiesList
// Fetch a list of all the activities this user has write
// permissions to.
//
function updateActivitiesList() {

	// Abort any pending request before starting a new one
	if (activityListRequest != null) {
			activityListRequest.abort();
			activityListRequest = null;
	}

	// The New Request
	activityListRequest = buildRequest(activityListUrl);
	activityListRequest.onload = function (xml) {
	
		// Debug - Server Response
		alert( "ACTIVITY LIST RESPONSE: " + activityListRequest.status );
	
		// Not successful
		if ( activityListRequest.status != 200 ) {
			alert("SERVER FAILURE");
			return;
		}

		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( activityListRequest.responseXML ) {
			feedRootElement = activityListRequest.responseXML.documentElement;
		}

		// Destory the XMLHttpRequest, Process, and Update
		activityListRequest = null;
		activitiesList = parseActivitiesFeed(feedRootElement);
        
        // Sort and update
        if ( sort == SORT_ALPHA ) {
            activitiesList.sort(function (a,b) {
                atitle = a.title;
                btitle = b.title;
                if ( atitle < btitle )
                    return -1;
                if ( atitle > btitle )
                    return 1;
                return 0;
            });
        } else if ( sort == SORT_PRIORITY ) {
			activitiesList.sort(function (a,b) {
				apriority = a.priority;
				bpriority = b.priority;
				if ( apriority < bpriority )
					return 1;
				if ( apriority > bpriority )
					return -1;
				return 0;
			});
		}
		
        updateActivitySelectLists();

	}

	// Send
	activityListRequest.send(null);
    setTimeout( function(){timeoutForTodoList(++currentActivityListReqNum)}, TIMEOUT_TIME );
}

/************ GUI MODIFYING FUNCTIONS ************/

//
// Function: updateActivitySelectLists
// Updates the back's activity list, keeping the default
// based on the <id> and then updates the create todo's
// select list.
//
function updateActivitySelectLists() {

	// For a priority sort
	var lastPriority = 1e5;
	var optgrp = null;
    
    // Recreate the back's select list and options
    var select = document.getElementById('activitySelectPopup');
    select.options.length = 0;
	optgrp = select;
    addOption(select, 'All Todos', -1);
    for (var j = 0; j < activitiesList.length; j++) {
		var activity = activitiesList[j];
		
		// For priority sort
		if ( sort == SORT_PRIORITY ) {
			
			// Open an optgrp
			if ( lastPriority > activity.priority ) {
				lastPriority = activity.priority;
				optgrp = openOptGroup( select, priorityHash[activity.priority] );
			}
			
			var selected = (selectedActivity && activity.id == selectedActivity.id) ? true : false;
			addOption(optgrp, activity.title, activity.id, selected);
			
		} else {
			var selected = (selectedActivity && activity.id == selectedActivity.id) ? true : false;
			addOption(select, activity.title, activity.id, selected);
		}
    }

    // Enable the drop down 'activities' menu on the front
    // Lower the flag for the hover states
    loading = false;
    enableDropDown();
}


//
// Function: enableDropDown()
// Enable the drop down on the front and change the style
//
function enableDropDown() {
    var dropDownMenu = document.getElementById( 'dropDownOverlay' );
    var dropDownPopup = document.getElementById( 'activitySelectPopup' );
    dropDownMenu.style.cursor   = 'pointer';
    dropDownPopup.style.cursor  = 'pointer';
    dropDownPopup.style.display = 'inline';
    dropDownMenu.style.opacity  = 1;
}


//
// Function: disableDropDown() 
// Disable the drop down on the front and change the style
//
function disableDropDown() {
    var dropDownMenu = document.getElementById( 'dropDownOverlay' );
    var dropDownPopup = document.getElementById( 'activitySelectPopup' );
    dropDownMenu.style.cursor   = 'default';
    dropDownPopup.style.cursor  = 'default';
    dropDownPopup.style.display = 'none';
    dropDownMenu.style.opacity  = .5; 
}


//
// Function: changeDropDown()
// Action for switching activities on the front
//
function changeDropDown() {

    // Change the title
    var index = document.getElementById('activitySelectPopup').selectedIndex-1;
    loading = true;

    if ( index < 0 ) {
    
        // Disable the addnew button and set the title
        disableAddNew();
        document.getElementById( 'title' ).innerHTML = 'All Todos';
        selectedActivity = null;
        
        // Close the panel
        if ( slideOpen ) closeAdvanced();
        
    } else {

        // Enable the addnew button and set the title
        enableAddNew();
        selectedActivity = activitiesList[index];
        document.getElementById( 'title' ).innerHTML = selectedActivity.title;

    }

    // Populate the second level lists and the Todo list based on the new selection
    updateTodoList();
    postActivitySelected();
    loading = false;
}


//
// Function: indexOfActivityWithId(id)
// Searches the activity list for the activity with
// the given id.  Returns the index if found
// -1 otherwise
//
function indexOfActivityWithId(id) {
    for (var i = 0; i < activitiesList.length; i++) {
        var activity = activitiesList[i];
        if (activity.id == id || activity.id.match(id) ) {
            return i;
        }
    }
    return -1;
}


//
// Function: addOption(select, value, id)
// Add an option to a select
//
function addOption(select, value, id, selected) {
    var option = document.createElement('option');
    option.innerHTML = value;
    option.value = id;
    if (selected) { option.selected="true"; }
    select.appendChild(option);
}

//
// Function: openOptGroup(select, str)
// Add an option group to a select
//
function openOptGroup(select, str) {
	var optgrp = document.createElement('optgroup');
	optgrp.label = str;
	select.appendChild(optgrp);
	return optgrp;
}


/************ UTILITY FUNCTIONS ************/

//
// Function: parseTodoFeed(atom)
// Parse an Atom feed.
//
// atom: Atom feed as an XML document.
//
// Returns the parsed results array.
//
function parseTodoFeed(atom) {
	
	// Put the results into the currentTodoHash
	for (var item = atom.firstChild; item != null; item = item.nextSibling) {
		if (item.nodeName == "entry") {

			// Get the ID, Updated, Name, and Content
            var todo = parseTodo(item);
            
            // Add it to the Hash if it doesn't already exist but
            // also update if it was in the hash and this version
            // is more recent (helps prevent bad updates).
            var id = todo.id;
            var hashToAddTo = (todo.completed) ? completedTodoHash : todoHash;
            if ( hashToAddTo[id] && todo.date > hashToAddTo[id].date ) {
                hashToAddTo[id] = todo;
            } else if ( !hashToAddTo[id] ) {
                hashToAddTo[id] = todo;
                hashToAddTo.keys.push(id);
            }

		}
	}
    
    // Sort
    sortTodoList();
}


//
// Function: sortTodoList
// Sorts the todo list
// Finally sort the list, and truncate to MAX_NUM_OF_TODOS elements
//
function sortTodoList() {
    var hashes = [todoHash, completedTodoHash];
    for (var i=0; i<hashes.length; i++) {

        // Fast sorting algorithm
        var hash = hashes[i];
        hash.keys.sort( function (a,b) {
            var adate = hash[a].date;
            var bdate = hash[b].date;
            if ( adate > bdate )
                return -1;
            if ( adate < bdate )
                return 1;
            return 0;
        });

        // Delete extras (if there are any)
        var toDelete = hash.keys.splice(max_num);
        toDelete.forEach( function(a) { delete hash[a]; } );

    }
}

//
// Function: parseTodo(entry)
// Parses a single Todo from an Atom Entry
//
function parseTodo(entry) {

    // Get the ID, Updated, Name, and Content
    var id = atomTextToHTML(findChild(entry, "id")).innerText;
    var updated = parseAtomDate(atomTextToHTML(findChild(entry, "updated")).innerText);
    var title = atomTextToHTML(findChild(entry, "title"));
    title = title ? title.innerText : "No Title";
    var content = atomTextToHTML(findChild(entry, "content"));
    content = content ? content.innerHTML : "No Description";
    
    // Activity ID
    var activityId = atomTextToHTML(findChild(entry, "activity")).innerText;
    
    // Optional SNX Fields
    var duedate = atomTextToHTML(findChild(entry, "duedate"));
    duedate = duedate ? parseAtomDate(duedate.innerText) : undefined;			
    var assignedto = atomTextToHTML(findChild(entry, "assignedto"));
    assignedto = assignedto ? assignedto.innerText : undefined;
    
    // Completed yes/no
    var completed = !!findChildAttrVal(entry, "category", ["scheme", "term"], [SCHEME_COMPLETED, TERM_COMPLETED]);
    
    // Edit Link
    var editLink = findChildAttrVal(entry, 'link', ['rel'], ['edit']);
    editLink = editLink ? editLink.getAttribute('href') : null;

    // The todo
    return {
        id: id,
        date: updated,
        title: title,
        content: content,
        duedate: duedate,
        assignedto: assignedto,
        completed: completed,
        edit: editLink,
        xml: entry,
        activityId: activityId
    }

}


//
// Function: parseActivitiesFeed(atom)
// Parse an Atom feed.
//
// atom: Atom feed as an XML document.
//
// Returns the parsed results array.
//
function parseActivitiesFeed(atom) {
	
	// Put the results into a nice Object Array
	var results = new Array;
	for (var item = atom.firstChild; item != null; item = item.nextSibling) {
		if (item.nodeName == "entry") {

			// See if they have permission to add TODOs
			var hasPermission = atomTextToHTML(findChild(item, 'permissions'));
			hasPermission = hasPermission ? !!hasPermission.innerText.match(/\bcreate_entries\b/) : false;
			
			// Only get more information if the user has permission
			if ( hasPermission ) {
				var title = atomTextToHTML(findChild(item, 'title')).innerHTML;
				var id = atomTextToHTML(findChild(item, 'id')).innerText;
                var uuid = atomTextToHTML(findChild(item, 'activity', NAMESPACE_SNX)).innerText;
                var editLink = findChildAttrVal(item, 'link', ['rel'], ['edit']);
                editLink = editLink ? editLink.getAttribute('href') : null;
                var selfLink = findChildAttrVal(item, 'link', ['rel'], ['self']);
                selfLink = selfLink ? selfLink.getAttribute('href') : null;

				// -----
				// New - Joe - Wednesday July 9, 2008
				// -----
				var priority = findChildAttrVal(item, 'category', ['scheme'], [SCHEME_PRIORITY]);
				var priorityLabel = priority ? priority.getAttribute('label') : 'Normal';
				priority = priority ? priority.getAttribute('term') : 1;
				priorityHash[priority] = priorityLabel;
				                
                results.push({
                    id:id,
                    title:title,
                    selfLink:selfLink,
                    href:editLink,
                    uuid:uuid,
					priority: priority
                });
                
			}
		}
	}

	return results;

}


// drawTodoList
function drawTodoList() {

    // -------
    // Build the GUI as a string
    // TODO: Convert to creating elements DOM style
    // TODO: Once DOM, instead of recreating the entire list
    //       only add/remove "rows" based on updates and
    //       checked off rows that are saved
    // -------
    
    /*
    <div class="row">
      <!-- Make this checked if it was already completed with checked="checked" -->
      <input type="checkbox" onchange="doCheckCallback('someLongId', this);" />
      <p onclick="doCallback('someLongId');" title="Due in X days">Title Goes Here</p>
    </div>
    */
    
    // Build each "row"
    var str = '';
    var hashes = [todoHash, completedTodoHash];
    for (var j=0; j<hashes.length; j++) {
        var hash = hashes[j];
        for (var i=0; i<hash.keys.length; i++) {
            var key = hash.keys[i];
            var todo = hash[key];
            var checked = (todo.completed) ? 'checked="checked" ' : '';
            var disabled = (no_connection) ? 'disabled="disabled" ' : '';
            var title = (todo.duedate) ? dateToString(todo.duedate) : 'No Duedate';
            str += '<div class="row">';
            str += '  <input type="checkbox" onchange="doCheckCallback(\'' + key + '\', this);" ' + checked + disabled + '/>';
            str += '  <p onclick="doCallback(\'' + key + '\');" title="' + title + '">' + trim(hash[key].title) + '</p>';
            str += '</div>';
        }
    }
  
    // Display and refresh the scrollbar
    document.getElementById("content").innerHTML = str;
    refreshScrollArea();
    
    // Show the user that there are no TOEDOWSSZS
    if( (todoHash.keys.length == 0) && (completedTodoHash.keys.length == 0) ) 
        showWarningMessage("There are no To-Do's for this Activity.", 82, 20);
}


//
// Function: getTodoById(id)
// Gets the todo, no matter the hash
//
function getTodoById(id) {
    return (todoHash[id]) ? todoHash[id] : completedTodoHash[id];
}


//
// Function: daCallback(key)
// Calls Backs
//
function doCallback(key) {

    var todo = getTodoById(key);
    
    // Set all the edit overlay properties
    
    // TITLE
    document.getElementById( 'editName' ).innerHTML = todo.title;
    
    // ACTIVITY
    var activityElement = document.getElementById( 'editActivity' );
    var index = indexOfActivityWithId(todo.activityId);
    activityElement.innerHTML = (index != -1) ? activitiesList[index].title : 'Unknown Activity';
    activityElement.onclick = function() { widget.openURL( server + activityUrl + todo.activityId ); };
    

    // DUEDATE
    var dateElement = document.getElementById( 'editDate');
    dateElement.innerHTML = (todo.duedate != undefined) ? dateToShortString(todo.duedate) : 'None';
    
    // SECTION
    var sectionElement = document.getElementById( 'editSection' );
    sectionElement.innerHTML = 'Section goes here';
    
    // ASSIGNEDTO
    var assignedElement = document.getElementById( 'editAssigned' )
    if ( todo.assignedto != undefined ) {
        var member = getFromList(memberList, function(a) { return a.email == todo.assignedto });
        assignedElement.innerHTML = (member) ? member.name : todo.assignedto;
    } else {
        assignedElement.innerHTML = 'Everyone';
    }
    
    // SUMMARY
    var summary = todo.content.length == 0 ? "None" : todo.content;
    document.getElementById( 'editSummary' ).innerHTML  = summary;
        
    // Show the edit overlay
    showOverlay( 'edit' );
}


//
// Function: doCheckCallback
// Blkasjdfla
//
function doCheckCallback(key, input) {
    var todo = getTodoById(key);
    var checked = input.checked;
    input.disabled = true;
    toggleTodoEntry(todo);
}


//
// Function: showLoadingImage()
// Shows the loading image
//
function showLoadingImage() {

    // Raise flag for drop down on the front (disable)
    loading = true;
    
    // -----
    // TODO: Make this better in every way possible
    // -----
    str  = '<div style="width:285px;margin-top:85px;text-align:center;">';
    str += '  <img src="Images/loadImageBig.gif" alt="Loading..." />';
    str += '</div>';
    document.getElementById('content').innerHTML = str;

}

//
// Function: showWarningMessage(msg, top, left)
// Shows a warning message.  Top and left are hardcoded
// values needed to center the text.
// Example: showWarningMessage('Doh!', 100, 100);
//
function showWarningMessage(msg, top, left) {
    var style = "font-size:1.1em;text-align:center;";
    style += "margin-top:"+top+"px;margin-left:"+left+"px;";
    var div = '<div style="' + style + '">' + msg + '</div>';
    document.getElementById("content").innerHTML = div;
}


//
// Function: timeoutForTodoList(reqNum)
// Timesout the TodoList request with the
// given request number
//
function timeoutForTodoList(reqNum) {
    if ( httpFeedRequest && currentTodoListReqNum == reqNum ) {
        alert('ABORTING TODO LIST');
        httpFeedRequest.abort();
        httpFeedRequest = null;
        no_connection = true;
        
        // Pull from cache or warning message if no cache
        if ( cache.exists() ) {
            alert('PULLING FROM CACHE - NEEDS SOME INDICATOR HERE');
            fetch_from_cache();            
        } else {
            showWarningMessage("Connection Timed Out!<br />Please Check Your Preferences", 82, 20);
        }
    }
}


//
// Function: timeoutForActivityList(reqNum)
// Timesout the TodoList request with the
// given request number
//
function timeoutForActivityList(reqNum) {
    if ( activityListRequest && currentActivityListReqNum == reqNum ) {
        alert('ABORTING ACTIVITY LIST');
        activityListRequest.abort();
        activityListRequest = null;
    }
}
