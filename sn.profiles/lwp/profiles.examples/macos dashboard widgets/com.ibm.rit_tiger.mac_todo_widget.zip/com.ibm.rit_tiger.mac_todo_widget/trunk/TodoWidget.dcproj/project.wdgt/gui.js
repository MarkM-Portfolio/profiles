// -----------------------
//       Overlays
// -----------------------


//
// Function: showOverlay
// Show the appropriate overlay
//
function showOverlay( overlay ) {
	
	function wau_helper(txt, ptr, clr, fade) {
		wauOverlay = true;
		var currentOpacity = nvl(document.getElementById( 'boundingBox' ).style.opacity, 0);
		document.getElementById( 'alertText' ).innerHTML = txt;
		document.getElementById( 'boundingBox' ).style.cursor = ptr;
		document.getElementById( 'boundingBox' ).style.backgroundColor = clr;
		opacity( 'boundingBox', currentOpacity, 100, 3000, 0.5 );
		if ( fade ) { setTimeout( 'opacity(\'boundingBox\',100,0,2000,0.65)', 4000 ); }
	}
	
	switch( overlay ) {
		case 'quickAdd':
			document.getElementById("addNew").src = ADD_NEW_PRESSED;
			document.getElementById( 'quickTodoName' ).focus();
			opacity( 'frontOverlay', 0, 100, 800, 0.16 );
			break;
			
		case 'addNew':
			opacity( 'todoCreated', 0, 100, 1500, 0.5 );
			opacity( 'todoCreatedName', 0, 100, 1500, 0.5 );
			setTimeout( function() {
                opacity( 'todoCreated', 100, 0, 2000, 0.65 );
                opacity( 'todoCreatedName', 100, 0, 2000, 0.65 );
            }, 3000);
			setTimeout( hide('todoCreated'), 5000 );
			setTimeout( hide('todoCreatedName'), 5000 );
			break;

		case 'edit':
			opacity( 'frontEditOverlay', 0, 100, 800, 0.35 );
			break;

		case 'wau_error_overlay':
			wau_helper(WAU_ERROR, 'default', 'rgba(255, 122, 124, 0.427451)', true);
			break;
			
		case 'wau_regular_overlay':
			wau_helper(WAU_REG, 'default', 'rgba(146, 172, 255, 0.427451)', true);
			break;
			
		case 'wau_new_overlay':
			wau_helper(WAU_NEW, 'pointer', 'rgba(142, 255, 164, 0.427451)', false);
			break;
			
		default:
			alert( 'Unknown overlay' );
			break;
	}
    
}
	

//
// Function: hideOverlay
// Hide a variety of overlays
//
function hideOverlay( overlay ) {
	
	switch( overlay ) {
		case 'quickAdd':
			document.getElementById("addNew").src = ADD_NEW_ENABLED;
			opacity( 'frontOverlay', 100, 0, 800, 0.2 );
			setTimeout( hide('frontOverlay'), 400 );
			break;
			
		case 'edit':
			opacity( 'frontEditOverlay', 100, 0, 800, 0.18 );
			setTimeout( hide('frontEditOverlay'), 400);
			break;

		case 'wau':
			setTimeout( hide('boundingBox'), 6000 );
			setTimeout( 'document.getElementById( \'updateButton\' ).style.opacity = 1.0', 6000 );
			setTimeout( 'wauOverlay = false;', 6000 );
			break;
			
		case 'wau_new':
			wayOverlay = false;
			opacity( 'boundingBox', 100, 0, 2000, 0.65 );
			break;
			
		default:
			alert( 'Unknown overlay' );
			break;
	}
}


//
// Function: hide(id)
// Sets the display to none of the element with the given id
//
function hide(id) {
	document.getElementById(id).style.display = 'none';
}


function editOverlayClickHandler(event) {
	hideOverlay( 'edit' );
}


// -----------------------
//    Refresh Handler
// -----------------------


function hoverRefresh(event) {
	document.getElementById( 'refresh' ).src = REFRESH_HOVER;
}

function regularRefresh(event) {
	document.getElementById( 'refresh' ).src = REFRESH_REGULAR;
}

function clickRefresh(event) {
	refresh();
}

function refresh() {
	updateActivitiesList();
	updateTodoList();
}


// -----------------------
//    Add New Icon (+)
// -----------------------


//
// Function: showHoverIcon()
// Display the 'addnew' hover image 
//
function showHoverIcon() {
	if ( !allActivitesSelected && !isPressed ) document.getElementById("addNew").src = ADD_NEW_ENABLED_HOVER;
}


//
// Function: hideHoverIcon()
// Hide the 'addnew' hover image
//
function hideHoverIcon() {
 if ( !allActivitesSelected && !isPressed ) document.getElementById("addNew").src = ADD_NEW_ENABLED;
}


//
// Function: showPressedIcon()
// Show the 'addnew' pressed image
//
function showPressedIcon() {
	if ( !allActivitesSelected ) {
		if ( !isPressed ) {
			showOverlay( 'quickAdd' );
            document.getElementById( 'quickTodoName' ).focus();
		} else {
            closeAdvanced();
		}
		// Set the 'plus' icon to be pressed, or reset it
		document.getElementById( 'addNew' ).src = ADD_NEW_ENABLED_HOVER;
	}
}

//
// Function: closeAdvanced
// Closes the advanced slide out tray
//
function closeAdvanced() {
    slide( 'newTodoPanel', this );
    isPressed = false;
    slideOpen = !slideOpen;
}



//
// Function: enableAddNew()
// Enable the add new button when the selection is not 'all activities'
//
function enableAddNew() {
	allActivitesSelected = false;
	
	var element = document.getElementById( 'addNew' );
	element.src = ADD_NEW_ENABLED;
	element.style.cursor = 'pointer';
	element.style.opacity = 1;
}


//
// Function: disableAddNew()
// Disable the add new button when 'all activities' selected
//
function disableAddNew() {
	allActivitesSelected = true;

	var element = document.getElementById( 'addNew' );
	element.src = ADD_NEW_DISABLED;
	element.style.cursor = 'default';
	element.style.opacity = 0.65;
}


// -----------------------
//   Activity Popup List
// -----------------------

function showActivityPopup() {
	if ( !loading ) document.getElementById( 'dropDownOverlay' ).src = DROPDOWN_HOVER;
}

function hideActivityPopup() {
	if ( !loading ) document.getElementById( 'dropDownOverlay' ).src = DROPDOWN_REGULAR;
}


// -----------------------
//     Create Button
// -----------------------


function showHoverCreate() {
	if ( enableCreate ) document.getElementById( 'saveTodo' ).style.backgroundColor = "#85BFFF";
}

function hideHoverCreate() {
	if ( enableCreate ) document.getElementById( 'saveTodo' ).style.backgroundColor = "#608EED";
}


// ----------------------------------
//   Quick Cancel / Create Buttons
// ----------------------------------
//
// These functions just deal with mouse actions with the create / cancel button
// when a user quickly adds a todo via the simple interface.
//

function showQuickCancel() {
	document.getElementById( 'quickCancel' ).src = QUICK_CANCEL_HOVER;
}

function clickQuickCancel() {
	hideOverlay( 'quickAdd' );
}

function hideQuickCancel() {
	document.getElementById( 'quickCancel' ).src = QUICK_CANCEL;
}

function showQuickCreate() {
	if ( enableCreate ) document.getElementById( 'quickCreate' ).src = QUICK_CREATE_HOVER;
}

function hideQuickCreate() {
	if ( enableCreate ) document.getElementById( 'quickCreate' ).src = QUICK_CREATE;
}

function clickQuickCreate() {
	if ( enableCreate ) {
		var todoElement = document.getElementById( 'todoCreatedName' );

		// Set the display name for the overlay
		todoElement.innerHTML = document.getElementById( 'textName' ).value;
		
		// Display overlay and submit the entry
		submitTodoEntry();
	 
		// Reset the name of the todo
		var todoName = document.getElementById( 'quickTodoName' );
		todoName.value = "";
		todoName.focus();
	}
}


// ----------------------------------
//   Quick Create Synchronization
// ----------------------------------

//
// Function: keyNameHandler
// Key up handler for the quick-add panel; sets the value of the other name field
//
function keyNameHandler() {
	document.getElementById( 'textName' ).value = document.getElementById( 'quickTodoName' ).value;
	nameTextHandler();
}


// ------------------
//       Slider
// ------------------


//
// Function: changeSlider
// Update the back counter when the slider changes
//
function changeSlider() {
	document.getElementById( 'completedNumber' ).innerHTML = document.getElementById( 'sliderCompleted' ).value;
}


// ------------------
//      Advanced
// ------------------


//
// Function: showAdvancedOptions
// Fade away the simple options and slide out the advanced tray
//
function showAdvancedOptions(event) {
	// Hide the simple pane
	hideOverlay( 'quickAdd' );
	
	// Animate the side panel
	slide('newTodoPanel', this);
	
	// Set the addnew icon to pressed
	document.getElementById( 'addNew' ).src = ADD_NEW_PRESSED;
	isPressed = true;
	slideOpen = true;
}


// ------------------
//    Date Popup
// ------------------


//
// Function: showDatePicker()
// Pop up a widget to pick a date for the todo
//
function showDatePicker() {
	displayDatePicker( 'textDate' );
}
