// -----------------------
//        Globals
// -----------------------
var WIDGET_VERSION = 1.2;
var DO_NOT_RELOAD_TIME_SPAN = 1000*60*5;


// -----------------------
//          Images
// -----------------------
var ADD_NEW_ENABLED       = 'Images/addnewenabled.png';
var ADD_NEW_ENABLED_HOVER = 'Images/addnewenabledhover.png';
var ADD_NEW_PRESSED       = 'Images/addnewpressed.png';
var ADD_NEW_DISABLED      = 'Images/addnewdisabled.png';
var DROPDOWN_HOVER        = 'Images/dropdownhover.gif';
var DROPDOWN_REGULAR      = 'Images/dropdown.gif'; 
var QUICK_CREATE          = 'Images/quickcreate.png';
var QUICK_CREATE_HOVER    = 'Images/quickcreatehover.png';
var QUICK_CANCEL          = 'Images/quickcancel.png';
var QUICK_CANCEL_HOVER    = 'Images/quickcancelhover.png';
var REFRESH_HOVER         = 'Images/refresh.png';
var REFRESH_REGULAR       = 'Images/refreshreg.png';


// -----------------------
// Status Update Messages
// -----------------------
var WAU_ERROR = 'Update error. Check the server path or connection.';
var WAU_REG	  = 'You already have the latest version!';
var WAU_NEW	  = 'New update available! Click to download.';


// -----------------------
//         States
// -----------------------
var loading              = true;
var wasOpen              = false;
var slideOpen            = false;
var isPressed            = false;
var wauOverlay           = false;
var enableCreate         = false;
var wau_updateAvailable  = false;
var allActivitesSelected = true;
var lastLoadTimestamp    = null;
var wau_updateObject     = null;


// -----------------------
//   Global Key Listener
// -----------------------


//
// Function: globalkey
// Add a global key handler for showing / hiding displays
//
function globalKey(e) {
	var key = e ? e.which : window.event.keyCode;

	switch ( key ) {
		case 27:
			// If the user hits esc hide the overlay 
			if ( key == 27 ) {
				if	( document.getElementById( 'frontEditOverlay' ).style.display == 'inline' ) {
					hideOverlay( 'edit' );
				} else if ( document.getElementById( 'frontOverlay' ).style.display == 'inline' ) {
					hideOverlay( 'quickAdd' );
				}
			}
			break;
		case 13:
			// If the user hits return when the addQuick is open, then create the todo
			if ( document.getElementById( 'frontOverlay' ).style.display == 'inline' ) clickQuickCreate()
			break;
	}
}

// Setup global key handler
document.onkeypress = globalKey;
if (document.layers) document.captureEvents(Event.KEYPRESS);


// -------------------------------
//   Validation and Form Handler
// -------------------------------


//
// Function: nameTextHandler
// Enable the create button if there is a name for it
//
function nameTextHandler() {
	var activityId = (selectedActivity) ? selectedActivity.id : null;
	if( document.getElementById( 'textName' ).value != "" && (activityId != -1) ) {
		enableCreateButton();
	} else {
		disableCreateButton();
	}
}


//
// Function: isDateValid()
// Returns true if valid, false otherwise
//
function isDateValid() {
	var date = trim(document.getElementById('textDate').value);
	return ( date == '' || date.match(/^\d{2}(\D)\d{2}\1\d{4}$/) );
}


//
// Function checkDate(event)
// Updates the border of the date input in the
// case of invalid input
//
function checkDate(event) {
	var date = document.getElementById('textDate');
	if ( isDateValid() ) {
		date.style.border = "1px solid lightGray";
		enableCreateButton();
	} else {
		date.style.border = "1px solid red";
		disableCreateButton();
	}
}


//
// Function: datePickerClosed(field)
// Callback for the calendar.js datepicker
//
function datePickerClosed(field) {
	checkDate(null);
}


// -----------------------------------
//   Enable / Disable Create Button
// -----------------------------------


//
// Function: okayToEnableCreateButton()
// Returns true if its okay to enable the create button
// false otherwise
//
function okayToEnableCreateButton() {
	if ( !selectedActivity || !selectedActivity.id )
		return false;
	if ( trim(document.getElementById( 'textName' ).value) == '' )
		return false; 
	if ( !isDateValid() )
		return false;
	
	return true;
}
	

//
// Function: enableCreateButton
// Set the style properties for the create button and enable it
//
function enableCreateButton() {
	if ( okayToEnableCreateButton() ) {
		var buttonElement = document.getElementById( 'saveTodo' );
		buttonElement.style.opacity = 1.0;
		buttonElement.style.cursor	= 'pointer';
		enableCreate = true;
	
		var createElement = document.getElementById( 'quickCreate' );
		createElement.style.opacity = 1.0;
		createElement.style.cursor	= 'pointer';
	}
}


//
// Function: disableCreateButton
// Set the style properties for the create button and disable it
//
function disableCreateButton() {
	var buttonElement = document.getElementById( 'saveTodo' );
	buttonElement.style.opacity = 0.3;
	buttonElement.style.cursor	= 'default';
	enableCreate = false;
	
	var createElement = document.getElementById( 'quickCreate' );
	createElement.style.opacity = 0.5;
	createElement.style.cursor	= 'default';
}


//
// Function: clearButtonAction
// Clears all the todo form elements
//
function clearButtonAction() {
	document.getElementById( "textName" ).value = "";
	document.getElementById( "textDate" ).value = "";
	document.getElementById( "description" ).value = "";
	document.getElementById( "quickTodoName" ).value = "";
	document.getElementById( "popupSection" ).selectedIndex = 0;
	document.getElementById( "popupAssigned" ).selectedIndex = 0;
	selectedSection = null;
	selectedMember = null;
}


// -----------------------
//   Slide the Sideshelf
// -----------------------


//
// Resize Functions
// Grow or Shrink the actualy size of the widget
//
function bigger()  { window.resizeBy( 240,0); }
function smaller() { window.resizeBy(-240,0); }


//
// Function: slide
// Slide out the 'addnew' panel
//
function slide(elementId, headerElement) {
	var element = document.getElementById( elementId );
	if(element.up == false) {
		animate(elementId, -225, 0, 280, 247, 250, smaller);
		element.up = true;
		element.down = false;
	} else {
        bigger();
		animate(elementId, 30, 0, 280, 247, 250, null);
		element.down = true;
		element.up = false;
	}
}


//
// Function: slideOpen(id)
// This will only slide open, and stay open if already open
//
function slideOpen(id) {
	var elem = document.getElementById( id );
	if (elem.up != false) {
        bigger();
		animate(id, 30, 0, 280, 247, 250, null);
		elem.down = true;
		elem.up = false;
	}
}


//
// Function: slideClosed(id)
// This will only slide open, and stay open if already open
//
function slideClosed(id) {
	var elem = document.getElementById( id );
	if (elem.up == false) {
		animate(id, -225, 0, 280, 247, 250, smaller);
		elem.up = true;
		elem.down = false;
	}
}


// --------------------
//   Check For Update
// --------------------


function checkForUpdate(event) {
	if ( !wauOverlay ) wau_check_for_update(newUpdate, sameVersion, errorUpdating);
}

function newUpdate( updateObject ) {
	// Show a message to the user
	showOverlay( 'wau_new_overlay' );
	
	wau_updateObject = updateObject;
	
	// Raise flag so the user can download the file
	wau_updateAvailable = true;
}

function errorUpdating() {
	// Show an error message
	showOverlay( 'wau_error_overlay' );
}

function sameVersion() {
	// Show a message to the user
	showOverlay( 'wau_regular_overlay' );

	// Reset the 'new' flag
	wau_updateAvailable = false;
}


//
// Function: downloadUpdate
// Download the newest version
//
function downloadUpdate(event) {
	if ( wau_updateAvailable ) {
		var url = wau_updateObject.url;
		var fileName = url.substr(url.lastIndexOf('/')+1);
		var path = WAU_DOWNLOAD_PATH + fileName;

		// Download the widget the desktop
		wau_download(url, path);
		
		// Hide the overlay
		hideOverlay( 'wau_new' );
		
		// Reset properties
		document.getElementById( 'boundingBox' ).style.cursor = 'default';
		
		setTimeout( 'wauOverlay = false;', 1000 );
	}
}


// ----------------------------
//   Default Widget Functions
// ----------------------------

// Defaults
function hide() {}
function sync() {}
function remove() { try { cache.wipe(); } catch(e) {} }

//
// Function: load()
// Called by HTML body element's onload event when the widget is ready to start
//
function load() {
	dashcode.setupParts();
	refreshSettings();
}


//
// Function: refreshScrollArea()
// Updates the content areas's scroll bar when the content or article length has changed.
//
function refreshScrollArea() {
	var contentarea = document.getElementById("contentArea");
	if (contentarea) contentarea.object.refresh();
}


//
// Function: show()
// Called when the widget has been shown
//
function show() {
	var currTime = new Date();
	var diff = (lastLoadTimestamp) ? currTime.getTime() - lastLoadTimestamp.getTime() : DO_NOT_RELOAD_TIME_SPAN+1;
	if ( diff > DO_NOT_RELOAD_TIME_SPAN ) {
		updateActivitiesList();
		updateTodoList();
	}
}


//
// Function: showBack(event)
// Called when the info button is clicked to show the back of the widget
//
// event: onClick event from the info button
//
function showBack(event) {

	// If the slider is open, pull it in and re-run this function
	var elem = document.getElementById('newTodoPanel');
	if (elem.up == false) {
		slideClosed('newTodoPanel');
		wasOpen = true;
		setTimeout(showBack, 255);
		return;
	}

	// Hide the picker if its open
	var pickerDiv = document.getElementById(datePickerDivID);
	
	// Update the slider number
	document.getElementById( 'completedNumber' ).innerHTML = document.getElementById( 'sliderCompleted' ).value; 
	
	if ( pickerDiv ) {
		pickerDiv.style.visibility = "hidden";
		pickerDiv.style.display = "none";
	}

	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget) {
		widget.prepareForTransition("ToBack");
	}

	front.style.display = "none";
	back.style.display = "block";

	if (window.widget) {
		setTimeout('widget.performTransition();', 0);
	}

}


//
// Function: showFront(event)
// Called when the done button is clicked from the back of the widget
//
// event: onClick event from the done button
//
function showFront(event) {

	// Update user settings & update lists
	if ( refreshSettings() ) {
		updateActivitiesList();
		updateTodoList();
	}
	
	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget) {
		widget.prepareForTransition("ToFront");
	}

	front.style.display="block";
	back.style.display="none";

	if (window.widget) {
		setTimeout('widget.performTransition();', 0);
	}
	
	// Reopen sideshelf if it was open when last flipped
	if (wasOpen) {
		setTimeout( function() {
			var id = 'newTodoPanel';
			var elem = document.getElementById(id);
            bigger();
			animate(id, 30, 0, 280, 247, 250, null);
			elem.down = true;
			elem.up = false;
		}, 700 );
	}
	
	// Always reset wasOpen to false
	wasOpen = false;

}


// Setup default widget functions
if ( window.widget ) {
	widget.onremove = remove;
	widget.onhide = hide;
	widget.onshow = show;
	widget.onsync = sync;
}
