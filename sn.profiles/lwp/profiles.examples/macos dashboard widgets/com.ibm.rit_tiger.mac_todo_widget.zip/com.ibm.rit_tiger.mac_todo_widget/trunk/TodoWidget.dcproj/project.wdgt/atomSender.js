/*
  Taken with permissions from Foxear's Firefox Extension Source
  Originally: [foxearSearch.js] => DogearSearch.prototype.entryObjToXmlDoc
*/

// Atom Constants
REL_MEMBER_LIST  = "http://www.ibm.com/xmlns/prod/sn/member-list";
NAMESPACE_ATOM   = "http://www.w3.org/2005/Atom";
NAMESPACE_APP    = "http://www.w3.org/2007/app";
NAMESPACE_SNX    = "http://www.ibm.com/xmlns/prod/sn";
NAMESPACE_THR    = "http://purl.org/syndication/thread/1.0";
SCHEME_COMPLETED = "http://www.ibm.com/xmlns/prod/sn/flags";
SCHEME_PRIORITY  = "http://www.ibm.com/xmlns/prod/sn/priority"
SCHEME_TODO      = "http://www.ibm.com/xmlns/prod/sn/type";
SCHEME_SECTION   = "http://www.ibm.com/xmlns/prod/sn/type";
TERM_TODO        = "todo";
TERM_SECTION     = "section";
TERM_COMPLETED   = "completed";

//
// Function entryObjectToXML(entry)
// Taken with permissions from Foxear's Firefox Extension Source
// Originally: [foxearSearch.js] => DogearSearch.prototype.entryObjToXmlDoc
// Takes an entry object and turns that into an atom entry document
//
//   Entry:                       =>    XML:
//  ---------------------------        ----------------------------------------------------------------------------------------
//   {                                  <?xml version="1.0" encoding="utf-8">
//     id: "-- ignored --",             <entry>
//     title: "Test Title",               <id>-- ignored --</id>
//     updated: "--ignored--",            <title type='text'>Test Title</title>
//     assigned: "a@us.ibm.com",          <snx:assigned>a@us.ibm.com</snx:assigned>
//     content: "Test",                   <updated>-- ignored --</updated>
//     duedate: "06-06-2008",             <snx:duedate>2008-06-06T04:00:00Z</snx:duedate>
//     thr: {                             <content type='html'>Test Description, Creating a Todo via the AP</content>
//            href: "PARENT_EDIT",        <category term='todo' scheme='http://www.ibm.com/xmlns/prod/sn/type' />
//            ref: "PARENT_ID",           <thr:in-reply-to
//            source: "ACTIVITY_ID"         href="PARENT_EDIT"
//          }                               ref="PARENT_ID"
//   }                                      source="ACTIVITY_ID"
//                                          type="application/atom+xml" />
//                                      </entry>
//
function entryObjectToXML( entry ) {
	
	// Setup the XML Document
	var doc = document.implementation.createDocument(NAMESPACE_ATOM, "entry", null);
	var entryNode = doc.documentElement;
	var processingInstruction = doc.createProcessingInstruction("xml", 'version="1.0" encoding="utf-8"');
	doc.insertBefore(processingInstruction, entryNode);
	entryNode.setAttribute("xmlns:snx", NAMESPACE_SNX);
	entryNode.setAttribute("xmlns:thr", NAMESPACE_THR);
	
	// Title (required)
	var node = doc.createElementNS(NAMESPACE_ATOM, "title");
    node.setAttribute("type", "text");
	node.appendChild(doc.createTextNode(entry.title));
	entryNode.appendChild(node);
	
	// Content (optional)
  if( entry.content ){
      node = doc.createElementNS(NAMESPACE_ATOM, "content");
      node.setAttribute("type", "text");
      node.appendChild(doc.createCDATASection(entry.content));
      entryNode.appendChild(node);
  }

	// Category (required for a todo)
  node = doc.createElementNS(NAMESPACE_ATOM, "category");
  node.setAttribute("scheme", SCHEME_TODO);
  node.setAttribute("term", TERM_TODO);
  entryNode.appendChild(node);

  // Duedate in Atom Format (optional)
	if ( entry.duedate ) {
		node = doc.createElementNS(NAMESPACE_SNX, "duedate");        
		node.appendChild(doc.createTextNode(createAtomDate(entry.duedate)));
        alert(createAtomDate(entry.duedate));
		entryNode.appendChild(node);
	}
    
    // Assigned to (optional)
    if ( entry.assigned ) {
        node = doc.createElementNS(NAMESPACE_SNX, "assignedto");
        node.appendChild(doc.createTextNode(entry.assigned));
        entryNode.appendChild(node);
    }

	// Thread In-Reply-To (required)
	node = doc.createElementNS(NAMESPACE_THR, "in-reply-to");
	node.setAttribute("href", entry.thr.href);
	node.setAttribute("ref", entry.thr.ref);
	node.setAttribute("source", entry.thr.source);
	node.setAttribute("type", "application/atom+xml");
	entryNode.appendChild(node);

	// Return
	return doc;

};


//
// Function: submitTodoEntry( entry )
// Submits a TodoEntry
//
function submitTodoEntry() {
	// Update the name of the todo
    var todoElement = document.getElementById( 'todoCreatedName' );
    
    // Set the display name for the overlay
    todoElement.innerHTML = document.getElementById( 'textName' ).value;
    
    // Do not call this method if the button is 'disabled'
    if( !enableCreate ) return;
    
	// Entry
	var entry = createTodoEntry();
    if (entry == null) {
        return;
    }
    
    // More Data
    var doc = entryObjectToXML(entry);
	var url = entry.thr.href;
	var loginString = Base64.encode(username + ':' + password);
    	
	// Setup the XMLHttpRequest
	var req = new XMLHttpRequest();
	req.open("POST", url);
	req.setRequestHeader("Authorization", 'Basic ' + loginString);
	req.setRequestHeader("Content-Type", "application/atom+xml");
    req.onload = function() {
    
        // Successfully created.  Redraw the list
        updateTodoList();
    
        // Set the name of todo for the overlay, then show the pretty GUI overlay
        document.getElementById( 'overlayName' ).innerHTML = document.getElementById( 'textName' ).value;
        showOverlay( 'addNew' );
        
        // Clear out simple values, but keep the dropdown selects at their previous values
        document.getElementById( "textName" ).value = "";
        document.getElementById( "textDate" ).value = "";
        document.getElementById( "description" ).value = "";
        disableCreateButton();

    };
    
    // ----------
    // WORKAROUND - Encoding is not set properly on doc, which is created
    //   on the fly with createDocument().  The encoding is null and should
    //   instead be set to UTF-8.  I don't know how to fix.
    // OLD WAY - req.send(doc);
    // ----------
    var serializer = new XMLSerializer();
    req.send(serializer.serializeToString(doc));
    // alert(serializer.serializeToString(doc));
}


//
// Function: createTodoEntry
// Creates a TodoEntry based on the GUI Elements
// Returns the entry on success, null otherwise
//
//
// Function: createTodoEntry
// Creates a TodoEntry based on the GUI Elements
// Returns the entry on success, null otherwise
//
function createTodoEntry() {

	// Pull Data from the GUI
	var title = trim(document.getElementById('textName').value);
	var desc  = trim(document.getElementById('description').value);
	
	// Bad Date (shouldn't happen)
	var date = trim(document.getElementById('textDate').value);
	if ( !isDateValid() ) {
		document.getElementById('textDate').focus();
		return null;
	}

	// Get the Activity and its data (bad activity shouldn't happen)
	var activity = selectedActivity;
	if (activity == null || activity.href == null ) {
		document.getElementById('activitySelectPopup').focus();
		return null;
	}
	
	// Set the "source" and "ref" fields
	// If there is a seectd section, you can do an awesome trick and
	// morph/cast a section as an activity like so
	var src = activity.id;
	if ( selectedSection ) {
		activity = selectedSection;
	}
	
	// Email for the assigned
	var email = (selectedMember) ? selectedMember.email : null;

	// Build the entry struct/object
	return {
		title: title,
		content: desc,
		duedate: date,
		assigned: email,
		thr: {
			href: collectionUrl,
			ref: activity.id,
			source: src
		}
	};

}


//
// Function: updateTodoValues(todo, newValues)
// Given a todo and a hash containing new values the
// xml and properties inside the todo are updated to have
// the new values
//
// newValues has the following properties:
//   title, content, duedate, assignedto
//
function updateTodoValues(todo, newValues) {
	
	function helper(todo, tagName, namespace, data, cdata) {
        todo[tagName] = data;
        var xml = todo.xml;
		var doc = xml.ownerDocument;
		var node = findChild(xml, tagName, namespace);
		if ( node ) {
			node.removeChild(node.firstChild);
			if ( cdata ) {
				node.appendChild(doc.createCDATASection(data));
			} else {
				node.appendChild(doc.createTextNode(data));
			}
		}
	}
	
	helper(todo, 'title'     , NAMESPACE_ATOM, newValues.title        );
	helper(todo, 'content'   , NAMESPACE_ATOM, newValues.content, true);
	helper(todo, 'duedate'   , NAMESPACE_SNX , newValues.duedate      );
	helper(todo, 'assignedto', NAMESPACE_SNX , newValues.assignedto   );
	
}


//
// Function: toggleTodoEntry
// Updates a todo Entry, marking it as either completed
// or not completed and making the atom request to update
// on the server.
//
function toggleTodoEntry(todo) {

    // Modify the Atom  Entry inside the todo (todo.xml)
    if ( todo.completed ) {

        // Find the completed category and remove it
        var node = findChildAttrVal(todo.xml, "category", ["scheme", "term"], [SCHEME_COMPLETED, TERM_COMPLETED]);
        todo.xml.removeChild(node);    

    } else {

        // Mark it completed by adding the <category>
        var node = todo.xml.ownerDocument.createElementNS(NAMESPACE_ATOM, "category");
        node.setAttribute("scheme", SCHEME_COMPLETED);
        node.setAttribute("term", TERM_COMPLETED);
        todo.xml.appendChild(node);
       
    }
    
    // Fix the content with CDATA
    var content = findChild(todo.xml, "content");
    if (content != null && content.firstChild != null) {
       var temp = content.firstChild.nodeValue;
       content.removeChild(content.firstChild);
       content.appendChild(todo.xml.ownerDocument.createCDATASection(temp));
    }

    // Prep the xml to send
    todo.xml.setAttribute("xmlns", NAMESPACE_ATOM);
    todo.xml.setAttribute("xmlns:snx", NAMESPACE_SNX);
	todo.xml.setAttribute("xmlns:thr", NAMESPACE_THR);

    // Setup the XMLHttpRequest
	var req = new XMLHttpRequest();
	req.open("PUT", todo.edit);
    var loginString = Base64.encode(username + ':' + password);
	req.setRequestHeader("Authorization", 'Basic ' + loginString);
	req.setRequestHeader("Content-Type", "application/atom+xml");
    req.onerror = function() { alert('Error'); };
    req.onload = function() {
        alert('UPDATE TODO CHECK/UNCHECK RESPONSE: ' + req.status);

		// Get the root element (should be <feed> for an Atom Feed)
		var root = null;
		if ( req.responseXML ) {
			
            // Update the todo in the global hash
            root = req.responseXML.documentElement;
            var todo = parseTodo(root);
            if ( todo.completed ) {
                completedTodoHash.keys.push(todo.id);
                completedTodoHash[todo.id] = todo;
                if ( todoHash[todo.id] ) {
                    removeAt( todoHash.keys, searchList(todoHash.keys, todo.id) );
                    delete todoHash[todo.id];
                }
            } else {
                todoHash.keys.push(todo.id);
                todoHash[todo.id] = todo;
                if ( completedTodoHash[todo.id] ) {
                    removeAt( completedTodoHash.keys, searchList(completedTodoHash.keys, todo.id) );
                    delete completedTodoHash[todo.id];
                }
            }
            
            // Update the GUI
            sortTodoList();
            drawTodoList();
		}        

    };

    // ----------
    // WORKAROUND - Encoding is not set properly on doc, which is created
    //   on the fly with createDocument().  The encoding is null and should
    //   instead be set to UTF-8.  I don't know how to fix.
    // OLD WAY - req.send(doc);
    // ----------
    var serializer = new XMLSerializer();
    req.send('<?xml version="1.0" encoding="utf-8" ?>' + "\n" + serializer.serializeToString(todo.xml));
    // alert('<?xml version="1.0" encoding="utf-8" ?>' + "\n" + serializer.serializeToString(todo.xml));

}


