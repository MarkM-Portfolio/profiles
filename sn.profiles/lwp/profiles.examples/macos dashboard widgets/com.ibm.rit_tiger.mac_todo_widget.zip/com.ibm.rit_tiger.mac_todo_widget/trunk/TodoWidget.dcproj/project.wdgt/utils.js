// -----------------------
//    Fading Functions
// -----------------------

//
// Function: opacity
// Fade an element based on start/end opacities and a time interval
//
function opacity( id, opacityStart, opacityEnd, time, modifier ) {

    // Inline
    document.getElementById(id).style.display = 'inline';
	
	// Speed
	var speed = Math.round( time / 100 ) * modifier;
	var timer = 0;
    	
	// Figure out blending direction
	if ( opacityStart > opacityEnd ) {
		for( var i = opacityStart; i >= opacityEnd; --i, ++timer ) {
            setTimeout( 'changeOpacity('+i+',"'+id+'")', timer*speed );
		}
	} else {
		for( var i = opacityStart; i <= opacityEnd; ++i, ++timer ) {
            setTimeout( 'changeOpacity('+i+',"'+id+'")', timer*speed );
		}
	}

}


//
// Function: changeOpacity(opacity, id)
// Set the opacity of an element given a percentage
//
function changeOpacity( opacity, id ) {
    document.getElementById( id ).style.opacity = (opacity / 100); 
}

// -----------------------
//  DOM Walking Functions
// -----------------------


//
// Function: findChild(element, nodeName, namespace)
// Scans the children of a given DOM element for a node matching nodeName, optionally in a given namespace.
//
// element: The DOM element to search.
// nodeName: The node name to search for.
// namespace: Optional namespace the node name must be in.
//
// Returns the child node if found, otherwise null.
//
function findChild(element, nodeName, namespace) {
	for (var child = element.firstChild; child != null; child = child.nextSibling) {
		if (child.localName == nodeName) {
			if (namespace == null || child.namespaceURI == namespace)
				return child;
		}
	}
	return null;
}


function findChildren(elem, nodeName, namespace) {
	var arr = [];
	for (var child = elem.firstChild; child != null; child = child.nextSibling) {
		if (child.localName == nodeName) {
			if (namespace == null || child.namespaceURI == namespace)
				arr.push(child);
		}
	}
	return arr;
}


//
// Function: findChildrenAttrVal(elem, nodeName, attrs, values, namespace)
// Find the child node of a given node that have the following
// attribute and value pairs.
//
// Example: findChildrenAttrVal(elem, 'link', ['rel'], ['self']);
// will find all <link rel="self"> nodes inside of elem
//
function findChildrenAttrVal(elem, nodeName, attrs, values, namespace) {
	var arr = [];
	var qualifies;
	if (attrs.length != values.length) { return arr; }
	for (var child = elem.firstChild; child != null; child = child.nextSibling) {
		if (child.localName == nodeName) {
			if (namespace == null || child.namespaceURI == namespace) {
				qualifies = true;
				for (var i=0; i<attrs.length; i++) {
					if (child.getAttribute(attrs[i]) != values[i]) {
						qualifies = false;
						break;
					}
				}
				if (qualifies) { arr.push(child); }
			}
		}
	}
	return arr;
}


function findChildAttrVal(elem, nodeName, attrs, values, namespace) {
	var arr = findChildrenAttrVal(elem, nodeName, attrs, values, namespace);
	return (arr.length > 0) ? arr[0] : null;
}


//
// Function: atomTextToHTML(element)
// Extracts the content of an atom text construct as HTML for display
//
function atomTextToHTML(element) {

	// Exit on null elements
	if (!element) {
		return;
	}

	// Depending on the type of the element, get the content into a <div>
	var NS_XHTML = "http://www.w3.org/1999/xhtml";
	var html;
	var type = element.getAttribute("type");
	if (type && (type.indexOf("xhtml") > -1)) {
		var div = findChild(element, "div", NS_XHTML);
		if (div) {
            html = div.cloneNode(true);
		}
	} else if (type && (type.indexOf("html") > -1)) {
		html = document.createElement("div");
		html.innerHTML = allData(element);
	} else {
		html = document.createElement("div");
		var elementText = allData(element);
		elementText = elementText.replace(/^\s+/, "");
		elementText = elementText.replace(/\s+$/, "");
		html.innerText = elementText;
	}
	
	// Return
	return html;

}


//
// Function: allData(node)
// Concatenate all the text data of a node's children.
//
function allData(node) {
	var data = "";
	if (node && node.firstChild) {
		node = node.firstChild;
		if (node.data) { data += node.data; }
		while (node = node.nextSibling) {
			if (node.data) { data += node.data; }
		}
	}
	return data;
}


// -----------------------
//  Array/List Functions
// -----------------------


//
// Function: getFromList(lst, func)
// Returns the value such that func(a) returns true
// Example usage:
//	 var arr = [ {name: "joe"}, {name: "steve"} ];
//	 var man = getFromList(arr, function(a) { return a.name == "joe" });
//
function getFromList(lst, func) {
	if ( func != null ) {
		for (var i=0; i<lst.length; i++) {
			if ( func(lst[i]) ) {
				return lst[i];
			}
		}
	}
	return null;
}


//
// Function: removeAt(arr, index)
// Removes an index from an array
//
function removeAt(arr, index) {
	var size = arr.length;
	for (var i=0; i<size; i++) {
		if ( i === index ) {
			arr.shift();
		} else {
			arr.push( arr.shift() );
		}
	}
}


//
// Function: setDifference(lst1, lst2)
// In english this finds what is in lst1 but not in lst2
// Takes the set difference in the form of
//	 lst1 - lst2 = returned list
//
function setDifference(lst1, lst2) {
	var diff = [];
	for (var i=0; i<lst1.length; i++) {
		if ( searchList(lst2, lst1[i]) == -1 ) {
			diff.push(lst1[i]);
		}
	}
	return diff;
}


//
// Function: searchList(lst, value)
// Searches a list linearly (can't expect it to be sorted)
// Returns the index of the element or -1 if not found
//
function searchList(lst, value) {
	for (var i=0; i<lst.length; i++) {
		if (lst[i] == value) {
			return i;
		}
	}
	return -1;
}


//
// Function: setUnion(lst1, lst2)
// Joins two lists removing duplicates
// Returns a third list
//
function setUnion(lst1, lst2) {
	return lst1.concat( setDifference(lst2, lst1) );
}


// -----------------------
//     Date Functions
// -----------------------


//
// Function: parseAtomDate(atomDate)
// Converts a date in Atom format to a Javascript Date
// Similiar to Bob Stachel's implementation
// Example:
// 1996-12-19T16:39:57Z
// yyyy mm dd hh mm ssZ
// 01234567890123456789
//
function parseAtomDate(s) {
	return new Date(Date.UTC(
		parseInt(s.substr(0,4)),
		parseInt(s.substr(5,2),10)-1,
		parseInt(s.substr(8,2),10),
		parseInt(s.substr(11,2),10),
		parseInt(s.substr(14,2),10),
		parseInt(s.substr(17,2),10)
	));
}

//
// Function: createAtomDate(date)
// Converts a date string in the format "mm-dd-yyyy" to Atom Format
// The seperator may be anything as long as it is consistant
// Simliar to json2.js's implementation
// Example:
// 06/20/2008  => 2008-20-06T04:00:00Z
// mm-dd-yyyy  => yyyy-mm-ddThh:mm:ssZ
//
function createAtomDate(dateStr) {
	
	dateStr = dateStr.replace(/\s/g,'');
	var mdy = dateStr.split( dateStr.match(/\D/) );	
	var d = new Date();
	d.setFullYear(mdy[2],mdy[0]-1,mdy[1]);
	d.setHours(0);
	d.setMinutes(0);
	d.setSeconds(0);
	
	function f(n) {
		return n < 10 ? '0' + n : n;
	}

	return d.getUTCFullYear() + '-' +
		f(d.getUTCMonth() + 1)  + '-' +
		f(d.getUTCDate())       + 'T' +
		f(d.getUTCHours())      + ':' +
		f(d.getUTCMinutes())    + ':' +
		f(d.getUTCSeconds())    + 'Z';

}


//
// Function: getCorrectYear(date)
// Correctly returns the year value
//
function getCorrectYear(date) {
	var yr = date.getYear();
	return (yr < 1000) ? yr + 1900 : yr;
}


//
// Function: dateToString
// Gives a nice string value back for a date object
//
function dateToString(date) {

	// Get this morning at midnight
	var today = new Date();
	today.setHours(0);
	today.setMinutes(0);
	today.setSeconds(0);
	
	// Parsed from the Cache
	if ( !date.getTime ) { date = parseAtomDate(date); }
	
	// Compare times
	var day = 3600*1000*24;
	var today_time = today.getTime();
	var date_time = date.getTime();
	var days = (date_time - today_time) / day;

	// Already Due
	if ( today_time > date_time ) {
		if ( Math.abs(days) < 1 ) {
			return "Due Today";
		} else {
			var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
			var str = months[date.getMonth()] + " " + date.getDate() + ", " + getCorrectYear(date);
			return "Was Due " + str;
		}
	}

	// Due in x days
	else {
		if ( days < 2 ) {
			return "Due Tomorrow";
		} else {
			return "Due in " + Math.floor(days).toString() + " days";
		}
	}

}


//
// Function: dateToShortString(date)
// Creates a simple m/d/yyyy string
//
function dateToShortString(date) {
	if ( !date.getTime ) { date = parseAtomDate(date); }
	return (date.getMonth()+1) + "/" + date.getDate() + "/" + getCorrectYear(date);
}


// -----------------------
//    Extra Functions
// -----------------------


//
// Function: nvl(elem, val)
// Returns val if elem is undefined, null, or ''
//
function nvl(elem, val) {
    return ( elem == undefined || elem == null || elem == '' ) ? val : val;
}


//
// Function: trim(str)
// Removes whitespace from the front and back of the string
//
function trim(str) {
	return (str) ? str.replace(/^\s+|\s+$/g,'') : str;
}
