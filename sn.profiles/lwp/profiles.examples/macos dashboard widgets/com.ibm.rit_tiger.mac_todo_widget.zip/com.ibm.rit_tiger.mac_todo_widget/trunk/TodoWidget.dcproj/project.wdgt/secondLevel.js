/*
  Handles 2nd stage GUI updates based on the first
  level selection.  For example:
    - Populating the member select list after an activity is selected
    - Populating the section select list after an activity is selected
*/

// Globals
var memberList = [];
var sectionList = [];
var collectionUrl = null;
var memberListUrl = null;
var selectedMember = null;
var selectedSection = null;

// HttpRequestObjects that may need to be aborted
reqGetUrls = null;
reqGetMembers = null;
reqGetSections = null;

// URL Parts
var SECTION_URL_PREFIX = "service/atom2/activity?ps=50&nodetype=section&activityUuid=";


//
// Function: postActivitySelected()
// A simple one function to call to delegate the work
//
function postActivitySelected() {
	
	// Clean + Get what was selected
	clearSecondLevelData();
	disableSecondLevel();
	
	// User selected the bad value
	if ( selectedActivity == null ) {
        disableCreateButton();
        abortGetUrls();
        abortGetSections();
		return;
	}
    
    if( document.getElementById( 'textName' ).value != "" ) {
        enableCreateButton();
    }
	
	// Get the Collection and Member List from the Activity's <entry>
	// This will automatically popuplate the members as soon as possible
	// because the request is asynchronous, it will happen on the callback.
	getUrlsForActivity(selectedActivity);
	
	// Get the Sections
	getSectionsForActivity(selectedActivity);

}

//
// Function: abortGetUrls
// Checks if aborting the Get URLs
//
function abortGetUrls() {
	if (reqGetUrls != null) {
		reqGetUrls.abort();
		reqGetUrls = null;
	}
	if (reqGetMembers != null) {
		reqGetMembers.abort();
		reqGetMembers = null;
	}
}


//
// Function: getUrlsForActivity(activity)
// Gets the collection URL and Member List URL
//
function getUrlsForActivity(activity) {
	
	// Abort any pending requests before starting a new one
	abortGetUrls();
	
	// Perform a GET request on the edit link
	reqGetUrls = new XMLHttpRequest();
	reqGetUrls.overrideMimeType("text/xml");
	reqGetUrls.open("GET", activity.selfLink);
	var loginString = Base64.encode(username + ':' + password);
	reqGetUrls.setRequestHeader("Authorization", 'Basic ' + loginString);
	reqGetUrls.setRequestHeader("Cache-Control", "no-cache");

	// onLoad Response
	reqGetUrls.onload = function() {
		alert('GET URLS RESPONSE: ' + reqGetUrls.status);

		// Not successful
		if ( reqGetUrls.status != 200 ) {
            alert("-- COULD NOT GET THE ACTIVITY's ENTRY --");
            return;
		}

		// Parse out the URLs
		if ( reqGetUrls.responseXML ) {
            rootFeed = reqGetUrls.responseXML.documentElement;
        
            //  <collection href="...">
            var collection = findChild(rootFeed, "collection", NAMESPACE_APP);
            collectionUrl = collection.getAttribute("href");

            // <link rel="http://www.ibm.com/xmlns/prod/sn/member-list" href="..." />
            memberListUrl = findChildAttrVal(rootFeed, 'link', ['rel'], [REL_MEMBER_LIST]).getAttribute('href');
        
        }
				
		// Populate the members list and Cleanup
		populateMembers();
		reqGetUrls = null;

	}
    
	// Send the request to populate the urls
	reqGetUrls.send(null);

}


//
// Function: populateMembers()
// Uses the memberListUrl to populate information about
// the members
//
function populateMembers() {
	if (!memberListUrl)	{ return; }
	
	// Perform a GET request on the memberListUrl
	reqGetMembers = new XMLHttpRequest();
	reqGetMembers.overrideMimeType("text/xml");
	reqGetMembers.open("GET", memberListUrl);
	var loginString = Base64.encode(username + ':' + password);
	reqGetMembers.setRequestHeader("Authorization", 'Basic ' + loginString);
	reqGetMembers.setRequestHeader("Cache-Control", "no-cache");
	
	// Build the select list on load
	reqGetMembers.onload = function() {
		alert("GET MEMBERS RESPONSE: " + reqGetMembers.status);
		
		// Not successful
		if ( reqGetMembers.status != 200 ) {
            alert("-- COULD NOT GET THE ACTIVITY's ENTRY --");
            return;
		}
		
		// Parse the member list
		if ( reqGetMembers.responseXML ) {
	    rootFeed = reqGetMembers.responseXML.documentElement;
			for (var entry = rootFeed.firstChild; entry != null; entry = entry.nextSibling) {
				if (entry.nodeName == "entry") {
	
					//  <contributor> node has <name> and <email>
					var contributor = findChild(entry, "contributor");
					if (contributor) {
						var email = atomTextToHTML(findChild(contributor, "email")).innerText;
						var name  = atomTextToHTML(findChild(contributor, "name")).innerText;
						memberList.push({
							email: email,
							name: name
						});
					}
					
				}
			}
		}
		
		// Build up the select list (nothing selected, defaults to -- All --)
		var select = document.getElementById('popupAssigned');
		addOption(select, "-- All (Shared) --", -1);
		for (var i=0; i<memberList.length; i++) {
			addOption(select, memberList[i].name, i);
		}
		
		// Cleanup
		reqGetMembers = null;
		
	}
	
	reqGetMembers.send(null);
	
}

//
// Function: abortGetSections
// Aborts the Get sections request
//
function abortGetSections() {
	if (reqGetSections != null) {
		reqGetSections.abort();
		reqGetSections = null;
	}
}

//
// Function: getSectionsForActivity(activity)
// Gets the collection URL and Member List URL
//
function getSectionsForActivity(activity) {
	
	// Abort any pending request before starting a new one
	abortGetSections();
	
	// Build the URL for sections within this activity
	var url = server + SECTION_URL_PREFIX + activity.uuid;
	
	// Perform a GET request on that threaded url
	reqGetSections = new XMLHttpRequest();
	reqGetSections.overrideMimeType("text/xml");
	reqGetSections.open("GET", url);
	var loginString = Base64.encode(username + ':' + password);
	reqGetSections.setRequestHeader("Authorization", 'Basic ' + loginString);
	reqGetSections.setRequestHeader("Cache-Control", "no-cache");

	// onLoad Response
	reqGetSections.onload = function() {
		alert('GET SECTION URL RESPONSE: ' + reqGetSections.status);

		// Not successful
		if ( reqGetSections.status != 200 ) {
            alert("-- COULD NOT GET THE SECTIONS VIA THREADED URL --");
            return;
		}
		
		// Parse out the Entries which are sections
		if ( reqGetSections.responseXML ) {
	    rootFeed = reqGetSections.responseXML.documentElement;
			for (var entry = rootFeed.firstChild; entry != null; entry = entry.nextSibling) {
				if (entry.nodeName == "entry") {
					
					// Harvest the Section Data
					var title = atomTextToHTML(findChild(entry, 'title')).innerHTML;
					var id = atomTextToHTML(findChild(entry, 'id')).innerText;
                    var editLink = findChildAttrVal(entry, 'link', ['rel'], ['edit']);
                    editLink = editLink ? editLink.getAttribute('href') : null;

                   sectionList.push({
                       id:id,
                       title:title,
                       href:editLink,
                   });

				}
			}
		}

		// Populate the sections list
		populateSections();
		
		// Cleanup
		reqGetSections = null;

	}
    
	// Send the request to populate the urls
	reqGetSections.send(null);

}


//
// Function: populateSections
// Fills the section select list with the values from
// the sectionList.
//
function populateSections() {
	var select = document.getElementById('popupSection');
	addOption(select, "-- None --", -1);
	for (var i=0; i<sectionList.length; i++) {
		addOption(select, sectionList[i].title, i);
	}
}


//
// Function: updateSelectedMember
// One to one correlation between the selected's value in
// the <select> and in the memberList array.  For the
// special case of -1 just set it to null
//
function updateSelectedMember() {
	var select = document.getElementById('popupAssigned');
	var selectedValue = select[select.selectedIndex].value;
	selectedMember = (selectedValue == -1) ? null : memberList[selectedValue];
}


//
// Function: updateSelectedSection
// One to one correlation between the selected's value in
// the <select> and in the sectionList array.  For the
// special case of -1 just set it to null
//
function updateSelectedSection() {
	var select = document.getElementById('popupSection');
	var selectedValue = select[select.selectedIndex].value;
	selectedSection = (selectedValue == -1) ? null : sectionList[selectedValue];
}


//
// Function: disableSecondLevel()
// Disable and clear the second level select lists
//
function disableSecondLevel() {
	var selectIds = ['popupSection', 'popupAssigned'];
	for (var i=0; i<selectIds.length; i++) {
		var select = document.getElementById(selectIds[i]);
		select.options.length = 0;
		select.enabled = false;	
	}
}


//
// Function: clearSecondLevelData()
// Cleans the stored lists and urls of data
//
function clearSecondLevelData() {
	memberList = [];
	sectionList = [];
	collectionUrl = null;
	memberListUrl = null;
}