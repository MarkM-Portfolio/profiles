/*
  Manage a cache using the Widget Cache (wc.js) library.
  This widget only caches a single object, so these wrapping
  functions make it simple for the GUI.
  
  The object being cached is both the todoHash and
  completedTodoHash (both inside a single object like so):
  
    {
      todoHash: ...,
      completedTodoHash: ...
    }
    
  Finally this script stores the most recent todo in
  todoHash only writes to the cache if there is a
  change to the "newwest id".  This prevents needless
  caching of unchanged data.
*/

// Globals
var cache = new WC('ActivitiesTodoWidget');
var TODOFEED_CACHE_NAME = 'todofeed';
var mostRecentTodoId = null;


//
// Function: write_to_cache(obj)
// Serializes the object to a cache
//
function write_to_cache() {
	cache.cache(TODOFEED_CACHE_NAME, { todoHash: todoHash, completedTodoHash: completedTodoHash });
	cacheExists = true;
}


//
// Function: fetch_from_cache()
// Pull the string stored in the cache
// Returns an XML Document Object
//
function fetch_from_cache() {
	var meta = cache.fetch(TODOFEED_CACHE_NAME);
	todoHash = meta.todoHash;
	completedTodoHash = meta.completedTodoHash;
	drawTodoList();
}


//
// Function: cacheIfNeeded()
// Checks the mostRecentTodo and writes to
// the cache if the obj is newer
//
function cacheIfNeeded() {
	var key = todoHash.keys[0];
	if ( key ) {
		var newRecentTodoId = todoHash[todoHash.keys[0]].id;
		if ( mostRecentTodoId == null || mostRecentTodoId != newRecentTodoId ) {
			mostRecentTodoId = newRecentTodoId;
			write_to_cache();
		}
	}
}
