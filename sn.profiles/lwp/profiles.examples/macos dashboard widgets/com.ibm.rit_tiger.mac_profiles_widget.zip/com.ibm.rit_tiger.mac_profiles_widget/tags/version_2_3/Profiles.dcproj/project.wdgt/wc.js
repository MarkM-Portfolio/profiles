/*
  Widget Cache for a Widget with Shell Access
  Author: Joseph Pecoraro
  Date: Monday July 7, 2008
  Requires: json2.js (a JSON library)
  Description:

    Provided with the path to a cache directory this library
    will write cache files using `echo` and read with `cat`
    in 4kb file increments.  This seems to work okay without
    crashing the dashboard.


  Cache File Convention:
  ----------------------

    Cache files are created at:

      ~/Library/Caches/user_provided_dir_name/ <here>

    Using this library you cache an object and at the same
    time you provide a "name".  [ @see cache(name, obj) ]
    The "name" becomes the base name for the cache files.
    So if you executed cache(obj, 'alpha') then obj would
    be JSONified and stored in up to 4kb chunks in these files:

      alpha0, alpha1, alpha2...

    This works with any simple "name".  Even those ending in
    a number already.  However it may be confusing to manually
    debug.  Also note that a special sorting algorithm is run
    to make sure that filenames are sorted in the correctly,
    so that alpha10 comes after alpha9.  This simply sorts
    by taking the trailing number and parsed to its Base 10
    value and sorting on that (instead of sorting by string).

    Finally, files that do not match this convention are simply
    ingored and will never be modified or removed.


  Initialize:
  -----------

    On startup this scans the cache directory to learn all of
    the already cached files.  It rebuilds its index of what
    cached objects already exist and sets up its map of files
    so that its ready to go immediatly to fetch a cached file.
    Note that wc_init_cache() is explicitly invoked in this
    script so it should never need to be directly invoked.

    If nothing previously exists then the cache folder will be
    created in preparation (using mkdir -p).


  Wipe:
  -----

    If you ever want to clear the entire cache you may simply
    call wipe() and all the cached objects and their known
    files will be deleted.

    If you provide a "name" to wipe(name) then only the
    named cache file will be deleted.  This will fail
    gracefully if you try to delete something that
    was not cached.

  How To Use:
  -----------

    1. Include the wc.js and json2.js files:

         <script type="text/javascript" src="json2.js"></script>
         <script type="text/javascript" src="wc.js"></script>

    2. Create a WC object like so:

         var cache_object = new WC('WC_DIR_NAME');

       Again, the cache folder name will be at:
       ~/Library/Caches/WC_DIR_NAME/

    3. Make use of the functions below to cache and fetch objects!

         cache_object.cache(obj, name)
         Cache the "obj".  Recall it later using "name"

         cache_object.fetch(name)
         Returns the object that was cached using "name"

         cache_object.wc_wipe(name)
         Clears the item cached with the given "name".
         If no "name" is provided, all cached items are cleared.

         cache_object.list()
         Returns a list of the "names" of already cached items.

         cache_object.exists(name)
         Checks if there is an item cached with the given "name".
         If no "name" is provided, this returns true if there
         is at least one item cached.

    4. Thats it!  Hack away.

*/


function WC(dirname) {

	// -----------------------
	//    Member Variables
	// -----------------------
	this.WC_USER_HOME   = widget.system('echo "$HOME"', null).outputString.replace(/\n/,'');
	this.WC_CACHE_DIR   = this.WC_USER_HOME + '/Library/Caches/' + dirname;
	this.WC_CACHE_DELTA = 4096;
	this.wc_objects     = [];
	this.wc_file_map    = {};
	this.wc_init_cache();

}


// -----------------------
//     Init Function
// -----------------------

WC.prototype.wc_init_cache = function() {
	var ls = widget.system("/bin/ls " + this.WC_CACHE_DIR, null).outputString;
	if ( ls == undefined ) {
		widget.system('/bin/mkdir -p ' + this.WC_CACHE_DIR, null);
	} else {

		// Grab each cached object, build up the list and filemap
		var regex = /^(.*?)\d+$/;
		var arr = ls.split(/\n/);
		for (var i=0; i<arr.length; i++) {
			var matches = null;
			var filename = arr[i];
			if ( matches = filename.match(regex) ) {
				var prefix = matches[1];
				if ( this.wc_file_map[prefix] == undefined ) {
					this.wc_objects.push(prefix);
					this.wc_file_map[prefix] = [];
				}
				this.wc_file_map[prefix].push(this.WC_CACHE_DIR + '/' + filename);
			}
		}

		// Sorts based on the number suffix of a string
		// so that "alpha10" is greater then "alpha2"
		function lil_sort(a,b) {
			var anum = parseInt(a.match(/\d+$/), 10);
			var bnum = parseInt(b.match(/\d+$/), 10);
			return (anum<bnum) ? -1 : (anum>bnum) ? 1 : 0;
		}

		// Sort each file list
		for (var i=0; i<this.wc_objects.length; i++) {
			this.wc_file_map[ this.wc_objects[i] ].sort(lil_sort);
		};

	}
}


// -----------------------
//    Public Functions
// -----------------------

WC.prototype.exists = function(name) {
	return (name != null) ? (this.wc_file_map[name] != undefined) : (this.wc_objects.length > 0);
}

WC.prototype.list = function() {
	return this.wc_objects;
}

WC.prototype.wipe = function(name) {
	if (name) {
		if (this.wc_file_map[name]) {
			this.wc_file_map[name].forEach(this.wc_remove_file);
			this.wc_remove_arr_val(this.wc_objects, name);
			delete this.wc_file_map[name];
		}
	} else {
		for (var i=0; i<this.wc_objects.length; i++) {
			var name = this.wc_objects[i];
			this.wc_file_map[name].forEach(this.wc_remove_file);
			delete this.wc_file_map[name];
		}
		this.wc_objects = [];
	}
}

// -----------------------
//         Write
// -----------------------

WC.prototype.cache = function(name, obj) {

	// Debug
	//alert('-- WRITING TO THE CACHE --');

	// In case of null
	if ( obj == null ) {
		//alert('-- CACHING NULL --');
		obj = 'null';
	}

	// Remove the old cache files
	if ( this.wc_file_map[name] ) {
		this.wc_file_map[name].forEach(this.wc_remove_file);
		this.wc_remove_arr_val(this.wc_objects, name);
	}

	// Keep writing out 4096 byte files until the JSON string is exhausted
	this.wc_file_map[name] = [];
	var json_str = JSON.stringify(obj);
	for (var i=0, index=0; index<json_str.length; ++i,index+=this.WC_CACHE_DELTA) {
		var filename = this.WC_CACHE_DIR + '/' + name + i;
		var str = "'" + json_str.substr(index, this.WC_CACHE_DELTA).replace(/'/, "'\"'\"'") + "'";
		this.wc_file_map[name].push(filename);
		widget.system("/bin/echo -n " + str + " > '" + filename + "'", null);
	}

	// Add to the object list
	this.wc_objects.push(name);

	// Debug
	//alert('-- DONE WRITING TO THE CACHE --');

}

// -----------------------
//          Read
// -----------------------

WC.prototype.fetch = function(name) {

	// Debug
	//alert('-- READING FROM THE CACHE --');

	// No Cache, return null
	var file_list = this.wc_file_map[name];
	if ( !file_list ) {
		return null;
	}

	// Build the entire JSON string
	var json_str = '';
	for (var i=0; i<file_list.length; i++) {
		var filename = file_list[i];
		json_str += widget.system('/bin/cat ' + filename, null).outputString;
	}

	// Debug
	//alert('-- DONE READING FROM THE CACHE --');

	// Parse the JSON and return
	return JSON.parse(json_str);

}

// -----------------------
//         Private
// -----------------------

WC.prototype.wc_remove_file = function(filename) {
	widget.system('/bin/rm ' + filename, null);
}

WC.prototype.wc_remove_arr_val = function(arr, val) {
	var size = arr.length;
	for (var i=0; i<size; i++) {
		if ( arr[0] === val ) {
			arr.shift();
		} else {
			arr.push( arr.shift() );
		}
	}
}
