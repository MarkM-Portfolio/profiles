// Modified version of Jonathan Feinberg's blue pages autocomplete YUI code

var YAHOO;

BPACDataSource = function (dsId, props) {
	if(typeof props == "object") {
        for(var p in props) {
            this[p] = props[p];
        }
    }
	this.callId = dsId;
	this.queryMatchSubset = false;
	this._init();
};
BPACDataSource.prototype = new YAHOO.widget.DataSource();
/* CHANGE THIS URL PLEASE */
BPACDataSource.prototype.scriptURI = retrievePreference( 'server' );
BPACDataSource.prototype.callId = null;

BPACDataSource.prototype.callCount = 0;
BPACDataSource.prototype.userEmail = null;

// Downloads the certificate and adds it to your keychain
function installCertificate( server ) {
    var regex = /^https?:\/\/(([\w-]+\.)*[\w-]+)/;
    var matches = regex.exec(server);
    if ( matches ) {
        server = matches[1];
    } else {
        return -1;
    }
    
    var certCommands =  'openssl s_client -showcerts -connect ' + server + ':443 >> profiles_cert.cer;'
                      + 'security add-trusted-cert -p ssl profiles_cert.cer; '
                      + 'rm profiles_cert.cer';

    widget.system( certCommands , null );
}

BPACDataSource.prototype.doQuery = function (oCallbackFn, sQuery, oParent) {
    var self = this;
	var typeaheadRequest = buildRequest( self.scriptURI + TYPEAHEAD_URL + sQuery, false );

    typeaheadRequest.onload = function () {
        if ( typeaheadRequest.status != 200 ) {
            serverError = true;
            triggerSlideDown();
            var message = '<ol>' +
                             '<li> You may have lost connection. </li>' +
                             '<li> The Profiles server may be down. </li>' +
                             '<li> The server URL may be wrong. </li>' +
                             '<li> You may need to trust a self-signed certificate. ' +
                                 'Click <a href="" onclick="javascript:installCertificate(retrievePreference(\'server\'));">here</a> to do that. </li>' +
                         '</ol>';
            setContent( 'Check your connection', message, 'Images/disconnected.png' );
            return; 
        } else {
			serverError = false;
		}
        
        var results = parseTypeahead( typeaheadRequest.responseText );
        self.process(results, oCallbackFn, sQuery, oParent);
    }
    typeaheadRequest.send( null );
};

function parseTypeahead( resp ) {
    var matches = new Array();
    var hiddenDiv = document.createElement( 'div' );
    hiddenDiv.innerHTML = resp;
    
    var allItems = findChildrenLayered( hiddenDiv, 'label' );
    
    for ( var i = 0; i < allItems.length; i+=3 ) {
        matches.push({
              name:  allData( allItems[i] ),
              loc:   allData( allItems[i+1] ),
              email: allData( allItems[i+2] ).replace( /[<>]/g, '' )
        });
    }
	return matches;
}


BPACDataSource.prototype.process = function (result, oCallbackFn, sQuery, oParent) {
	
	function escapeRegexChars(str) {
		return str.replace( /([{}[\]().+*^$|\\\-])/g, '\\$1' ); 
	}
	
	var r = [];
    var regex = new RegExp( escapeRegexChars(unescape(sQuery)), 'i' );	
	for (var i = 0; i < result.length; i++) {
		var m = result[i];
		var highlightedName = m.name;
		var matches = regex.exec(m.name);
		if ( matches != null ) {
			highlightedName = m.name.replace(regex, '<strong>' + matches[0] + '</strong>');
		}
		r[i] = [m.email, "<span class='bpac-name'>"        + highlightedName + 
                         "</span> <span class='bpac-loc'>" + m.loc + 
                         "</span> <span class='bpac-mail'>"+ m.email + "</span>", m];
	}
	oCallbackFn(sQuery, r, oParent);
};

var BPACAutoComplete = function (textInputId, props) {
	if(typeof props == "object") {
        for(var p in props) {
            this[p] = props[p];
        }
    }
    
	var textInput = YAHOO.util.Dom.get(textInputId);
	YAHOO.util.Dom.setStyle(textInput, "position", "relative");
	
	var instanceId = BPACAutoComplete.nextId++;
	
	var bpacId = YAHOO.util.Dom.generateId();
	var bpacDiv = document.createElement("div");
	bpacDiv.setAttribute("id", bpacId);
	bpacDiv.className = "bpac";
	textInput.parentNode.insertBefore(bpacDiv, textInput.nextSibling);
	
	var ds = new BPACDataSource('bpac' + instanceId, props);
	var bpac = new YAHOO.widget.AutoComplete(textInputId, bpacId, ds, {
		animVert: false,
		useIFrame: true,
		highlightClassName: "bpac-highlighted",
		autoHighlight: true,
		useShadow: true,
		maxResultsDisplayed: 8,
		formatResult: function (item, query) {
			return item[1];
		},
		_iFrameSrc: "about:blank"
	});
	if (this.multiple) {
		bpac.delimChar = ',';
	}

	var stopSelect = function (e, obj) {
		YAHOO.util.Event.stopEvent(e);
	};
	var dom = YAHOO.util.Dom;
	var popupWidth = this.popupWidth;
	bpac.containerExpandEvent.subscribe(function() {
		dom.setX(bpacDiv, dom.getX(textInput));
		dom.setY(bpacDiv, dom.getY(textInput) + textInput.offsetHeight);
		var width = popupWidth || (textInput.offsetWidth + 'px');
		dom.setStyle(bpacDiv, "width", width);

		// When showing calculate the width
		bpacDiv.style.visibility = 'visible';
		setAutoSuggestWidth();
		makeSpace();

		// Disable text selection
		var lis = bpacDiv.getElementsByTagName("li");
		for (var i = 0; i < lis.length; i++) {
			YAHOO.util.Event.removeListener(lis[i], "mousedown", stopSelect);
			YAHOO.util.Event.addListener(lis[i], "mousedown", stopSelect);
			lis[i].ondrag = lis[i].onselectstart = function() { return false; };
		}
	});

	// Hide invisible space in the close state when no autosuggest
	bpac.containerCollapseEvent.subscribe(function() {
		if ( !isOpen && !onBack && !isDialog ) {
			window.resizeTo(gClosedWidth, gClosedHeight);
		}
	});

	// Really blur on a blur
	bpac.textboxBlurEvent.subscribe(function() {
		this._elTextbox.blur();
	});
	
	// Let selection bubble up to <input type="search">'s onsearch function
	// But store the name/email pair into the history object
	bpac.itemSelectEvent.subscribe(function(e, args) {
		var name = trim(args[2][2]['name']);
		var email = trim(args[2][2]['email']);
		hist.add(name, email);
		document.getElementById('searchBar').value = name;
	});
	
	// Make the DataSource avaliable for editing
	this.dataSource = bpac.dataSource;
	
};

BPACAutoComplete.nextId = 1;
BPACAutoComplete.prototype.popupWidth = null;
/* BPACAutoComplete.prototype.selectionCallback = makeRequest; */
BPACAutoComplete.prototype.setScriptURI = function(uri) { this.dataSource.scriptURI = uri; }
