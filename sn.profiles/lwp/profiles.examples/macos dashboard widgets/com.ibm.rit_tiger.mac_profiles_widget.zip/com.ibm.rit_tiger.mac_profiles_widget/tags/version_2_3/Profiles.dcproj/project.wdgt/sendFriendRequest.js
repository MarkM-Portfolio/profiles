/*
  Code to get information about the current user
  Author: Joseph Pecoraro
  Date: Tuesday July 1, 2008


	NOTE: Pagination for friend/pending lists has a potential
	timing issue.  If a user is able to login under two valid
	accounts before the entire pagination code finishes then
	the extra XHR (XMLHttpRequests) that were sent to populate
	the extra pages will still populate the friend/pending
	lists.  However, this is ignored because:
	
	   1. The likelyhood is very low
	   2. The most likely case would be the same account twice
	      which means duplicate entries which will still work
	      perfectly fine.
	   3. Lists are regenerated after an hour anyways, and will
	      be populated correctly.  So 

*/

// -----------------------
//    Member Variables
// -----------------------

// Atom Constants
NAMESPACE_SNX = "http://www.ibm.com/xmlns/prod/sn";
NAMESPACE_OPENSEARCH = "http://a9.com/-/spec/opensearch/1.1/";

// States that can be used
var FRIEND_YES  = 0;
var FRIEND_NO   = 1;
var FRIEND_PEND = 2;

// Globals
var friendList = [];
var pendingList = [];
var lastFriendReq = 0;
var req_friendList = null;
var req_pendingList = null;
var req_addColleague = null;
var TIMEOUT_BETWEEN_FRIEND_REQ = 1000*60*60; // 1 hour


// -----------------------
//    Util Functions
// -----------------------


//
// Function: searchListForObjectWithAttrVal(lst, attr, val)
// Scans an object array for an object with the given
// attribute/value pair
// NOTE: utility function
//
function searchListForObjectWithAttrVal(lst, attr, val) {
	if (lst && attr) {
		for (var i=0; i<lst.length; i++) {
			if (lst[i][attr] == val) {
				return lst[i];
			}
		}
	}
	return null;
}


// -----------------------
//       Niceties
// -----------------------
function getFriendByKey(k)    { return searchListForObjectWithAttrVal(friendList,  'key'  , k); }
function getFriendByEmail(e)  { return searchListForObjectWithAttrVal(friendList,  'email', e); }
function getPendingByKey(k)   { return searchListForObjectWithAttrVal(pendingList, 'key'  , k); }
function getPendingByEmail(e) { return searchListForObjectWithAttrVal(pendingList, 'email', e); }


//
// Function: getFriendStatus
// Using the users email you get the colleague status of that
// person in relation to the logged in user.  They are defined
// by the FRIEND_* constant states
//
function getFriendStatus(email) {
	if ( getFriendByEmail(email) != null ) {
		return FRIEND_YES;
	} else if ( getPendingByEmail(email) ) {
		return FRIEND_PEND;
	} else {
		return FRIEND_NO;
	}
}


// -----------------------
//    Sending Request
// -----------------------


//
// Function: sendFriendRequest(personKey, msg)
// Sends a friend request!
//
// Example:
// http://profiles.tap.ibm.com/profiles/xml/friendrequest?targetKey=1434116d-d6da-4885-943e-f067a362228f&lastMod=1214836547851&msg=I%27d%20like%20to%20add%20you%20to%20my%20Connections%20colleagues%20list.
// http://profiles.tap.ibm.com/profiles/xml/friendrequest?targetKey=1434116d-d6da-4885-943e-f067a362228f&lastMod=1214836547851&msg=I%27d%20like
//
function sendFriendRequest(personKey, msg) {
	
	// Make sure this person isn't already in your friend list
	if ( getFriendByKey(personKey) != null ) {
		//alert('Whoa... This person is already your friend!');
		return;
	}
	
	// Default message
	if ( msg == null ) {
		msg = 'Invite from the widget!';
	}

	// URL for a friend request
	var url = retrievePreference( 'server' ) + FRIEND_REQ_URL;
	url += "?targetKey=" + personKey;
	url += "&lastMod=" + (new Date()).getTime();
	url += "&msg=" + encodeURIComponent(msg);
	
	// Abort any pending request before starting a new one
	if (req_addColleague != null) {
		req_addColleague.abort();
		req_addColleague = null;
	}
    
	// Send the XMLHttpRequest
	req_addColleague = new XMLHttpRequest();
	req_addColleague.overrideMimeType("text/xml");
	req_addColleague.open("POST", url);
    
	var loginString = Base64.encode( getAuthString() );
	req_addColleague.setRequestHeader("Authorization", 'Basic ' + loginString);
	req_addColleague.setRequestHeader("Cache-Control", "no-cache");
	req_addColleague.onload = function(xml) {
			
		// Bad
		// Change this to the correct number!
		if ( req_addColleague.status < 200 || req_addColleague.status > 201 ) {
			//alert('BAD FRIEND REQUEST');
			return;
		}
		
		// Already invited response
		if ( req_addColleague.responseText.match(/\s*<error\s*code\s*=\s*.connection-exist.\s*\/>/) ) {
			//alert('Already invited... Sorry, we couldn\'t tell!');
			return;
		}
				
		// Complete
		else {
			onSuccessfulFriendRequest(personKey);
		}
		
	}
	
	// Send
	req_addColleague.send(null);

};


//
// Function: onSuccessfulFriendRequest
// Updates the data structures and GUI after a successful request
//
function onSuccessfulFriendRequest(personKey) {

	// -----
	// TODO: This is a hack... I should probably get the email in a better way
	// -----
	// Mark that person as pending
	pendingList.push({
		key: personKey,
		email: resultsArray[0].email
	});

	// Update the GUI's colleague link
	var col = document.getElementById('colleague');
	col.onmouseover = col.onmouseout = col.onclick = function(){};
	col.style.cursor = 'default';
	col.innerHTML = 'Awaiting Colleague Confirmation';

}


// -----------------------
//    Pulling Requests
// -----------------------

//
// Function: populateColleages(userKey)
// Pulls both the friends list and pending friends lists for
// the user with the given key
//
function populateColleagues(userKey) {

	// Start by clearing the old lists (always... in case the key is bad)
	friendList = [];
	pendingList = [];
	
	// Bad key, quick return
	if ( userKey == null ) {
		//alert('Key was null, not fetching friends or pending friends lists');
		return;
	}
	
	// Set the last friendReq var
	lastFriendReq = (new Date).getTime();
	
	// Pull both
	getFriendsList(userKey);
	getPendingList(userKey);
	
}


//
// Function: getFriendsList(userKey)
// Gets the list of friends and populates friendList for the
// user identified by the given key.
//
// Example:
// http://profiles.tap.ibm.com/profiles/atom/colleagues.do?key=31929063-6e8a-419f-a0da-84fcdd0e6421&output=hcard&ps=50
//
function getFriendsList(userKey) {
	
	// Abort any pending request before starting a new one
	if (req_friendList != null) {
		req_friendList.abort();
		req_friendList = null;
	}
	
	// URL for a friend request
	var url = retrievePreference( 'server' ) + FRIEND_URL + userKey;

	// Recreate the XMLHttpRequest
    req_friendList = buildRequest( url, false );
	req_friendList.onload = function(xml) {
    
		//alert('FRIEND LIST RESPONSE: ' + req_friendList.status);

		// Bad Request
		if ( req_friendList.responseXML == null || req_friendList.status != 200) {
			return;
		}
        
		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( req_friendList.responseXML ) {
			feedRootElement = req_friendList.responseXML.documentElement;
		}

		// Handle Pagination
		var node = findChild(feedRootElement, 'totalResults', NAMESPACE_OPENSEARCH);
		var total = node ? parseFloat(allData(node)) : 0;
		node = findChild(feedRootElement, 'itemsPerPage', NAMESPACE_OPENSEARCH);
		var perpage = node ? parseFloat(allData(node)) : 1;
		var needed  = Math.floor(total / perpage); // floor, we got 1 already so we can round down and add 1
		for (var i=2; i<=needed; i++) {
			getPaginatedPage( url, i, false );
		}

		// Parse Friend Feed [page 0]
		parseFriendFeed(feedRootElement, false);

	}
	
	// Send
	req_friendList.send();

}


//
// Function: getFriendsListPage(url)
// Gets the list of friends from the given url and adds that
// onto the friendList
//
// Example:
// http://profiles.tap.ibm.com/profiles/atom/colleagues.do?key=31929063-6e8a-419f-a0da-84fcdd0e6421&output=hcard&ps=50&page=1
//
function getPaginatedPage(url, page, isPending) {
	url += '&page=' + page;
    var req = buildRequest( url, false );
	req.onload = function(xml) {

		//alert('FRIEND LIST PAGE ' + page + ' RESPONSE: ' + req.status);

		// Bad Request
		if ( req.responseXML == null || req.status != 200) {
			return;
		}
        
		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( req.responseXML ) {
			feedRootElement = req.responseXML.documentElement;
			parseFriendFeed(feedRootElement, isPending);
		}
	
	}
	
	req.send();
}


//
// Function: getPendingList(userKey)
// Gets the list of pending invitations and populates pendingList
// for the user identified by the given key.
//
// Example:
// https://profiles.tap.ibm.com/profiles/atom/colleagues.do?key=31929063-6e8a-419f-a0da-84fcdd0e6421&status=pending&output=hcard
//
function getPendingList(userKey) {
	
	// Abort any pending request before starting a new one
	if (req_pendingList != null) {
		req_pendingList.abort();
		req_pendingList = null;
	}
	
	// URL for a friend request
	var url = retrievePreference( 'server' ) + PENDING_URL + userKey;

	// Recreate the XMLHttpRequest
    req_pendingList = buildRequest( url, true );
	req_pendingList.onload = function(xml) {
    
		//alert('PENDING LIST RESPONSE: ' + req_pendingList.status);

		// Bad Request
		if ( req_pendingList.responseXML == null || req_pendingList.status != 200) {
			return;
		}
        
		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( req_pendingList.responseXML ) {
			feedRootElement = req_pendingList.responseXML.documentElement;
		}
		
		// Handle Pagination
		var node = findChild(feedRootElement, 'totalResults', NAMESPACE_OPENSEARCH);
		var total = node ? parseFloat(allData(node)) : 0;
		node = findChild(feedRootElement, 'itemsPerPage', NAMESPACE_OPENSEARCH);
		var perpage = node ? parseFloat(allData(node)) : 1;
		var needed  = Math.floor(total / perpage); // floor, we got 1 already so we can round down and add 1
		for (var i=2; i<=needed; i++) {
			getPaginatedPage( url, i, true );
		}

		// Parse as a Friend Feed, tell it these are pending [page 0]
		parseFriendFeed(feedRootElement, true);

	}

	// Send
	req_pendingList.send();

}


// -----------------------
//   Private Functions
// -----------------------


//
// Function: parseFriendFeed(feed)
// Parses out friends and adds them to the friendList
//
// <atom:feed snx:total-friends="1" snx:current-page="0">
//   ...
//   <atom:entry snx:key="..." snx:email="...">
//     <atom:title />
//     <atom:id />
//     <atom:link />
//   </atom:entry>
//   ...
// </atom:feed>
//
function parseFriendFeed(feed, isPending) {
	for (var item = feed.firstChild; item != null; item = item.nextSibling) {
		if (item.nodeName == "entry") {
			var content = findChild(item, 'content');
			if ( content ) {
				var card = parseHCard(content);
				( isPending ) ? pendingList.push(card) : friendList.push(card);
			}
		}
	}
}
