/*
  Code to handle Callbacks and Events for the widget GUI
  Author: Steve Willard
  Author: Joseph Pecoraro
  Date: Thursday July 17, 2008
*/

// -----------------------
//       Constants
// -----------------------
var NOT_FOUND = 0;
var BAD_VER   = 1;
var BAD_USR   = 2;
var ADIUM_STATE = { NOT_FOUND : 0, BAD_VER : 1, BAD_USR : 2, GOOD : 3 }

// -----------------------
//         Globals
// -----------------------
var actionTaken = false; 

// ------------------------------
//      Auto-Update Functions
// ------------------------------

//
// Function: checkForUpdate
// Handler for a check for an update button, inside this handler
// are handlers for all three of the wau callbacks
//
function checkForUpdate(event) {
	// Skip if the user selected to skip this version
	if ( updateObject && updateObject.version == skipVersion ) {
		return;
	}

	// Check for Update
	var nullFunction = function(){};
	var onsuccess = function(newUpdate) {
		updateObject = newUpdate;
		triggerToDialog(DIALOG_UPDATE);
	};
	wau_check_for_update(onsuccess, nullFunction, nullFunction);
}

//
// Function: manualCheckUpdate
// Clears the skip value, and checks for an update
//
function manualCheckUpdate(event) {
	skipVersion = -1;
	var nullFunction = function(){};
	var onnewest = function() {}
	var onsuccess = function(newUpdate) {
		updateObject = newUpdate;
		flipToFront();
		setTimeout( 'triggerToDialog('+DIALOG_UPDATE+')', 750+400+10 );
	};
	
	wau_check_for_update(onsuccess, onnewest, nullFunction);
}



//
// Function: skipCallback
// Sets the version to be skipped and closes the dialog
//
function skipCallback(event) {
    if ( triggerFromDialog() ) skipVersion = updateObject.version;
}


//
// Function: installCallback
// Calls the default Widget Auto-Updater download, which
// downloads to the desktop.  Then closes the dialog.
//
function installCallback(event) {
    if ( triggerFromDialog() ) wau_def_new_update_callback(updateObject);
}


//
// Function: inviteCallback
// Callback for the invite to colleage button
//
function inviteCallback(event) {
	if ( triggerFromDialog() ) sendFriendRequest( resultsArray[0].key );
}


// ------------------------------
//   Callback / Event Functions
// ------------------------------

//
// Function: goToProfile
// Opens the current displayed user's Lotus Connections
// Profile page in the default browser
//
function goToProfile(event) {
	widget.openURL(connLink); 
}


//
// Function: openContactAdium
// Runs the "adium.scpt" AppleScript that tries to open an
// Adium chat with the given contact.  This requires that
// the current user be logged into the widget, because
// it uses the current user's account
//
function openContactAdium(event) {
    if ( checkLoggedIntoAdium() ) {
        var execStr = "/usr/bin/osascript Adium.scpt " +
            quote( retrievePreference( 'username' ) ) + " " +
            quote( resultsArray[0].email ) + " " + 
            quote( (resultsArray[0].imgUrl).replace( 'https://', 'http://' ));
        alert (execStr);

        var ADIUM_STATE = parseInt( widget.system(execStr, null).outputString );
        handleAdiumMessage( ADIUM_STATE );
	}
}


//
// Function: handleAdiumMessage(msg)
// Will display the proper chat dialog based on the Adium AppleScript
//
function handleAdiumMessage( message ) {
    switch ( message ) {
        case NOT_FOUND:
            triggerToDialog( DIALOG_CHAT_NO_INSTALL );
            break;
        case BAD_VER:
            triggerToDialog( DIALOG_CHAT_BAD_VERSION );
            break;
        case BAD_USR:
            triggerToDialog( DIALOG_CHAT_NO_LOGIN );
            break;
    }
}


//
// Function: addToAddressBook
// Runs the "AddressBook.scpt" AppleScript and tries to import
// information on the current displayed user into the address
// book (name, email, phone, image...).  The user will be put
// into an "IBM" group inside of AddressBook
//
function addToAddressBook(event) {
    if ( resultsArray && resultsArray.length > 0 ) {

        // First/Last Name
        var names = resultsArray[0].name.split(/\s+/);
        var firstName = names[0];
        var lastName = "";
        if ( names.length > 1 ) {
            lastName = names[names.length-1];
        }
        
        // Phone Number, Job Title, Email
        var tel = document.getElementsByClassName("tel")[0].children[1].innerHTML;
        var jobTitle = document.getElementsByClassName("role")[0].innerHTML;
        var email = document.getElementsByClassName("email")[0].innerHTML;
        var imgUrl = resultsArray[0].imgUrl;

        // usage: AddressBook.scpt first last phone organization jobTitle email addr
        var execStr = "/usr/bin/osascript AddressBook.scpt " +
            quote(firstName) + " " + quote(lastName) + " " +
            quote(tel)       + " " + quote(ADDR_GROUP) + " " +
            quote(jobTitle)  + " " + quote(email) + " " +
            quote(imgUrl);
        
        // Execute immediately
        widget.system(execStr, null);
    }
}


//
// Function: makeSpace
// This will add an extra 200 pixels onto the bottom of the widget
// whenever the user starts typing inside it and the height
// is not at least a certain size (for instance it is closed)
//
function makeSpace(event) {
	window.resizeTo(window.innerWidth, Math.max(window.innerHeight,200));
}


//
// Function: autoClose
// If the widget is open but the search box is empty or if
// the user clicks the (x) to empty the search box (onclick)
// then the widget is automatically closed
//
function autoClose(event) {

	// Open, without a dialog and the search bar is empty => Close
	if ( isOpen && !isDialog && document.getElementById('searchBar').value.length == 0) {
		triggerSlideUp();
	}
	
	// No dialog and the search bar is empty => Hide Autocomplete
	if ( !isDialog && document.getElementById('searchBar').value.length == 0) {
		var bpacBox = document.getElementsByClassName('bpac');
		if ( bpacBox.length > 0 ) {
			bpacBox = bpacBox[0];
			bpacBox.style.visibility = 'hidden';
		}
	}

}


//
// Function: nullDoubleClick
// Prevents autoClose on the searchBar!
//
function nullDoubleClick(event) {
    event.stopPropagation();
    event.preventDefault();
}


//
// Function: giveFeedback
// Opens the feedback page
//
function giveFeedback(event) {
	widget.openURL('http://ibmrit.bluehost.ibm.com/mac_contact/');
}


//
// Function: goToSearchBar
// Focuses and Selects everything in the searchBar
//
function goToSearchBar(event) {
    document.getElementById( 'searchBar' ).select();
}


//
// Function: slideToMinSize
// Handles double-clicking the top bar to open, close, or shrink
// the widget.
//
function slideToMinSize(event) {
	if ( actionTaken === true ) { return; }
	actionTaken = true;
	setTimeout(function(){actionTaken=false}, 400);
	if ( !isDialog ) {
		if ( isOpen && isMinSize() ) {
			triggerSlideUp();
		} else {
			gSavedOpenWidth = gMinWidth;
			gSavedOpenHeight = gMinHeight;
			triggerSlideDown();
		}
	}
}


// ------------------------------
//   Configure Server Functions
// ------------------------------

//
// Function: configureServerCallback
// This function is called when the user clicks the "Configure Server"
// pseudo-link on the back of the widget.  It handles showing/hiding
// the proper elements on the GUI as well as trying to pre-determine
// the Connections Server.
//
function configureServerCallback(event) {

	// Defaults, local variables because they are infrequently used
	var defaultServer = 'http://profiles.tap.ibm.com/profiles/';
	var component = 'profiles';
	
	// Determine if we need to use the LCSWC
	var predetermine = ( retrievePreference('server') == '' );
	// alert('Predetermine: ' + predetermine);

	// Show the fields
	revealServerFields(predetermine);
	
	// Predetermining
	if (predetermine) {
		var loginStr = Base64.encode( getAuthString() );
		var txt = document.getElementById('server');
		if (LCSWC.exists()) {
			LCSWC.pull(loginStr, function(state) {
				if (state === LCSWC_SUCCESS) {
					var server = LCSWC.get(component);
					txt.value = ( server == null ) ? defaultServer : server;
				} else {
					txt.value = defaultServer;
				}
				fadeOut( document.getElementById('loader') );
			});
		} else {
			txt.value = defaultServer;
			fadeOut( document.getElementById('loader') );
		}
	}

}


//
// Function: storeServerUrl
// Decides if the server url should be cached in the LCSWC
//
function storeServerUrl() {
    if ( right( retrievePreference( 'server' ), 1 ) == '/' ) {
        var elem = document.getElementById( 'server' ).value;
        document.getElementById( 'server' ).value = elem.substr( 0, elem.length - 1 );
    }
    storePreferences();
	LCSWC.set(retrievePreference('server'), Base64.encode(getAuthString()));
}


//
// Function: revealServerFields
// Fades the server fields in.  This will show the loading image
// if the single param "showLoading" is true
//
function revealServerFields(showLoading) {

	// Hide the "Configure Server" link
	document.getElementById('tConfigure').style.visibility = 'hidden';
	
	// Decide if we should show the loading gif
	if ( showLoading ) {
		document.getElementById('loader').style.visibility = 'visible';
	}
	
	// Fade the server fields in
	var serverFields = document.getElementById('serverFields');
	serverFields.style.opacity = 0.0;
	serverFields.style.visibility = 'visible';
	fadeIn(serverFields);

}


//
// Function: hideServerFields
// Hides the serverFields components, including the loading image
// on the back.  This is typically called when flipping to the back
// to keep it always consistant.
//
function hideServerFields() {
	document.getElementById('tConfigure').style.visibility = 'visible';
	document.getElementById('serverFields').style.visibility = 'hidden';
	document.getElementById('loader').style.visibility = 'hidden';
}
