/*
  History
  Author: Joseph Pecoraro
  Date: Monday August 11, 2008
  Description:

    This is a backend storage for the search history.  It is used
    because searches and people are uniquely identified by email
    addresses, but those are not user friendly.  The user actually
    searches on the name.  So this is file contains a hash table
    translation for those searched names to their unique emails
    for a more user friendly interface.


  Note:
  -----

    The hash table will limit itself in order to not continually
    grow out of memory. The number of elements saved comes from
    the results attribute on the <input type="search"> inside
    main.html.  Be careful if you change this value.


  Data Storage:
  -------------

    max: int - bounds for the table
	queue: array - oldest => most recent unique names
	table: array - names (keys) => emails (values)


  How To Use:
  -----------

    1. Include the history.js

         <script type="text/javascript" src="history.js"></script>

    2. Create a History object using its constructor.
       The single parameter is optional.

         var hist = new History(5);

    3. Make use of the public functions to interact with the history.

       - Add elements to the list like so:

          hist.add('joe', 'joepeck02@gmail.com');
          hist.add('joeIBM', 'jjpecora@us.ibm.com');

       - Lookup elements like so:

          hist.lookup('joe');   // joepeck02@gmail.com

    4. Thats it!  Hack away.

*/

function History(hist_size) {

	// -----------------------
	//    Member Variables
	// -----------------------
	var DEFAULT_HISTORY_SIZE = document.getElementById('searchBar').getAttribute('results');
	this.max = (hist_size && hist_size > 0) ? hist_size : DEFAULT_HISTORY_SIZE;
	this.queue = [];
	this.table = {};

}


// -----------------------
//     Public Functions
// -----------------------

History.prototype.add = function(name, email) {

	// Return the index of an element if its in the list, -1 if not found
	function arrIndexOf(arr, elem) {
		for (var i=0; i<arr.length; i++) {
			if (arr[i] == elem) {
				return i;
			}
		}
		return -1;
	}

	// Drop out if it is already in the queue
	var idx = arrIndexOf(this.queue, name);
	if ( idx != -1 ) { return; }

	// Add to the back of the queue and into the table
	this.queue.push(name);
	this.table[name] = email;

	// Readjust the size, by deleting the oldest (front of the queue)
	// in order to keep the memory size bounded
	if ( this.queue.length > this.max ) {
		var oldest = this.queue.shift();
		delete this.table[oldest];
	}

}


//
// Function: lookup(name)
// Returns the email for the given name
//
History.prototype.lookup = function(name) {
	return this.table[name];
}
