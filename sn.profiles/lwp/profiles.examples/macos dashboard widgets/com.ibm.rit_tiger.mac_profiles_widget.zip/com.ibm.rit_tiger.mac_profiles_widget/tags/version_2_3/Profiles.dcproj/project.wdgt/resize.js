/*
  Functions for resizing the widget
  Author: Joseph Pecoraro
  Date: Wednesday July 16, 2008
*/

// -----------------------
//        Globals
// -----------------------
var isOpen = false;
var isDialog = false;
var wasClosed = false; // for dialogs only
var gSavedOpenWidth = 0;
var gSavedOpenHeight = 0;
var gBackWidth = 416;
var gBackHeight = 242;
var gMinWidth = 396;
var gMinHeight = 220;
var gCalculatedMinHeight = 396;
var gClosedWidth = 360;
var gClosedHeight = 50;
var growboxInset;


// -----------------------
//  Slide/Resize Handlers
// -----------------------

//
// Function: whatMustHappenWhenResizing(x, y)
// "Don't repeat yourself" - this function handles the changes
// to the innards of the widget whenever it is being resized.
// This is the single common function to handle these details.
// Think of totalWidth as (x) and totalHeight as (y)
//
function whatMustHappenWhenResizing(totalWidth, totalHeight) {

	// Handle elements in #face
	document.getElementById("middle").style.height = (totalHeight-73) + 'px'; // 43 = top, 30 = bottom
	document.getElementById("bottom").style.top = (totalHeight-30) + 'px'; // 30 = bottom
    window.resizeTo(totalWidth, totalHeight);
	
	// Handle resizing the auto-suggest dropdown if its visible
	setAutoSuggestWidth();

}


//
// Function: setAutoSuggestWidth()
// Adjusts the auto-suggest boxes' width
//
function setAutoSuggestWidth() {
	var boxes = getAutoCompleteBoxes();
	if ( boxes != null ) {
		var newWidth = (window.innerWidth-81) + 'px';
		boxes[0].style.width = newWidth;
		boxes[1].style.width = newWidth;
	}
}


//
// Function slideRectHandler(anim, curr, start, end)
// This function handles everything that must happen
// during an animation to the innards of the widget
//
function slideRectHandler(animation, curr, start, end) {
	whatMustHappenWhenResizing(curr.right, curr.bottom);
}


// -----------------------
//  AutoComplete Helper
// -----------------------

function getAutoCompleteBoxes() {
	var lst1 = document.getElementsByClassName('yui-ac-content');
	var lst2 = document.getElementsByClassName('yui-ac-shadow');
	return ( lst1.length > 0 ) ? [ lst1[0], lst2[0] ] : null;
}


// -----------------------
//  Preferences Animation
// -----------------------

//
// Function: resizeToPref
// Resizes the widget to the size for the back, then flips
// to the back.  The dimensions before flipped are saved.
//
function resizeToPref() {
	saveWidthAndHeight();
	genericSlide(gBackWidth, gBackHeight, 400, flipToBack);
}


//
// Function: resizeFromPref
// Resizes the widget to the size before flipping to the back
//
function resizeFromPref() {
	genericSlide(gSavedOpenWidth, gSavedOpenHeight, 400, null);	
}


//
// Function: flipToBack
// Default function to flip to the backside of the widget
//
function flipToBack() {

	// Configure the back (always revert to hiding the server textfield)
	hideServerFields();

    var front = document.getElementById("front");
    var back = document.getElementById("back");
 
	if (window.widget) {
		widget.prepareForTransition("ToBack");
 	}
		
    front.style.display="none";
    back.style.display="block";
 
    if (window.widget){
        setTimeout ('widget.performTransition();', 0);
		widget.setCloseBoxOffset(13,14);
    }
	
	// Update the front/back flag
	onBack = true;

}


//
// Function: flipToFront
// Default function to flip to the frontside of the widget
//
function flipToFront() {

    var front = document.getElementById("front");
    var back = document.getElementById("back");
	
	if (window.widget) {
		widget.prepareForTransition("ToFront");
 	}

    back.style.display="none";
    front.style.display="block";
	
    if (window.widget) {
        setTimeout ('widget.performTransition();', 0);
		widget.setCloseBoxOffset(7,9);
	}
	
	// Once the flip to the front is complete, flipToFront resizes the widget back to its former size.
	setTimeout("resizeFromPref()", 750);
	
	// Update the front/back flag
	onBack = false;
    
    // Save all the items on the back ( non-volatile, even after restart )
    storePreferences();
	storeServerUrl();
	
	// Get the user information and eventually their colleague list
	getUserInfo( retrievePreference( 'username' ), ongetinfo );
    
    // Check if there's a username
    checkLoggedIntoAdium();
}


// -----------------------
//    Resize Functions
// -----------------------


function mouseDown(event) {
    document.addEventListener("mousemove", mouseMove, true);
    document.addEventListener("mouseup", mouseUp, true);
    growboxInset = {x:(window.innerWidth - event.x), y:(window.innerHeight - event.y)};
    event.stopPropagation();
    event.preventDefault();
}
 
function mouseMove(event) {

	// setup
	if ( event.x == -1 ) return;
	var x = event.x + growboxInset.x;
    var y = event.y + growboxInset.y;
 
	// min width and height
	if(x < gMinWidth) x = gMinWidth;
	if(y < gCalculatedMinHeight) y = gCalculatedMinHeight;

	// resize - this is the important part that handles the widget's
	whatMustHappenWhenResizing(x,y);
 
	// make this the sole handler
    event.stopPropagation();
    event.preventDefault();

}

function mouseUp(event) {
	saveWidthAndHeight(); // Prevent any sliding to lose the new width/height
    document.removeEventListener("mousemove", mouseMove, true);
    document.removeEventListener("mouseup", mouseUp, true); 
    event.stopPropagation();
    event.preventDefault();
}


// -------------------------
//    Hide/Show Functions
// -------------------------

function showBottomElems() {
	document.getElementById('middle').style.display = 'block';
	document.getElementById('bottom').style.display = 'block';
	document.getElementById('resize').style.display = 'block';
	document.getElementById('top-left').style.backgroundPositionY = '-71px';
	document.getElementById('top-right').style.backgroundPositionY = '-68px';
	document.getElementById('top-middle').style.backgroundPositionY = '-57px';
}

function hideBottomElems() {
	document.getElementById('top-left').style.backgroundPositionY = '-5px';
	document.getElementById('top-right').style.backgroundPositionY = '-6px';
	document.getElementById('top-middle').style.backgroundPositionY = '0px';
	document.getElementById('middle').style.display = 'none';
	document.getElementById('bottom').style.display = 'none';
	document.getElementById('resize').style.display = 'none';
}

function showFrontElems() {
	document.getElementById('face').style.display = 'block';
	document.getElementById('chatIcon').style.display = 'block';
}

function hideFrontElems() {
	document.getElementById('face').style.display = 'none';
	document.getElementById('chatIcon').style.display = 'none';
}


// -------------------------
//  Slide Up/Down Functions
// -------------------------


//
// Function: saveWidthAndHeight
// Used to set the globals that "remember" the size of the widget
// before a resize in case it needs to be resized back later
//
function saveWidthAndHeight() {
	gSavedOpenWidth = window.innerWidth;
	gSavedOpenHeight = window.innerHeight;
}


//
// Function: isMinSize()
// For convenience many widget actions are immediate when it is in the min size
//
function isMinSize() {
  return (window.innerWidth == gMinWidth && window.innerHeight == gCalculatedMinHeight) ? true : false;
}


//
// Function: triggerSlideDown
// Slides down and once complete it shows the front elements
//
function triggerSlideDown(event) {
	var afterSlide = function() {
		showFrontElems();
		isOpen = true;
		slideLower();
	};
	if ( !isOpen ) { window.resizeTo(gClosedWidth, gClosedHeight); }
	( isOpen && isMinSize() ) ? afterSlide() : slideDown(afterSlide);
}


//
// Function: triggerSlideUp
// Slides up and once complete it hides the bottom elements
//
function triggerSlideUp(event) {
	slideUp(function() {
		hideBottomElems();
		isOpen = false;
	});
}


//
// Function: slideUp(callback)
// Shows the bottom elements and slides down
// NOTE: You should use triggerSlideDown()
//
function slideDown(completeCallback) {
	showBottomElems();
	gCalculatedMinHeight = gMinHeight;
	genericSlide(Math.max(gMinWidth,gSavedOpenWidth), Math.max(gMinHeight,gSavedOpenHeight), 300, completeCallback);
}


//
// Function: slideLower
// The text might overflow the content area...
// So using the scrollHeight attribute we can
// resize it a little lower!
//
function slideLower() {
	var CONSTANT_OFFSET = 105; // entire height of the widget (window) - minimum height of #content
	content = document.getElementById('content');
	gCalculatedMinHeight = Math.max(document.getElementById('content').scrollHeight+CONSTANT_OFFSET, gMinHeight);
	genericSlide(Math.max(gMinWidth,gSavedOpenWidth), Math.max(gCalculatedMinHeight,gSavedOpenHeight), 100, null);
}


//
// Function: slideUp(callback)
// Hides the elements on the front and slides up
// NOTE: You should use triggerSlideUp()
//
function slideUp(completeCallback) {
	hideFrontElems();
	saveWidthAndHeight();
	genericSlide(gClosedWidth, gClosedHeight, 300, completeCallback);
}


//
// Function: genericSlide(width, height, ms, callback)
// This resizes (without bounds checking) from the current widget's size
// to the given width and height, over the given number of milliseconds,
// calling the given callback once completed.
// NOTE: You must check your bounds if you want this to resize to the minSize
//
function genericSlide(w, h, ms, completeCallback) {
	if (completeCallback == null) { completeCallback = function(){}; }
	var startingRect = new AppleRect (0, 0, window.innerWidth, window.innerHeight);
	var finishingRect = new AppleRect (0, 0, w, h);
	var currentRectAnimation = new AppleRectAnimation( startingRect, finishingRect, slideRectHandler );
	var currentAnimator = new AppleAnimator (ms, 12);
	currentAnimator.addAnimation(currentRectAnimation);
	currentAnimator.oncomplete = completeCallback;
	currentAnimator.start();
}
