/*
  Trigger Dialogs and Fade animations. 
  Author: Steve Willard
  Author: Joseph Pecoraro
  Date: Thursday July 17, 2008
*/


// -----------------------
//       Constants
// -----------------------
var DIALOG_UPDATE           = 0;
var DIALOG_CHAT_NO_LOGIN    = 1;
var DIALOG_CHAT_NO_INSTALL  = 2;
var DIALOG_CHAT_BAD_VERSION = 3;
var DIALOG_COLLEAGUE        = 4;
var DIALOG_INVITE           = 5;

// -----------------------
//    Trigger Functions
// -----------------------

//
// Function: triggerToDialog
// Handles all cases of resizing to a dialog and showing the dialog
// This should be called whenever you want to trigger a dialog
//
function triggerToDialog(state) {

	// Closure to perform the dialog logic, not resize logic (same for all cases)
	var work = function() {
		isOpen = true;
		showDialog(state);
		isDialog = true;
	}
	
	// Closed or Min Size - both resize to min and display the dialog
	if ( !isOpen ) {
		wasClosed = true;
		gSavedOpenWidth = 0;
		gSavedOpenHeight = 0;
		slideDown( function() {
			showFrontElems();
			work();
		});
	}
	
	// Already Open
	else {
	
		// Already Min Size - show dialog
		// Not Min Size - Resize to min and show dialog
		saveWidthAndHeight();
		if ( isMinSize() ) {
			work();
		} else {
			genericSlide(gMinWidth, gMinHeight, 300, work);
		}
	}
}


//
// Function: triggerFromDialog
// Returns the widget to its expected size from a dialog
//
function triggerFromDialog() {

	// Prevent flickering
    if ( !checkAction() ) {
        return false;
    }

	// Set the global flag for dialogs, hide the dialog and return to the original state
    isDialog = false;
    hideDialog(function() {
        if ( wasClosed ) {
            triggerSlideUp();
            wasClosed = false;
        } else {
            genericSlide(Math.max(gSavedOpenWidth, gMinWidth), Math.max(gSavedOpenHeight, gMinHeight), 300, null);
        }
    }); 
    
    return true;
}


//
// Function: checkAction
// Make sure the user can't spam any of the dialog controls
// True  -> Everything is good, disable the buttons now
// False -> Something is already happening, don't do anything
//
function checkAction() {
    if ( !actionTaken ) {
        actionTaken = true; 
        setTimeout( 'actionTaken = false;', 1500 );
        return true;
    } else {
        return false;
    }
}


// -----------------------
//    Display Functions
// -----------------------

function showDialog(state) {

	var dialog = document.getElementById('dialog');
	var dialogWindow = null;
	switch(state) {
	case DIALOG_UPDATE:
		dialogWindow = document.getElementById('dialogUpdate');
		break;    
	case DIALOG_CHAT_NO_LOGIN:
		dialogWindow = document.getElementById('dialogAdiumNoLogin');
		break;
	case DIALOG_CHAT_NO_INSTALL:
		dialogWindow = document.getElementById('dialogAdiumNoInstall');
		break;
	case DIALOG_CHAT_BAD_VERSION:
		dialogWindow = document.getElementById('dialogAdiumBadVersion');
		break;
	case DIALOG_COLLEAGUE:
		dialogWindow = document.getElementById('dialogColleague');
		break;
	case DIALOG_INVITE:
		dialogWindow = document.getElementById('dialogInvite');
		break;
	default:
		//alert('Inside showDialog()... should never get here! breaking');
		return;
	}
	
	dialog.style.opacity = '0.0';
	dialog.style.visibility = 'visible';
	dialogWindow.style.visibility = 'visible';
	fadeIn(document.getElementById('dialog'));
	
}

function hideDialog(callback) {
	fadeOut(document.getElementById('dialog'), function() {
		document.getElementById('dialog').style.visibility = 'hidden';
		[ 'dialogUpdate',
		  'dialogAdiumNoLogin',
		  'dialogAdiumNoInstall',
		  'dialogAdiumBadVersion',
		  'dialogColleague',
		  'dialogInvite' ].forEach(function(id) {
			document.getElementById(id).style.visibility = '';
		});
		callback();
	});
}

function fadeIn(elem, callback) {
	if ( callback == null ) { callback = function(){}; }
	var fadeHandler = function(a, c, s, f) { elem.style.opacity = c; };
	var anim = new AppleAnimator(1000, 13, 0.0, 1.0, fadeHandler);
	anim.oncomplete = callback;
	anim.start();
}

function fadeOut(elem, callback) {
	if ( callback == null ) { callback = function(){}; }
	var fadeHandler = function(a, c, s, f) { elem.style.opacity = c; };
	var anim = new AppleAnimator(1000, 13, 1.0, 0.0, fadeHandler);
	anim.oncomplete = callback;
	anim.start();
}	