// Globals
var FEED_URL        = '/atom/search.do?email=';
var PROFILE_URL     = '/html/profileView.do?uid=';
var TYPEAHEAD_URL   = '/html/nameTypeahead.do?name=';
var FRIEND_URL      = '/atom/colleagues.do?ps=50&output=hcard&key=';
var PENDING_URL     = '/atom/colleagues.do?ps=50&output=hcard&status=pending&key=';
var FRIEND_REQ_URL  = '/xml/friendrequest';
var USER_URL        = '/atom/profile.do?output=hcard&email=';
var ADDR_GROUP      = 'IBM';


var autoComplete    = null;
var blogLink        = null;
var connLink        = null;
var hist            = null;
var httpFeedRequest = null;
var resultsArray    = null;
var serverError	    = null;
var updateObject    = null;
var onBack          = false;
var noPerson        = true;
var skipVersion     = -1.0;

// Namespaces
var NS_IMAGE  = "http://www.ibm.com/xmlns/prod/sn/image";
var NS_XHTML  = "http://www.w3.org/1999/xhtml";

//
// Function: globalkey
// Add a global key handler
//
function globalKey(e) {
	var key = e ? e.which : window.event.keyCode;
	switch ( key ) {
		// Return
		case 13:
			if ( onBack ) flipToFront();
			break;
	}
}


//
// Function: globalClick
// Add a global click handler
//
function globalMouse(e) {
	if ( !onBack && !isDialog ) {
		goToSearchBar();
	}
}

// Setup global key handler
document.onkeypress = globalKey;
if (document.layers) document.captureEvents(Event.KEYPRESS);

// Setup global click handler
document.onclick = globalMouse;


//
// Function: psuedoSearch(hashedName)
// Makes the translation between a name and email for makeRequest
// using the searchHistory hash table.  Won't run a search
// on a blank name.
//
function psuedoSearch(hashedName) {
	if ( hashedName && hashedName.length > 0 ) {
		makeRequest( hist.lookup(hashedName) );
	}
}


//
// Function: makeRequest(searchEmail)
// Sends the search request and processes it
//
function makeRequest( searchEmail ) {
	searchEmail = trim( searchEmail );

	// Abort any pending request before starting a new one
	if (httpFeedRequest != null) {
		httpFeedRequest.abort();
		httpFeedRequest = null;
	}
	
	// Generate the search URL
	document.getElementById("searchBar").value = searchEmail;
	var searchUrl = retrievePreference( 'server' ) + FEED_URL + searchEmail;

	// The XMLHttpRequest
	httpFeedRequest = new XMLHttpRequest();
	httpFeedRequest.overrideMimeType("text/xml");
	httpFeedRequest.open("GET", searchUrl);
	httpFeedRequest.setRequestHeader("Cache-Control", "no-cache");
	httpFeedRequest.onload = function (xml) {

		// Not successful
		if ( httpFeedRequest.status != 200 ) {
			serverError = true;
			return;
		}

		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( httpFeedRequest.responseXML ) feedRootElement = httpFeedRequest.responseXML.documentElement;

		// Destory the XMLHttpRequest
		httpFeedRequest = null;
		
		// Process the Feed
		resultsArray = parseAtomFeed(feedRootElement, searchEmail);
		
		// Show in the GUI the first result
		if ( resultsArray.length > 0 && !serverError ) {
			setContent(resultsArray[0].name, resultsArray[0].content, resultsArray[0].imgUrl, resultsArray[0].colleagueState);
			
            //Found a person
            noPerson = false;

            document.getElementById("img").style.opacity = 100;
            
			//Show these icons
			document.getElementById("addressBookIcon").style.display = "inline";
			document.getElementById("vcardIcon").style.display = "inline";
			document.getElementById("blogIcon").style.display = "inline";
			
			//Set the cursors
			document.getElementById("addressBookIcon").style.cursor = "pointer";
			document.getElementById("vcardIcon").style.cursor = "pointer";
            
		} else {
        
            //Reset the icons
			setContent("No Person", "Sorry...", null, null);
            document.getElementById("img").style.opacity = 0;
			noPerson = true;
			
			//Hide these icons
			document.getElementById("addressBookIcon").style.display = "none";
			document.getElementById("vcardIcon").style.display = "none";
			document.getElementById("blogIcon").style.display = "none";
			
			//Reset the cursors
			document.getElementById("addressBookIcon").style.cursor = "default";
			document.getElementById("vcardIcon").style.cursor = "default";
			document.getElementById("blogIcon").style.cursor = "default";
		}
		
		// Start sliding down after content as been set
		// This is because slideLower() requires that #content be VISIBLE for scrollHeight to be set.
		triggerSlideDown();
	}
	
	// Set Loading display and send the request
	clearContent();
	httpFeedRequest.send(null);

}

//
// Function: clearContent
// Hides the img, the content, and displays loading in the text 
//
function clearContent() {
	document.getElementById("text").innerHTML = "Loading...";
	document.getElementById("content").innerHTML = "";
	document.getElementById("img").style.opacity = 0;
	document.getElementById("chatIcon").style.opacity = 0;
	document.getElementById("addressBookIcon").style.opacity = 0;
	document.getElementById("vcardIcon").style.opacity = 0;
	document.getElementById("blogIcon").style.opacity = 0;
	document.getElementById("blogIcon").style.cursor = 'default';
}

//
// Function: setContent
// Helper function to easily set the image and text
//
function setContent(name, content, imgUrl, colleagueState) {
	
	// Name
	document.getElementById("text").innerHTML = name;
	
	// Content
	// I assume spans[1] because spans[0] should be the "vcard" span
	// and anything that comes back with spans.length < 1 is ignored
	var contentElem = document.getElementById("content");
	contentElem.innerHTML = content;

	// Image
	var img = document.getElementById("img");
	img.src = imgUrl;
	img.style.opacity = 100;

	// Icons
	if ( !serverError ) {

		// Make the colleague text clickable if the person is not a colleague
		if ( colleagueState == FRIEND_NO ) {
			document.getElementById('inviteName').innerHTML = resultsArray[0].name;
			var col = document.getElementById('colleague');
			col.style.cursor = 'pointer';
			col.onmouseover = function() { col.style.color = 'rgb(81, 106, 139)'; col.style.textDecoration = 'underline'; col.style.cursor = 'pointer'; };
			col.onmouseout  = function() { col.style.color = 'rgb(31, 56, 89)'; col.style.textDecoration = 'none'; };
			col.onclick     = function() { triggerToDialog(DIALOG_INVITE); };
		}

		noPerson = false;
		document.getElementById( 'blogIcon' ).onclick = function() { widget.openURL(blogLink); };
		document.getElementById( 'addressBookIcon' ).style.opacity = 1;
		document.getElementById( 'vcardIcon' ).style.opacity = 1;
		checkLoggedIntoAdium();

		blogElem = document.getElementById( 'blogIcon' );    
		if ( blogLink != '#' ) {
			blogElem.style.opacity = 1;
			blogElem.style.cursor = 'pointer';
		} else {
			blogElem.style.opacity = 0.3;
			blogElem.style.cursor = 'default';
		}
	}

}

//
// Function: checkLoggedIntoAdium
// Checks to make sure the username is a valid email and that a person is being displayed
// If so, enable the chat icon.
//
function checkLoggedIntoAdium() {
    var good  = ( checkEmail( retrievePreference( 'username' )) && !noPerson ) ? true : false;
    document.getElementById( 'chatIcon' ).style.opacity = good ? 1.0 : 0.3;
    document.getElementById( 'chatIcon' ).style.cursor = good ? 'pointer' : 'default';
    return good;
}

//
// Function: parseAtomFeed(atom, email)
// Parses the Atom feed into an array of Person objects.
// Returns the parsed results array.
//
function parseAtomFeed(atom, email) {
	var results = new Array;

	// For each element, get title, link, etc.
	for (var item = atom.firstChild; item != null; item = item.nextSibling) {
		if (item.nodeName == "entry") {

			// Get the Name
			var name = atomTextToHTML(findChild(item, "title"));
			name = name.innerHTML;
            
            // Special Easter Egg Checks to fix the authors all caps names!
            if ( name.match(/steve willard/i) )      { name = 'Steve Willard'; }
			if ( name.match(/joseph j. pecoraro/i) ) { name = 'Joseph pecoraro'; }

			// Get the content, this holds the vcard
			var content = atomTextToHTML( findChild(item, 'content' ));

			// Phone Number - 'tel'
			var tel = content.getElementsByClassName('tel')[0];
			if (!tel.children[1].innerHTML.match(/\d/)) { 
				tel.style.display = 'none';
			} else {
				content.getElementsByClassName('tel')[0].firstChild.innerHTML = "Phone: ";
			}
					
			// Setup the blog link (which for some reason must be set later)
			var blogUrls = content.getElementsByClassName('x-blog-url');
			if ( blogUrls && blogUrls.length > 0 ) {
				blogLink = blogUrls[0].href;
			} else {
				blogLink = "#";
			}
			
			// Hide the role if it is the default "IBM employee, Regular"
			var role = content.getElementsByClassName('role')[0];
			if ( role.innerHTML.match( /IBM employee, Regular/i ) ) {
				role.style.display = 'none';
			}
			
			// Rewrite the content variable to instead be the string of
			// HTML it contains (for when we create the person object below)
			content = content.innerHTML;

			// Get the image url and connLink
			var imgUrl;
			var allLinks = findChildren(item, "link");
			for (var i = 0; i < allLinks.length; i++) {
				var rel = allLinks[i].getAttribute("rel");
				if (rel == NS_IMAGE) {
					imgUrl = allLinks[i].getAttribute("href");
					break;
				} else if ( rel == 'related' ) {
					connLink = allLinks[i].getAttribute("href")
				}
			}

			// Get the key from the connLink
			var key = getUrlValue(connLink, 'key');
            
			// Add to colleague
			var colleagueState = getFriendStatus(email);
			var colleagueStr = '<span id="colleague">';
			if ( colleagueState == FRIEND_YES ) {
				colleagueStr  = '<img id="colleagueImg" src="Images/person.png">' + colleagueStr;
				colleagueStr += 'My Colleague';
			} else if ( colleagueState == FRIEND_PEND ) {
				colleagueStr += 'Awaiting Colleague Confirmation';
			} else {
				colleagueStr += 'Invite to My Colleagues';
			}
			colleagueStr += '</span><br><br>';
			content = colleagueStr + content;

			// Add to the results array
			results.push({
				email: email,
				name: name,
				content: content,
				imgUrl: imgUrl,
				key: key,
				colleagueState: colleagueState
			});

			// ---------------------------
			//   Remove this break if
			//   you want all results
			//   and not just the first.
			// ---------------------------
			break;

		}
	}
	
	return results;
}

//
// Function: load()
// Called by HTML body element's onload event when the widget is ready to start
//
function load() {

	// Debug
	// alert( wau_get_version() );

	// Make use of BPACAutoComplete (but it really uses the connections server)
	autoComplete = new BPACAutoComplete("searchBar");
	
	// History Manager
	hist = new History();
		
	// Setup all the elements on the widget
	dashcode.setupParts();
	document.getElementById('middle').style.display = 'none';
	document.getElementById('bottom').style.display = 'none';
    
	slideUp(function() {
		gSavedOpenWidth = gMinWidth;
		gSavedOpenHeight = gMinHeight;
		isOpen = false;
	});

	// Preferences on the back (this could exist if the user removes and re-adds the widget)
	document.getElementById('username').value = retrievePreference('username');
	document.getElementById('password').value = retrievePreference('password');
	document.getElementById('server').value = retrievePreference('server');
	
	// Get User Info
	getUserInfo( retrievePreference( 'username' ), ongetinfo );
	
	// Create the info and done buttons
	new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "white", "white", resizeToPref);
	new AppleGlassButton(document.getElementById("doneButton"), "Done", flipToFront);
	new AppleGlassButton(document.getElementById("updateButton"), "Check for Update", manualCheckUpdate);
	new AppleGlassButton(document.getElementById("feedbackButton"), "Feedback", giveFeedback);
	
	// Dynamic Texts
	document.getElementById('tVersion').innerHTML = 'v'+ wau_get_version();
	document.getElementById('inviteText').innerHTML = 'Invite <span id="inviteName">-</span> as a Colleague?';
	document.getElementById('adiumNoInstallText').innerHTML = 'Click <a href="javascript:widget.openURL(\'http://beta.adiumx.com/\');">here</a> to install Adium.';
	document.getElementById('adiumBadVersionText').innerHTML ='You need at least <a href="javascript:widget.openURL(\'http://beta.adiumx.com/\');">Version 1.3</a> of Adium to use the <img src="Images/chatOnIcon.png">Chat feature.';

}

function ongetinfo() { populateColleagues(user.key); }
function remove() { }
function hide() {}
function sync() {}

var firstTimeEver = true;
function show() {

	// First time ever... give us a second (literally)
	if ( firstTimeEver ) {
		firstTimeEver = false;
		setTimeout(show, 1000);
		return;
	}
	
	// Check friends list (limit of one check per hour)
	if ( ( (new Date).getTime() - lastFriendReq ) > TIMEOUT_BETWEEN_FRIEND_REQ ) {
		populateColleagues(user.key);
	}

	// Check for an update!
	if ( !onBack && !isDialog ) { checkForUpdate(); }

	// Check Adium
    checkLoggedIntoAdium();

}

// Initialize the Dashboard event handlers
if (window.widget) {
    widget.onremove = remove;
    widget.onhide = hide;
    widget.onshow = show;
    widget.onsync = sync;
}
