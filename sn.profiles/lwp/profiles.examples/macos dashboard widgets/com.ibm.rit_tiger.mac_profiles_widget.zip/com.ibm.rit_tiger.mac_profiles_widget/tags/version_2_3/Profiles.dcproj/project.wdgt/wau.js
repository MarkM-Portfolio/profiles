/*
  Widget Auto-Updater (WAU) for a Widget with Shell Access

  Author: Joseph Pecoraro
  Author: Steve Willard
  Date: Thursday June 19, 2008
  Description:

    A server contains an XML or JSON file listing versions of
    the widget, a description of the changes since the previous
    version, and finally a link to download that version of
    the widget.  By checking that XML file periodically
    you can detect a change, display to the user what has
    updated, and download the widget for the user.

    This script includes a simple function to call that will
    check the server for an update and download the updated
    file to the desktop for the user.  It also allows other
    developers to override this "default" behavior so that
    they may include widget specific behavior.  For instance
    displaying a message to the user on their widget's face.

  XML Format:
  -----------

  <?xml version="1.0" encoding="UTF-8"?>
  <updates>
    <widget>
      <version>1.1</version>
      <date>1213881217085</date>
      <url>http://bogojoker.com/widgets/widget1-1.wdgt</url>
      <desc>Now a chance to win the lottery!</desc>
    </widget>
    <widget>
      <version>1.0</version>
      <date>1213881215015</date>
      <url>http://bogojoker.com/widgets/widget1-0.wdgt</url>
      <desc>Initial Release</desc>
    </widget>
  </updates>


  JSON Format:
  -----------

  {
    "updates": [
      {
        "version": 1.1,
        "date": 1213881217085,
        "url": "http://bogojoker.com/widgets/widget1-1.wdgt",
        "desc": "Now a chance to win the lottery"
      },
      {
        "version": 1.0,
        "date": 1213881215015,
        "url": "http://bogojoker.com/widgets/widget1-0.wdgt",
        "desc": "Initial Release"
      }
    ]
  }


  Description of Format:
  ----------------------

    - All tags/properties are required
    - in JSON there must be an 'updates' Array
    - The Version number is a decimal/float value
    - Date is a Unix Timestamp as an Integer
    - The url and desc tags/properties are strings


  How To Use:
  -----------

    1. Include the wau.js file:

       <script type="text/javascript" src="wau.js"></script>

    2. Set the widget version in your Widget Attributes

    3. Edit these values to point to your server with the XML
       and JSON files that you have made according to the
       above formats.  Hosting only 1 file is fine just make
       sure that WAU_USE_JSON is true or false to point to
       the one you support.

*/

      // -----------------------
      //   User Defined Values
      // -----------------------
      var WAU_HOST = 'http://ibmrit.bluehost.ibm.com/widget_auto_update/';
      var WAU_JSON_FILE = 'profiles_widget.json';
      var WAU_XML_FILE = 'profiles_widget.xml';
      var WAU_USE_JSON = true;

/*

    4. When you want your widget to check for updates simply
       call wau_check_for_update().  If you would like to
       provide a callback you may for any of these events:

       New Update:      function(updateObject)
       No New Update:   function()
       Error Occurred:  function()

       For the New Update function you must pass in an object
       with the same format as the JSON objects above.  Also
       you may make use of wau_download() which uses curl
       to download from the given url to the local harddrive.

    5. Thats it!  The user can then install the new widget.

*/


// -----------------------
//    Member Variables
// -----------------------
var WAU_USER_HOME = widget.system('echo "$HOME"', null).outputString.replace(/\n/,'');
var WAU_DOWNLOAD_PATH = WAU_USER_HOME + '/Desktop/';
var wau_new_update_callback = null;
var wau_regular_callback = null;
var wau_error_callback = null;
var wau_request = null;
var wau_widget_version = null;


// -----------------------
//    Public Functions
// -----------------------

function wau_get_version() {
    return wau_widget_version;
}

function wau_check_for_update(newUpdateCallback, regularCallback, errorCallback) {

	// Default callbacks
	wau_new_update_callback = (newUpdateCallback) ? newUpdateCallback : wau_def_new_update_callback;
	wau_regular_callback = (regularCallback) ? regularCallback : wau_def_regular_callback;
	wau_error_callback = (errorCallback) ? errorCallback : wau_def_error_callback;

	// Setup an AJAX Request
	if ( wau_request != null ) { wau_request.abort(); }
	wau_request = new XMLHttpRequest();
	wau_request.onerror = wau_error_callback;
	wau_request.setRequestHeader( 'Cache-Control', 'no-cache' );

	// XML / JSON
	if ( WAU_USE_JSON ) {
		wau_request.open('GET', WAU_HOST + WAU_JSON_FILE);
		wau_request.onload = wau_process_json;
	} else {
		wau_request.open('GET', WAU_HOST + WAU_XML_FILE);
		wau_request.onload = wau_process_xml;
	}

	// Send
	wau_request.send(null);

}

function wau_download(url, savePath) {

	// Download to the given path
	url = url.replace(/'/,"\\'"); //'"
	savePath = "'" + savePath.replace(/'/,"\\'") + "'"; //'
	var cmd = "curl '" + url + "' -o " + savePath;
	widget.system(cmd, function() {

		// Function to use finder to open an run the new .wdgt file
		var quoted_desktop = "'" + WAU_DOWNLOAD_PATH.replace(/'/, "\\'") + "'"; //';
		function openWdgt() {
			widget.system('open ' + quoted_desktop + '*.wdgt; ' + 'rm ' + savePath, null);
		}

		// Extract and open (many different possible formats)
		if ( savePath.match(/\.(jar|zip)'$/) ) { // (most likely)   //' .jar, .zip        =>  unzip FILE
			widget.system('unzip -o ' + savePath + " -x '__MACOSX*' '*.svn*' -d " + quoted_desktop, openWdgt)
		}

		/*
		// Possible formats to support in the future.
		} else if ( savePath.match(/\.(tar\.bz2|tbz2)'$/ ) ) {      //' .tar.bz2, .tbz2   =>  tar xjf FILE
			retCode = widget.system('tar xjf ' + savePath, null);
		} else if ( savePath.match(/\.(tar\.gz|tar\.Z|tgz)'$/ ) ) { //' .tar.gz, .tar.Z   =>  tar xzf FILE
			retCode = widget.system('tar xzf ' + savePath, null);
		} else if ( savePath.match(/\.tar'$/) ) {                   //' .tar              =>  tar xf FILE
			retCode = widget.system('tar xf ' + savePath, null);
		} else if ( savePath.match(/\.bz2'$/) ) {                   //' .bz2              =>  bunzip2 FILE
			retCode = widget.system('bunzip2 ' + savePath, null);
		} else if ( savePath.match(/\.gz'$/) ) {                    //' .gz               =>  gunzip FILE
			retCode = widget.system('gunzip ' + savePath, null);
		} else if ( savePath.match(/\.Z'$/) ) {                     //' .Z                =>  uncompress FILE
			retCode = widget.system('uncompress ' + savePath, null);
		}
		*/
		
	});

}


// -----------------------
//    Default Callbacks
// -----------------------

function wau_def_error_callback() {
	//alert('inside error callback... check connection or server path');
}

function wau_def_regular_callback() {
	//alert('inside regular callback... you have the latest version!');
}

function wau_def_new_update_callback(updateObject) {
	//alert('inside new_update callback... downloading to the your desktop');
	var url = updateObject.url;
	var fileName = url.substr(url.lastIndexOf('/')+1);
	var path = WAU_DOWNLOAD_PATH + fileName;
	wau_download(url, path);
}


// -----------------------
//    Private Functions
// -----------------------

function wau_pre_process() {
	//alert( 'WAU RESPONSE: ' + wau_request.status );
	if ( wau_request.status != 200 ) {
		wau_error_callback();
		return false;
	} else {
		return true;
	}
}

function wau_post_process(maxVersion, maxUpdateObject) {
	wau_request = null;
	if ( maxVersion > wau_widget_version ) {
		wau_new_update_callback(maxUpdateObject);
	} else {
		wau_regular_callback();
	}
}

function wau_process_json(event) {
	//alert('processing json');
	if ( wau_pre_process() == false ) {
		return;
	}

	// Eval to an Object
	var json = eval( '(' + wau_request.responseText + ')' );

	// Find the greatest version number
	var maxVersion = 0;
	var maxUpdateObject = null;
	for (var i=0; i<json.updates.length; i++) {
		var updateObject = json.updates[i];
		if ( maxVersion < updateObject.version ) {
			maxVersion = updateObject.version;
			maxUpdateObject = updateObject;
		}
	}

	// Callback based on if the maxVersion is greater then the current
	wau_post_process(maxVersion, maxUpdateObject);

}

function wau_process_xml(event) {
	//alert('processing xml');
	if ( wau_pre_process() == false ) {
		return;
	}

	// Root
	var root = null;
	if ( wau_request.responseXML ) {
		root = wau_request.responseXML.documentElement;
	} else {
		wau_error_callback();
	}

	// Find the greatest version number
	var maxVersion = 0;
	var maxUpdateObject = null;
	for (var widget = root.firstChild; widget != null ; widget = widget.nextSibling) {
		if ( widget.nodeName == 'widget' ) {
			var version = parseFloat(wau_get_child_data(widget, 'version'));
			if ( maxVersion < version ) {
				maxVersion = version;
				maxUpdateObject = {
					version: version,
					date: parseInt(wau_get_child_data(widget, 'date')),
					url: wau_get_child_data(widget, 'url'),
					desc: wau_get_child_data(widget, 'desc')
				};
			}
		}
	}

	// Callback based on if the maxVersion is greater then the current
	wau_post_process(maxVersion, maxUpdateObject);

}

function wau_get_child_data(elem, nodeName) {
	for (var child = elem.firstChild; child != null; child = child.nextSibling) {
		if ( child.localName == nodeName ) {
			var data = '';
			for (var node = child.firstChild; node != null; node = node.nextSibling) {
				if ( node.data ) { data += node.data; }
			}
			return data;
		}
	}
	return null;
}

// Used for getting the version number
function getKeyValue( plist, key ) {
	var xml_http = new XMLHttpRequest();
	xml_http.open( 'GET', plist, false );
	xml_http.send( null ); 

	var xml = xml_http.responseXML;
	var key_value = null;
	var nodes = xml.getElementsByTagName('dict')[0].childNodes; 

	for ( var i = 0; i < nodes.length; ++i ) {
		if ( nodes[i].nodeType == 1 && nodes[i].tagName.toLowerCase() == 'key' && nodes[i].firstChild.data == key ) {
        	if ( nodes[i+2].tagName.toLowerCase() != 'array' ) {
            	key_value = nodes[ i + 2 ].firstChild.data;
			} else {
            	key_value = new Array();
            	var ar_nodes = nodes[ i + 2 ].childNodes;
            	for ( var j=0; j < ar_nodes.length; ++j ) {
					if ( ar_nodes[j].nodeType == 1 ) { key_value.push( ar_nodes[j].firstChild.data ); }
            	}
        	}    
		break;
     	}
  	} 
	return key_value;
}

wau_widget_version = getKeyValue( 'Info.plist', 'CFBundleVersion' );