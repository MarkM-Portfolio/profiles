// Globals
var WIDGET_VERSION  = 2.0;

var SECURE_URL      = "https://profiles.tap.ibm.com/profiles";
var SERVER_URL      = 'http://profiles.tap.ibm.com/profiles';
var FEED_URL        = '/atom/search.do?email=';
var PROFILE_URL     = '/html/profileView.do?uid=';
var TYPEAHEAD_URL   = '/html/nameTypeahead.do?name=';
var FRIEND_URL      = '/atom/colleagues.do?ps=50&output=hcard&key=';
var FRIEND_REQ_URL  = '/xml/friendrequest';
var USER_URL        = '/atom/profile.do?output=hcard&email=';

var httpFeedRequest = null;
var blogLink        = null;
var connLink		= null;
var resultsArray    = null;
var serverError		= null;
var updateObject    = null;
var onBack          = false;
var noPerson		= false;
var skipVersion     = -1.0;

// Namespaces
var NS_IMAGE = "http://www.ibm.com/xmlns/prod/sn/image";

//
// Function: globalkey
// Add a global key handler
//
function globalKey(e) {
	var key = e ? e.which : window.event.keyCode;
	switch ( key ) {
        // Return
		case 13:
            if ( onBack ) flipToFront();
			break;
	}
}

// Setup global key handler
document.onkeypress = globalKey;
if (document.layers) document.captureEvents(Event.KEYPRESS);

//
// Function: makeRequest(searchEmail)
// Sends the search request and processes it
//
function makeRequest( searchEmail ) {
	searchEmail = trim( searchEmail );

    // Abort any pending request before starting a new one
    if (httpFeedRequest != null) {
        httpFeedRequest.abort();
        httpFeedRequest = null;
    }
	
	// Generate the search URL
	document.getElementById("searchBar").value = searchEmail;
	var searchUrl = SERVER_URL + FEED_URL + searchEmail;

	// The XMLHttpRequest
	httpFeedRequest = new XMLHttpRequest();
	httpFeedRequest.overrideMimeType("text/xml");
    httpFeedRequest.open("GET", searchUrl);
    httpFeedRequest.setRequestHeader("Cache-Control", "no-cache");
    httpFeedRequest.onload = function (xml) {

		// Not successful
		if ( httpFeedRequest.status != 200 ) {
			serverError = true;
			return;
		}

		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( httpFeedRequest.responseXML ) feedRootElement = httpFeedRequest.responseXML.documentElement;

		// Destory the XMLHttpRequest
		httpFeedRequest = null;
		
		// Process the Feed
		resultsArray = parseAtomFeed(feedRootElement);
		
		// Show in the GUI the first result
		if ( resultsArray.length > 0 && !serverError ) {
			setContent(resultsArray[0].name, resultsArray[0].content, resultsArray[0].imgUrl);
			
            //Found a person
            noPerson = false;
            document.getElementById("img").style.opacity = 100;
            
			//Show these icons
			document.getElementById("addressBookIcon").style.display = "inline";
			document.getElementById("vcardIcon").style.display = "inline";
			document.getElementById("blogIcon").style.display = "inline";
            //document.getElementById('buttonsBackground').style.display = 'inline';
			
			//Set the cursors
			document.getElementById("addressBookIcon").style.cursor = "pointer";
			document.getElementById("vcardIcon").style.cursor = "pointer";
            
		} else {
        
            //Reset the icons
			setContent("No Person", "Sorry...", null );
            document.getElementById("img").style.opacity = 0;
			noPerson = true;
			
			//Hide these icons
			document.getElementById("addressBookIcon").style.display = "none";
			document.getElementById("vcardIcon").style.display = "none";
			document.getElementById("blogIcon").style.display = "none";
            document.getElementById('buttonsBackground').style.display = 'none';
			
			//Reset the cursors
			document.getElementById("addressBookIcon").style.cursor = "default";
			document.getElementById("vcardIcon").style.cursor = "default";
			document.getElementById("blogIcon").style.cursor = "default";
		}

    }
	
	// Set Loading display and slide down
	clearContent();
	triggerSlideDown();
	
	// Send the request
    httpFeedRequest.send(null);

}

//
// Function: clearContent
// Hides the img, the content, and displays loading in the text 
//
function clearContent() {
	document.getElementById("text").innerHTML = "Loading...";
	document.getElementById("content").innerHTML = "";
	document.getElementById("img").style.opacity = 0;
	document.getElementById("chatIcon").style.opacity = 0;
	document.getElementById("addressBookIcon").style.opacity = 0;
	document.getElementById("vcardIcon").style.opacity = 0;
	document.getElementById("blogIcon").style.opacity = 0;
    document.getElementById("blogIcon").style.cursor = 'default';
}

//
// Function: setContent
// Helper function to easily set the image and text
//
function setContent(name, content, imgUrl) {
	
	// Name
	document.getElementById("text").innerHTML = name;
	
	// Content
	// I assume spans[1] because spans[0] should be the "vcard" span
	// and anything that comes back with spans.length < 1 is ignored
	var contentElem = document.getElementById("content");
	contentElem.innerHTML = content;

	document.getElementById("blogIcon").onclick = function() { widget.openURL(blogLink); };
	
	// Image
	var img = document.getElementById("img");
	img.src = imgUrl;
	img.style.opacity = 100;
	
	// Icons
	if( !serverError ) {
        // document.getElementById('buttonsBackground').style.opacity = 1;
		document.getElementById("addressBookIcon").style.opacity = 1;
		document.getElementById("vcardIcon").style.opacity = 1;
        checkLoggedIntoAdium();
        	
		if( noPerson != null && blogLink != "#" ) {
			document.getElementById("blogIcon").style.opacity = 1;
            document.getElementById("blogIcon").style.cursor = "pointer";
		} else {
			document.getElementById("blogIcon").style.opacity = 0.4;
            document.getElementById("blogIcon").style.cursor = "default";
		}
	}
}

function checkLoggedIntoAdium() {
    var email = checkEmail( document.getElementById( 'searchBar' ).value );
    var user  = retrievePreference( 'username' );
    var good  = ( user != '' && checkEmail( user ) && email ) ? true : false;
    document.getElementById( 'chatIcon' ).style.opacity = good ? 1.0 : 0.3;
    document.getElementById( 'chatIcon' ).style.cursor = good ? 'pointer' : 'default';
    
    return good;
}

//
// Function: parseAtomFeed(atom)
// Parses the Atom feed into an array of Person objects.
// Returns the parsed results array.
//
function parseAtomFeed(atom) {
	var results = new Array;

	// For each element, get title, link, etc.
	for (var item = atom.firstChild; item != null; item = item.nextSibling) {
		if (item.nodeName == "entry") {

			// Get the Name
			var name = atomTextToHTML(findChild(item, "title"));
			name = name.innerHTML;
			if (!name) {
				name = "No Name?";
			}
            
            // Special Easter Egg Checks to fix the authors all caps names!
            if ( name.match(/steve willard/i) )      { name = "Steve Willard"; }
			if ( name.match(/joseph j. pecoraro/i) ) { name = "Joseph Pecoraro"; }

			// Get the content, this holds the vcard
			var content = atomTextToHTML(findChild(item, "content"));

			// Phone Number - 'tel'
			var tel = content.getElementsByClassName('tel')[0];
			if (!tel.children[1].innerHTML.match(/\d/)) { 
				tel.style.display = 'none';
			} else {
				content.getElementsByClassName('tel')[0].firstChild.innerHTML = "Phone: ";
			}
					
			// Setup the blog link (which for some reason must be set later)
			var blogUrls = content.getElementsByClassName('x-blog-url');
			if ( blogUrls && blogUrls.length > 0 ) {
				blogLink = blogUrls[0].href;
			} else {
				blogLink = "#";
			}
			
			// Hide the role if it is the default "IBM employee, Regular"
			var role = content.getElementsByClassName('role')[0];
			if ( role.innerHTML.match( /IBM employee, Regular/i ) ) {
				role.style.display = 'none';
			}
			
			// Rewrite the content variable to instead be the string of
			// HTML it contains (for when we create the person object below)
			content = content.innerHTML;

            // Get the image url and connLink
            var imgUrl;
            var allLinks = findChildren(item, "link");
            for (var i = 0; i < allLinks.length; i++) {
                var rel = allLinks[i].getAttribute("rel");
                if (rel == NS_IMAGE) {
                    imgUrl = allLinks[i].getAttribute("href");
                    break;
                } else if ( rel == "related" ) {
                    connLink = allLinks[i].getAttribute("href")
                }
            }
            
			// Get the key from the connLink
            var key = getUrlValue(connLink, 'key');

			// Add to the results array
			results.push({
				name: name,
				content: content,
				imgUrl: imgUrl,
				key: key
			});
			
			// ---------------------------
			//   Remove this break if
			//   you want all results
			//   and not just the first.
			// ---------------------------
			break;

		}
	}
	
	return results;
}

//
// Function: load()
// Called by HTML body element's onload event when the widget is ready to start
//
function load() {
	
	// Setup all the elements on the widget
	dashcode.setupParts();
	document.getElementById('searchBar').style.zIndex = 200;
	document.getElementById('middle').style.display = 'none';
	document.getElementById('bottom').style.display = 'none';
	slideUp( function() {
		gSavedOpenWidth = gMinWidth;
		gSavedOpenHeight = gMinHeight;
		isOpen = false;
	});

	// Preferences on the back (this could exist if the user removes and re-adds the widget)
	document.getElementById('username').value = retrievePreference('username');
	document.getElementById('password').value = retrievePreference('password');
	document.getElementById('server').value = retrievePreference('server');
	getUserInfo( retrievePreference( 'username' ), ongetinfo );
	
	// Create the info and done buttons
	gInfoButton = new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "black", "black", resizeToPref);
	gDoneButton = new AppleGlassButton(document.getElementById("doneButton"), "Done", flipToFront);
	
	// Dialog Texts
	document.getElementById('adiumNoInstallText').innerHTML = 'Click <a href="javascript:widget.openURL(\'http://beta.adiumx.com/\');">here</a> to install Adium.';

}

function ongetinfo() { getFriendsList(user.key); }
function remove() { }
function hide() {}
function sync() {}

var firstTimeEver = true;
function show() {

	// First time ever... give us a second (literally)
	if ( firstTimeEver ) {
		firstTimeEver = false;
		setTimeout(show, 1000);
		return;
	}

	// Check for an update!
	if ( !onBack && !isDialog ) { checkForUpdate(); }

	// Check Adium
    checkLoggedIntoAdium();
}

// Initialize the Dashboard event handlers
if (window.widget) {
    widget.onremove = remove;
    widget.onhide = hide;
    widget.onshow = show;
    widget.onsync = sync;
}