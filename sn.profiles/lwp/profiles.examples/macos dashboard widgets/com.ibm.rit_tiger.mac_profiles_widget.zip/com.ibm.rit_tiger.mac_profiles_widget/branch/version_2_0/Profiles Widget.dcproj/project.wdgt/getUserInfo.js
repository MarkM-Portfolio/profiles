/*
  Code to get information about the current user
  Author: Joseph Pecoraro
  Date: Tuesday July 1, 2008
  
  Other scripts should know to access the global user
  variable for information about the current user. If
  it is not null there are two keys:
  
    key = Lotus Connections Profiles key (aka targetKey)
	email = Unique email address for the user  
*/

// -----------------------
//    Member Variables
// -----------------------
var user     = null;
var req_user = null;


// -----------------------
//    Public Functions
// -----------------------


//
// Function: getUserInfo
// Directly get the user information via email, also there
// is a callback for success and failure
//
// Example:
// http://profiles.tap.ibm.com/profiles/atom/profile.do?email=jjpecora%40us.ibm.com&output=hcard
//
function getUserInfo(email, successCallback, errorCallback) {
	
	// Abort any pending request before starting a new one
	if (req_user != null) {
		req_user.abort();
		req_user = null;
	}
	
	// Clear the current values
	user = {
		email: email,
		key: null
	};
	
	// Build the URL
	var url = SERVER_URL + USER_URL + encodeURIComponent(email);

	// Recreate the XMLHttpRequest()
	req_user = new XMLHttpRequest();
	req_user.overrideMimeType("text/xml");
	var loginString = Base64.encode('');
	req_user.setRequestHeader("Authorization", 'Basic ' + loginString);
	req_user.open("GET", url);
	req_user.setRequestHeader("Cache-Control", "no-cache");
	req_user.onerror = errorCallback;
	req_user.onload = function(xml) {
    
		// Debug
		alert('GET USER INFO RESPONSE: ' + req_user.status);

		// Bad Request
		if ( req_user.responseXML == null || req_user.status != 200) {
			alert('erroring out!');
			if ( errorCallback ) {
				errorCallback();
			}
			return;
		}
        
		// Get the root element (should be <feed> for an Atom Feed)
		var card = null;
		var root = null;
		if ( req_user.responseXML ) {
		
			// Find the <content> node of the <entry> and parse that as an HCard
			root = req_user.responseXML.documentElement;
			for (var entry = root.firstChild; entry != null; entry = entry.nextSibling) {
				if (entry.nodeName == "entry") {
					var content = findChild(entry, "content");
					if (content) {
						var card = parseHCard(content);
					}
				}
			}
					
		}
		
		// Set the key
		user.key = card ? card.key : null;
		
		// If there was a successCallback call that
		if ( successCallback ) {
			successCallback();
		}

	}
    
	// Grab me!
	req_user.send();

}
