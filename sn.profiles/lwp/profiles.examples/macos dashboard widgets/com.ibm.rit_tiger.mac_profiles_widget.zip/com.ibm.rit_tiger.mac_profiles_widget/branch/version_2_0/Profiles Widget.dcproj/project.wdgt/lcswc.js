/*
  Lotus Connections Shared Widget Cache (LCSWC) for a Widget with Shell Access

  Author: Joseph Pecoraro
  Date: Wednesday July 9, 2008
  Requires: wc.js (Widget Cache)
  Description:

    Once one widget has made a connection to the Connections
    server, they should store the /serviceconfigs URL in a shared
    cache for "Pre-Determination" of servers for other widgets
    that are installed in the future.

  Technical Problems:
  -------------------

    1. The cache is stale/old

       This can be solved by storing a URL to the last known
       working /serviceconfigs URL.

    2. The /serviceconfigs URL does not work

       The cache is erased and we should proceed as if there was
       no cache to begin with.  This would be the case where
       the cache has turned stale.


  Notes of Interest:
  ------------------

  This script includes a stand-alone version of the 'Widget Cache'
  script.  It should be noted that if there is a future version of
  the 'Widget Cache' script that handles any major issue, that
  this script should include that as well.

  In-order to not cause any naming conflicts this script
  encapsulates everything within a "LCSWC" object.  This is common
  "object oriented" practice emulated in Javascript.


  How To Use:
  -----------

    1. Include the wc.js and lcswc.js files:

         <script type="text/javascript" src="wc.js"></script>
         <script type="text/javascript" src="lcswc.js"></script>

    2. If you need to grab the /serviceconfigs call:

         LCSWC.pull(callback)

       This attempts to use the cached URL. The single parameter,
       "callback", is a callback function and is invoked after the
       request to the url has returned.  A single boolean is passed
       to the callback function: true if everything worked and the
       LCSWC datastructures are set, false otherwise.

    3. If there is no cached URL the user should use:

         LCSWC.set(url, callback)

       This will test the given url just like above.  In the case of
       a successful request the url is cached automatically.

       You can always check if a url is cached by calling:

         LCSWC.exists()

    4. On a successful pull (or set) get the component you want using:

         LCSWC.get(component)

       Known Components are:

         activities             blogs
         communities            dogear
         homepage               personTag
         profiles

*/

// Namespace
var LCSWC = (function() {


	// -----------------------
	//    Member Variables
	// -----------------------
	var LCSWC_CACHE_NAME = 'url';
	var lcswc_cache      = new WC('LotusConnectionsSharedCache');
	var lcswc_request    = null;
	var lcswc_data       = {};


	// -----------------------
	//    Private Functions
	// -----------------------

	function get_component_data(component) {
		return lcswc_data[component] == undefined ? null : lcswc_data[component];
	}

	function wipe_bad_cache_url() {
		lcswc_cache.wipe(LCSWC_CACHE_NAME);
	}

	function set_cache_url(url) {
		lcswc_cache.cache(LCSWC_CACHE_NAME, url);
	}

	function default_callback(bool) {
		alert( bool ? 'LCSWC PULL SUCCEEDED' : 'LCSWC PULL FAILED' );
	}


	// -----------------------
	//  Update the Cached URL
	// -----------------------

	function update_url(url, user_callback) {

		// Default callback and save the old URL
		if ( user_callback == null ) { user_callback = default_callback; }

		// Add /serviceconfigs if needed
		if ( url != null && !url.match(/\/serviceconfigs$/) ) {
			var str = 'serviceconfigs';
			url += (url.match(/\/$/)) ? str : '/' + str;
		}

		// Cache the above URL if successful
		pull_service_configs(url, function(bool) {
			if (bool) {
				lcswc_cache.cache(LCSWC_CACHE_NAME, url);
			}
			user_callback(bool);
		});

	}


	// -----------------------
	//      Make Request
	// -----------------------

	function pull_with_cached_url(callback) {

		// Use the cached URL
		var url = lcswc_cache.fetch(LCSWC_CACHE_NAME);

		// Default callback
		if ( callback == null ) { callback = default_callback; }

		// Wrap the callback to wipe the cache if it fails
		function wipe_callback(bool) {
			if ( bool === false ) {
				wipe_bad_cache_url();
			}
			callback(bool);
		}

		// Call the advanced pull
		pull_service_configs(url, wipe_callback);

	}


	// -----------------------
	//    Advanced Request
	// -----------------------

	function pull_service_configs(url, callback) {

		// Check params
		if ( callback == null ) { callback = default_callback; }
		if ( url === null ) {
			callback(false);
			return;
		}

		// Setup the Request
		if ( lcswc_request != null ) { lcswc_request.abort(); }
		lcswc_request = new XMLHttpRequest();
		lcswc_request.open("GET", url);
		lcswc_request.overrideMimeType("text/xml");
		lcswc_request.onerror = function() { alert('Error'); };
		lcswc_request.onload = function() {

			// Bad HTTP Response
			if ( lcswc_request.status != 200 ) {
				alert('LCSWC BAD RESPONSE: ' + lcswc_request.status);
				callback(false);
				return;
			}

			// Empty Response
			if ( !lcswc_request.responseXML ) {
				alert('LCSWC EMPTY RESPONSE');
				callback(false);
				return;
			}

			// Parse and callback
			var bool = parse_feed(lcswc_request.responseXML);
			callback(bool);

		}

		// Send
		lcswc_request.send();

	}


	// -----------------------
	//     XML/DOM Parsing
	// -----------------------

	function parse_feed(feed) {
		var bool = false;
		var root = feed.documentElement;
		var entries = find_children(root, 'entry');
		for (var i=0; i<entries.length; i++) {
			var entry = entries[i];
			var title = get_child_data(entry, 'title');
			var id    = get_child_data(entry, 'id').replace(/^http:/, 'https');
			if ( !id.match(/\/$/) ) { id += '/'; }
			lcswc_data[title] = id;
			bool = true;
		}
		return bool;
	}

	function get_child_data(elem, nodeName) {
		for (var child = elem.firstChild; child != null; child = child.nextSibling) {
			if ( child.localName == nodeName ) {
				var data = '';
				for (var node = child.firstChild; node != null; node = node.nextSibling) {
					if ( node.data ) { data += node.data; }
				}
				return data;
			}
		}
		return null;
	}

	function find_children(elem, nodeName, namespace) {
		var arr = [];
		for (var child = elem.firstChild; child != null; child = child.nextSibling) {
			if (child.localName == nodeName) {
				if (namespace == null || child.namespaceURI == namespace)
					arr.push(child);
			}
		}
		return arr;
	}


	// -----------------------
	//    Public Functions
	// -----------------------

	return {
		exists : function() { return lcswc_cache.exists(LCSWC_CACHE_NAME); },
		pull   : function(callback) { pull_with_cached_url(callback); },
		get    : function(comp) { return get_component_data(comp); },
		set    : function(url, callback) { update_url(url, callback); }
	};

})();
