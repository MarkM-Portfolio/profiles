/*
  Lotus Connections Shared Widget Cache (LCSWC) for a Widget with Shell Access

  Author: Joseph Pecoraro
  Date: Wednesday July 9, 2008
  Requires: wc.js (Widget Cache)
  Description:

    Once one widget has made a connection to the Connections
    server, they should store the /serviceconfigs URL in a shared
    cache for "Pre-Determination" of servers for other widgets
    that are installed in the future.

  Technical Problems:
  -------------------

    1. The cache is stale/old

       This can be solved by storing a URL to the last known
       working /serviceconfigs URL.

    2. The /serviceconfigs URL does not work

       This would be the case where the cache has turned stale.
       I don't think its appropriate to delete the cached url,
       because it could just be that the server is temporarily
       down or that login information was incorrect.  So it is
       simply left alone, free to be tried again.

      
  States:
  -------

  These states are constants (defined below).  You should use the
  constants, and not their direct integer values.

    LCSWC_SUCCESS:

      A successful request.  All of the LCSWC datastructures
      will be set and ready to use.
  
    LCSWC_FAILURE:

      A failed XMLHttpRequest for any reason.
  
    LCSWC_NEED_LOGIN:
  
      The url provided appears to be secure (https) but no
      login information was provided.  Please provide login
      information.


  Notes of Interest:
  ------------------

  In-order to not cause any naming conflicts this script
  encapsulates everything within a "LCSWC" object.  This is common
  "object oriented" practice emulated in Javascript.


  How To Use:
  -----------

    1. Include the wc.js and lcswc.js files:

         <script type="text/javascript" src="wc.js"></script>
         <script type="text/javascript" src="lcswc.js"></script>

    2. If you need to grab the /serviceconfigs call:

         LCSWC.pull(login_string, callback)

       This attempts to use the cached URL.

       The first parameter "login_string" is required if the url
       is secure.  It is best to always pass in a login_string
       because it will be ignored if the url is not secure.

       The second parameter, "callback", is a callback function
       that is always invoked after the request to has returned.
       A return code integer is passed to the callback function.
       It will be one of the defined states (see above "States").

    3. If there is no cached URL the user should use:

         LCSWC.set(url, login_string, callback)

       This will test the given url just like above.  In the case of
       a successful request the url is cached automatically,
       replacing the existing cached url, and then call your callback
       function.  In the case of any non-successful request nothing
       is changed and the callback function is called.

       You can always check if a url is cached by calling:

         LCSWC.exists() - returns true if there is a cached url
         LCSWC.url() - returns the cached url, null if none

    4. On a successful pull (or set) get the component you want using:

         LCSWC.get(component)

       Known Components are:

         activities             blogs
         communities            dogear
         homepage               personTag
         profiles

*/

// -----------------------
//      Return Codes
// -----------------------
var LCSWC_SUCCESS    = 0;
var LCSWC_FAILURE    = 1;
var LCSWC_NEED_LOGIN = 2;

// Namespace
var LCSWC = (function() {


	// -----------------------
	//    Member Variables
	// -----------------------
	var LCSWC_CACHE_NAME = 'url';
	var lcswc_cache      = new WC('LotusConnectionsSharedCache');
	var lcswc_request    = null;
	var lcswc_data       = {};


	// -----------------------
	//    Private Functions
	// -----------------------

	function get_component_data(component) {
		return lcswc_data[component] == undefined ? null : lcswc_data[component];
	}

	function wipe_bad_cache_url() {
		lcswc_cache.wipe(LCSWC_CACHE_NAME);
	}

	function set_cache_url(url) {
		lcswc_cache.cache(LCSWC_CACHE_NAME, url);
	}

	function default_callback(state) {
		switch(state) {
		case LCSWC_SUCCESS:
			alert('LCSWC PULL SUCCEEDED');
			break;
		case LCSWC_FAILURE:
			alert('LCSWC PULL FAILED');
			break;
		case LCSWC_NEED_LOGIN:
			alert('LCSWC NEEDS LOGIN INFORMATION');
			break;
		default:
			alert('LCSWC UNKNOWN');
		}
	}


	// -----------------------
	//  Update the Cached URL
	// -----------------------

	function update_url(url, login_string, user_callback) {

		// Default callback and save the old URL
		if ( user_callback == null ) { user_callback = default_callback; }

		// Add /serviceconfigs if needed
		if ( url != null && !url.match(/\/serviceconfigs$/) ) {
			var str = 'serviceconfigs';
			url += (url.match(/\/$/)) ? str : '/' + str;
		}

		// Cache the above URL if successful
		pull_service_configs(url, login_string, function(state) {
			if (state === LCSWC_SUCCESS) {
				lcswc_cache.cache(LCSWC_CACHE_NAME, url);
			}
			user_callback(state);
		});

	}


	// -----------------------
	//      Make Request
	// -----------------------

	function pull_with_cached_url(login_string, callback) {

		// Use the cached URL
		var url = lcswc_cache.fetch(LCSWC_CACHE_NAME);

		// Default callback
		if ( callback == null ) { callback = default_callback; }

		/*
		Friday July 18, 2008
		Joe Change the spect to not wipe the cache url on a bad request
		due to secure server (username/password) requirements
		Wrap the callback to wipe the cache if it fails
		
		function wipe_callback(state) {
			if ( state === LCSWC_FAILURE ) {
				wipe_bad_cache_url();
			}
			callback(state);
		}
		*/
		

		// Call the advanced pull
		pull_service_configs(url, login_string, callback);

	}


	// -----------------------
	//    Advanced Request
	// -----------------------

	function pull_service_configs(url, login_string, callback) {
	
		// Debug
		//alert('LCSWC.pull trying url: ' + url);
		//alert('Login String: ' + login_string);
		//alert('Is this secure?: ' + is_secure(url));

		// Check params
		if ( callback == null ) { callback = default_callback; }
		if ( url === null ) {
			callback(LCSWC_FAILURE);
			return;
		}
		
		// Secure URL Requires a login string
		if ( login_string == null && is_secure(url) ) {
			callback(LCSWC_NEED_LOGIN);
			return;
		}

		// Setup the Request
		if ( lcswc_request != null ) { lcswc_request.abort(); }
		lcswc_request = new XMLHttpRequest();
		lcswc_request.open("GET", url);
		lcswc_request.overrideMimeType("text/xml");
		if ( is_secure(url) ) { lcswc_request.setRequestHeader("Authorization", 'Basic ' + login_string); }
		lcswc_request.onerror = function() { alert('Error'); };
		lcswc_request.onload = function() {

			// Bad HTTP Response
			if ( lcswc_request.status != 200 ) {
				alert('LCSWC BAD RESPONSE: ' + lcswc_request.status);
				callback(LCSWC_FAILURE);
				return;
			}

			// Empty Response
			if ( !lcswc_request.responseXML ) {
				alert('LCSWC EMPTY RESPONSE');
				callback(LCSWC_FAILURE);
				return;
			}

			// Parse and callback
			var bool = parse_feed(lcswc_request.responseXML);
			callback( bool ? LCSWC_SUCCESS : LCSWC_FAILURE );

		}

		// Send
		lcswc_request.send();

	}
	

	// -----------------------
	//     Util Functions
	// -----------------------
	
	function is_secure(url) {
		return !!(url.match(/^https/));
	}


	// -----------------------
	//     XML/DOM Parsing
	// -----------------------

	function parse_feed(feed) {
		var bool = false;
		var root = feed.documentElement;
		var entries = find_children(root, 'entry');
		for (var i=0; i<entries.length; i++) {
			var entry = entries[i];
			var title = get_child_data(entry, 'title');
			var id    = get_child_data(entry, 'id').replace(/^http:/, 'https');
			if ( !id.match(/\/$/) ) { id += '/'; }
			lcswc_data[title] = id;
			bool = true;
		}
		return bool;
	}

	function get_child_data(elem, nodeName) {
		for (var child = elem.firstChild; child != null; child = child.nextSibling) {
			if ( child.localName == nodeName ) {
				var data = '';
				for (var node = child.firstChild; node != null; node = node.nextSibling) {
					if ( node.data ) { data += node.data; }
				}
				return data;
			}
		}
		return null;
	}

	function find_children(elem, nodeName, namespace) {
		var arr = [];
		for (var child = elem.firstChild; child != null; child = child.nextSibling) {
			if (child.localName == nodeName) {
				if (namespace == null || child.namespaceURI == namespace)
					arr.push(child);
			}
		}
		return arr;
	}


	// -----------------------
	//    Public Functions
	// -----------------------

	return {
		exists : function() { return lcswc_cache.exists(LCSWC_CACHE_NAME); },
		url    : function() { return lcswc_cache.fetch(LCSWC_CACHE_NAME); },
		get    : function(comp) { return get_component_data(comp); },
		pull   : function(login_string, callback) { pull_with_cached_url(login_string, callback); },
		set    : function(url, login_string, callback) { update_url(url, login_string, callback); }
	};

})();
