/*
  Functions for resizing the widget
  Author: Joseph Pecoraro
  Date: Wednesday July 16, 2008
*/

// -----------------------
//        Globals
// -----------------------
var isOpen = false;
var isDialog = false;
var wasClosed = false; // for dialogs only
var gInfoButton, gDoneButton, gFrontButton;
var gFrontHeight, gFrontWidth;
var gSavedOpenWidth = 0;
var gSavedOpenHeight = 0;
var gBackWidth = 416;
var gBackHeight = 242;
var gMinWidth = 396;
var gMinHeight = 220;
var gClosedWidth = 360;
var gClosedHeight = 50;
var growboxInset;


// -----------------------
//     Slide Handler
// -----------------------


// This function handles everything that must happen
// during an animation to the innards of the widget
function slideRectHandler(animation, curr, start, end) {
	document.getElementById("middle").style.height = (curr.bottom-73)+'px';
	document.getElementById('bottom').style.top = (curr.bottom-30)+'px';
	window.resizeTo(curr.right, curr.bottom);
}


// -----------------------
//  Preferences Animation
// -----------------------

function resizeToPref() {
	
	// store the front height and width values to restore on return to front
	gFrontHeight = window.innerHeight;
	gFrontWidth = window.innerWidth;
	
	// Two AppleRect objects store the starting and finshing rectangle sizes
	var startingRect = new AppleRect (0, 0, window.innerWidth, window.innerHeight);
	var finishingRect = new AppleRect (0, 0, gBackWidth, gBackHeight);
	
	// The RectAnimation specifies the range of values and the handler to call at the animator's interval
	var currentRectAnimation = new AppleRectAnimation( startingRect, finishingRect, slideRectHandler );

	// The Animator is the timer for the animation
	var currentAnimator = new AppleAnimator (400, 12);
	
	// Associate the animator and animation
	currentAnimator.addAnimation(currentRectAnimation);
	
	// Set a handler to be called when the animation is done (in this case, flip the widget to its back)
	currentAnimator.oncomplete = flipToBack;
	
	// Once everything is set up, start the animation
	currentAnimator.start();
	
}

function flipToBack() {

	// Configure the back (always revert to hiding the server textfield)
	hideServerFields();

    var front = document.getElementById("front");
    var back = document.getElementById("back");
 
	if (window.widget) {
		widget.prepareForTransition("ToBack");
 	}
		
    front.style.display="none";
    back.style.display="block";
 
    if (window.widget){
        setTimeout ('widget.performTransition();', 0);
		widget.setCloseBoxOffset(13,14);
    }
	
	onBack = true;
}


function flipToFront() {

    var front = document.getElementById("front");
    var back = document.getElementById("back");
	
	if (window.widget) {
		widget.prepareForTransition("ToFront");
 	}

    back.style.display="none";
    front.style.display="block";
	
    if (window.widget) {
        setTimeout ('widget.performTransition();', 0);
		widget.setCloseBoxOffset(7,9);
	}
	
	// Once the flip to the front is complete, flipToFront resizes the widget back to its former size.
	setTimeout("resizeFromPref()", 750);
	
	// Update the front/back flag
	onBack = false;
    
    // Save all the items on the back ( non-volatile, even after restart )
    storePreferences();
	storeServerUrl();
	
	// Get the user information and eventually their colleague list
	getUserInfo( retrievePreference( 'username' ), ongetinfo );
    
    // Check if there's a username
    checkLoggedIntoAdium();
}


// Uses another AppleRectAnimation to resize the widget to its previous size
function resizeFromPref() {
	var startingRect = new AppleRect (0, 0, gBackWidth, gBackHeight);
	var finishingRect = new AppleRect (0, 0, gFrontWidth, gFrontHeight);
	var currentRectAnimation = new AppleRectAnimation( startingRect, finishingRect, slideRectHandler );
	var currentAnimator = new AppleAnimator (400, 12);
	currentAnimator.addAnimation(currentRectAnimation);
	currentAnimator.start();	
}

// -----------------------
//    Resize Functions
// -----------------------

 
function mouseDown(event) {
    document.addEventListener("mousemove", mouseMove, true);
    document.addEventListener("mouseup", mouseUp, true);
    growboxInset = {x:(window.innerWidth - event.x), y:(window.innerHeight - event.y)};
    event.stopPropagation();
    event.preventDefault();
}
 
function mouseMove(event) {

	if ( event.x == -1 ) return;
	var x = event.x + growboxInset.x;
    var y = event.y + growboxInset.y;
 
	// min width and height
	if(x < gMinWidth) x = gMinWidth;
	if(y < gMinHeight) y = gMinHeight;

	// resize
	// this is the important part that handles the widget's
	// innards while the user is resizing
	document.getElementById("middle").style.height = (y-73) + 'px'; // 43 = top, 30 = bottom
	document.getElementById("bottom").style.top = (y-30) + 'px'; // 30 = bottom
    window.resizeTo(x,y);
 
    event.stopPropagation();
    event.preventDefault();
}

function mouseUp(event) {
    document.removeEventListener("mousemove", mouseMove, true);
    document.removeEventListener("mouseup", mouseUp, true); 
    event.stopPropagation();
    event.preventDefault();
}


// -------------------------
//  Slide Up/Down Functions
// -------------------------

function showBottomElems() {
	document.getElementById('middle').style.display = 'block';
	document.getElementById('bottom').style.display = 'block';
	document.getElementById('resize').style.display = 'block';
	document.getElementById('top-right').style.backgroundPositionY = '-68px'
	document.getElementById('top-left').style.backgroundPositionY = '-71px'
	document.getElementById('top-middle').style.backgroundPositionY = '-57px'
}

function hideBottomElems() {
	document.getElementById('top-right').style.backgroundPositionY = '-6px'
	document.getElementById('top-left').style.backgroundPositionY = '-5px'
	document.getElementById('top-middle').style.backgroundPositionY = '0px'
	document.getElementById('middle').style.display = 'none';
	document.getElementById('bottom').style.display = 'none';
	document.getElementById('resize').style.display = 'none';
}

function showFrontElems() {
	document.getElementById('face').style.display = 'block';
	document.getElementById('chatIcon').style.display = 'block';
}

function hideFrontElems() {
	document.getElementById('face').style.display = 'none';
	document.getElementById('chatIcon').style.display = 'none';
}


//
// Function: saveWidthAndHeight
// Used to set the globals that "remember" the size of the widget
// before a resize in case it needs to be resized back later
//
function saveWidthAndHeight() {
	gSavedOpenWidth = window.innerWidth;
	gSavedOpenHeight = window.innerHeight;
}


//
// Function: isMinSize()
// For convenience many widget actions are immediate when it is in the min size
//
function isMinSize() {
  return (window.innerWidth == gMinWidth && window.innerHeight == gMinHeight) ? true : false;
}


//
// Function: triggerSlideDown
// Slides down and once complete it shows the front elements
//
function triggerSlideDown(event) {
	if ( !isOpen ) { window.resizeTo(gClosedWidth, gClosedHeight); }
	slideDown( function() {
		showFrontElems();
		isOpen = true;
	});
}


//
// Function: triggerSlideUp
// Slides up and once complete it hides the bottom elements
//
function triggerSlideUp(event) {
	slideUp( function() {
		hideBottomElems();
		isOpen = false;
	});
}

//
// Function: slideUp(callback)
// Shows the bottom elements and slides down
// NOTE: You should use triggerSlideDown()
//
function slideDown(completeCallback) {
	showBottomElems();
	genericSlide(Math.max(gMinWidth,gSavedOpenWidth), Math.max(gMinHeight,gSavedOpenHeight), completeCallback);
}


//
// Function: slideUp(callback)
// Hides the elements on the front and slides up
// NOTE: You should use triggerSlideUp()
//
function slideUp(completeCallback) {
	hideFrontElems();
	saveWidthAndHeight();
	genericSlide(gClosedWidth, gClosedHeight, completeCallback);
}


//
// Function: genericSlide(width, height, callback)
// This resizes (without bounds checking) from the current widget's size
// to the given width and height, calling the given callback once completed.
// NOTE: You must check your bounds if you want this to resize to the minSize
//
function genericSlide(w, h, completeCallback) {
	if (completeCallback == null) { completeCallback = function(){}; }
	var startingRect = new AppleRect (0, 0, window.innerWidth, window.innerHeight);
	var finishingRect = new AppleRect (0, 0, w, h);
	var currentRectAnimation = new AppleRectAnimation( startingRect, finishingRect, slideRectHandler );
	var currentAnimator = new AppleAnimator (300, 12);
	currentAnimator.addAnimation(currentRectAnimation);
	currentAnimator.oncomplete = completeCallback;
	currentAnimator.start();
}