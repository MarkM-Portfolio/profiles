// -----------------------
//      DOM Parsing
// -----------------------


//
// Function: findChild(element, nodeName, namespace)
// Scans the children of a given DOM element for a node matching nodeName, optionally in a given namespace.
//
// element: The DOM element to search.
// nodeName: The node name to search for.
// namespace: Optional namespace the node name must be in.
//
// Returns the child node if found, otherwise null.
//
function findChild(element, nodeName, namespace) {
    for (var child = element.firstChild; child != null; child = child.nextSibling) {
        if (child.localName == nodeName) {
            if (namespace == null || child.namespaceURI == namespace)
                return child;
        }
    }
    return null;
}

function findChildren(elem, nodeName, namespace) {
	var arr = [];
	for (var child = elem.firstChild; child != null; child = child.nextSibling) {
		if (child.localName == nodeName) {
			if (namespace == null || child.namespaceURI == namespace)
				arr.push(child);
		}
	}
	return arr;
}

function findChildrenLayered( elem, nodeName ) {
    var elements = [];
    for ( var child = elem.firstChild; child != null; child = child.nextSibling ) {
        if ( child.localName == nodeName ) {
            elements.push( child );
        }
        
        if ( child.hasChildNodes() ) {
            var grandChildren = child.childNodes;
            for ( var i = 0; i < grandChildren.length; i++ ) {
                elements = elements.concat( findChildrenLayered( grandChildren[i], nodeName ));
            }
        }
    }
    
    return elements;
}

//
// Function: atomTextToHTML(element)
// Extracts the content of an atom text construct as HTML for display
//
// element: an Atom element containing an atomTextConstruct per RFC4287
//
// Returns an HTML div Element node containing the HTML
//
function atomTextToHTML(element) {

    if (!element) {
        return;
    }

		var NS_XHTML	= "http://www.w3.org/1999/xhtml";
    var html;
    var type = element.getAttribute("type");
    if (type && (type.indexOf("xhtml") > -1)) {
        // The spec says there should be a DIV in the XHTML namespace
        var div = findChild(element, "div", NS_XHTML);
        if (div) {
            html = div.cloneNode(true);
        }
    } else if (type && (type.indexOf("html") > -1)) {
        // Encoded HTML
        html = document.createElement("div");
        html.innerHTML = allData(element);
    } else {
        // Plain text
        html = document.createElement("div");
        var elementText = allData(element);
        elementText = elementText.replace(/^\s+/, "");
        elementText = elementText.replace(/\s+$/, "");
        html.innerText = elementText;
    }

    return html;
}


//
// Function: allData(node)
// Concatenate all the text data of a node's children.
//
// node: DOM element to search for text.
//
// Returns the concatenated text.
//
function allData(node) {
    var data = "";
    if (node && node.firstChild) {
        node = node.firstChild;
        if (node.data) data += node.data;
        while (node = node.nextSibling) {
            if (node.data) data += node.data;
        }
    }
    return data;
}


// -----------------------
//     hCard Support
// -----------------------


//
// Function: parseHCard(hcard)
// The HCard should be the element containing the hcard,
// so in most cases it should be the <content> node
//
// NOTE: This uses the getElementsByClassName from yahoo-dom-event.js
//
//
function parseHCard(hcard) {

	// First element in a list or null
	function f(nodeList) {
		return nodeList ? nodeList[0] : null;
	}
	
	// Key, Email
	var node  = f( hcard.getElementsByClassName('x-profile-key') );
	var key   = node ? node.innerText : null;
	node      = f( hcard.getElementsByClassName('email') );
	var email = node ? node.innerText : null;
	
    // Return a card object
	return {
		key: key,
		email: email
	};

}


// -----------------------
//   String Manipulation
// -----------------------


//
// Function: quote(str)
// Takes a string returns it wrapped in single quotes with
// all the single quotes inside str escaped.
//
function quote(str) {
	return "'" + str.replace("'", "\\'") + "'";
}

function trim( stringValue ) {
    return stringValue.replace( /(^\s*|\s*$)/g, "");
}
