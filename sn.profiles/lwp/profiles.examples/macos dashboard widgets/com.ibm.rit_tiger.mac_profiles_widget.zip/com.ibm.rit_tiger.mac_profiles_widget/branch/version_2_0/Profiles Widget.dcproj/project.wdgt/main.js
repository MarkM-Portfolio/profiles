// New Globals
var WIDGET_VERSION  = 1.2;
var secure_server   = "https://profiles.tap.ibm.com/profiles/";

var SECURE_URL      = "https://profiles.tap.ibm.com/profiles";
var SERVER_URL      = 'http://profiles.tap.ibm.com/profiles';
var FEED_URL        = '/atom/search.do?email=';
var PROFILE_URL     = '/html/profileView.do?uid=';
var TYPEAHEAD_URL   = '/html/nameTypeahead.do?name=';
var FRIEND_URL      = '/atom/colleagues.do?ps=50&output=hcard&key=';
var FRIEND_REQ_URL  = '/xml/friendrequest';
var USER_URL        = '/atom/profile.do?output=hcard&email=';

var httpFeedRequest = null;
var defaultImg      = null;
var blogLink        = null;
var connLink		= null;
var resultsArray    = null;
var serverError		= null;
var noPerson		= false;

// Namespaces
var NS_IMAGE = "http://www.ibm.com/xmlns/prod/sn/image";


function buildRequest( url, keyword ) {
	var req = new XMLHttpRequest();
	req.overrideMimeType("text/xml");
	alert( url + keyword );
    req.open("GET", url + keyword);
	req.setRequestHeader("Cache-Control", "no-cache");
	return req;
}

//
// Function: refreshFeed()
// Starts loading the feed source.
// processFeedDocument() will be called when it finishes loading.
//
function makeRequest( searchEmail ) {
	searchEmail = trim( searchEmail );

    // Abort any pending request before starting a new one
    if (httpFeedRequest != null) {
        httpFeedRequest.abort();
        httpFeedRequest = null;
    }
	
	// Set the search bar
	document.getElementById("searchBar").value = searchEmail;
	
	// Recreate the XMLHttpRequest()
    httpFeedRequest = new XMLHttpRequest();
	
	// Generate the search URL
	var searchUrl = SERVER_URL + FEED_URL + searchEmail;

	// The XMLHttpRequest's onload
    httpFeedRequest.onload = function (xml) {

		// Not successful
		if ( httpFeedRequest.status != 200 ) {
			serverError = true;
			return;
		}

		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( httpFeedRequest.responseXML ) feedRootElement = httpFeedRequest.responseXML.documentElement;

		// Destory the XMLHttpRequest
		httpFeedRequest = null;
		
		// Process the Feed
		resultsArray = parseAtomFeed(feedRootElement);
		
		// Show in the GUI the first result
		if ( resultsArray.length > 0 && !serverError ) {
			setContent(resultsArray[0].name, resultsArray[0].content, resultsArray[0].imgUrl);
			
            //Found a person
            noPerson = false;
            document.getElementById("img").style.opacity = 100;
            
			//Show these icons
			document.getElementById("icon1").style.display = "inline";
			document.getElementById("icon2").style.display = "inline";
			document.getElementById("blogIcon").style.display = "inline";
            document.getElementById('buttonsBackground').style.display = 'inline';
			
			//Set the cursors
			document.getElementById("icon1").style.cursor = "pointer";
			document.getElementById("icon2").style.cursor = "pointer";
            
		} else {
        
            //Reset the icons
			setContent("No Person", "Sorry...", null );
            document.getElementById("img").style.opacity = 0;
			noPerson = true;
			
			//Hide these icons
			document.getElementById("icon1").style.display = "none";
			document.getElementById("icon2").style.display = "none";
			document.getElementById("blogIcon").style.display = "none";
            document.getElementById('buttonsBackground').style.display = 'none';
			
			//Reset the cursors
			document.getElementById("icon1").style.cursor = "default";
			document.getElementById("icon2").style.cursor = "default";
			document.getElementById("blogIcon").style.cursor = "default";
		}

    }
	
	// More setup for the AJAX Request
    httpFeedRequest.overrideMimeType("text/xml");
    httpFeedRequest.open("GET", searchUrl);
    httpFeedRequest.setRequestHeader("Cache-Control", "no-cache");
	
	// Show loading
	clearContent();
	
	// Send the request
    httpFeedRequest.send(null);
}

//
// Function: clearContent
// Hides the img, the content, and displays loading in the text 
//
function clearContent() {
	document.getElementById("text").innerHTML = "Loading...";
	document.getElementById("content").innerHTML = "";
	document.getElementById("img").style.opacity = 0;
	document.getElementById("icon1").style.opacity = 0;
	document.getElementById("icon2").style.opacity = 0;
	document.getElementById("blogIcon").style.opacity = 0;
    document.getElementById("blogIcon").style.cursor = 'default';
    document.getElementById('buttonsBackground').style.opacity = 0;
}

//
// Function: setContent
// Helper function to easily set the image and text
//
function setContent(name, content, imgUrl) {
	
	// Name
	document.getElementById("text").innerHTML = name;
	
	// Content
	// I assume spans[1] because spans[0] should be the "vcard" span
	// and anything that comes back with spans.length < 1 is ignored
	var contentElem = document.getElementById("content");
	contentElem.innerHTML = content;

	document.getElementById("blogIcon").onclick = function() { widget.openURL(blogLink); };
	
	// Image
	var img = document.getElementById("img");
	img.src = imgUrl;
	img.style.opacity = 100;
	
	// Icons
	if( !serverError ) {
        document.getElementById('buttonsBackground').style.opacity = 1;
		document.getElementById("icon1").style.opacity = 1;
		document.getElementById("icon2").style.opacity = 1;
		
		if( noPerson != null && blogLink != "#" ) {
			document.getElementById("blogIcon").style.opacity = 1;
            document.getElementById("blogIcon").style.cursor = "pointer";
		} else {
			document.getElementById("blogIcon").style.opacity = 0.4;
            document.getElementById("blogIcon").style.cursor = "default";
		}
	}
}

//
// Function: parseAtomFeed(atom)
// Parse an Atom feed.
//
// atom: Atom feed as an XML document.
//
// Returns the parsed results array.
//
function parseAtomFeed(atom) {
	// Put the results into a nice Object Array
	var results = new Array;

	// For each element, get title, link and publication date.
	// Note that all elements of an item are optional.
	for (var item = atom.firstChild; item != null; item = item.nextSibling) {
	
		if (item.nodeName == "entry") {

			// Get the Name
			var name = atomTextToHTML(findChild(item, "title"));
			name = name.innerHTML;
			if (!name) {
				name = "No Name?";
			}
            
            // Special Easter Egg Check
            if ( name.match(/steve willard/i) ) {
                name = "Steve Willard";
            } else if ( name.match(/joseph j. pecoraro/i) ) {
                name = "Joseph Pecoraro";
            }

			// Get the content
			var content = atomTextToHTML(findChild(item, "content"));

			// Check to see if the work phone is empty
			var tel = content.getElementsByClassName('tel')[0];
			if (!tel.children[1].innerHTML.match(/\d/)) { 
				tel.style.display = 'none';
			} else {
				content.getElementsByClassName('tel')[0].firstChild.innerHTML = "Phone: ";
			}
					
			// Setup the blog link (which for some reason must be set later)
			var blogUrls = content.getElementsByClassName('x-blog-url');
			if ( blogUrls && blogUrls.length > 0 ) {
				blogLink = blogUrls[0].href;
			} else {
				blogLink = "#";
				document.getElementById("blogIcon").style.display = "none";
				document.getElementById("blogIcon").style.cursor = "default";
			}
			
			// Set the content here
			content = content.innerHTML;

            // Get the image url and connLink
            var imgUrl = defaultImg;
            var allLinks = findChildren(item, "link");
            for (var i = 0; i < allLinks.length; i++) {
                var rel = allLinks[i].getAttribute("rel");
                if (rel == NS_IMAGE) {
                    imgUrl = allLinks[i].getAttribute("href");
                    break;
                } else if ( rel == "related" ) {
                    connLink = allLinks[i].getAttribute("href")
                }
            }
            
			// Get the key from the connLink
            var key = getUrlValue(connLink, 'key');

			// Add to the results array
			results.push({
				name: name,
				content: content,
				imgUrl: imgUrl,
				key: key
			});
			
			// ---------------------------
			//   Remove this break if
			//   you want all results
			//   and not just the first.
			// ---------------------------
			break;

		}
		
	}
	
	return results;
}

// Function for the address book icon
function addToAddressBook() {

	// First/Last Name
	var names = resultsArray[0].name.split(/\s+/);
	var firstName = names[0];
	var lastName = "";
	if ( names.length > 1 ) {
		lastName = names[names.length-1];
	}
	
	// Phone Number, Job Title, Email
	var tel = document.getElementsByClassName("tel")[0].children[1].innerHTML;
    var jobTitle = document.getElementsByClassName("role")[0].innerHTML;
    var email = document.getElementsByClassName("email")[0].innerHTML;
    var imgUrl = resultsArray[0].imgUrl;

	// Execute
	// usage: AddressBook.scpt first last phone organization jobTitle email addr
	var execStr = "/usr/bin/osascript AddressBook.scpt " +
		quote(firstName) + " " + quote(lastName) + " " +
		quote(tel) + " " + quote("IBM") + " " +
		quote(jobTitle) + " " + quote(email) + " " + quote(imgUrl);
	widget.system(execStr, null);
}

// Function for the LC icon
function goToProfile() {
	widget.openURL(connLink); 
}

function ongetinfo() {
	getFriendsList(user.key);
}


//
// Function: load()
// Called by HTML body element's onload event when the widget is ready to start
//
function load() {
    dashcode.setupParts();
	
	// -----
	// TODO: This function should be called when the user
	//       sets their username on the back.
	//       Its Hardcoded for testing.
	// -----
    getUserInfo('jjpecora@us.ibm.com', ongetinfo);
}

//
// Function: remove()
// Called when the widget has been removed from the Dashboard
//
function remove() { }

//
// Function: hide()
// Called when the widget has been hidden
//
function hide() {}

//
// Function: show()
// Called when the widget has been shown
//
function show() {
	if ( document.getElementById('glassbutton') ) {
		document.getElementById('glassbutton').childNodes[0].childNodes[1].innerHTML = 'Check for Update';
	}
}

//
// Function: sync()
// Called when the widget has been synchronized with .Mac
//
function sync() {}

//
// Function: showBack(event)
// Called when the info button is clicked to show the back of the widget
//
// event: onClick event from the info button
//
function showBack(event) {
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget)
        widget.prepareForTransition("ToBack");

    front.style.display="none";
    back.style.display="block";

    if (window.widget)
        setTimeout("widget.performTransition();", 0);
}

//
// Function: showFront(event)
// Called when the done button is clicked from the back of the widget
//
// event: onClick event from the done button
//
function showFront(event) {
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget)
        widget.prepareForTransition("ToFront");

    front.style.display = "block";
    back.style.display = "none";

    if (window.widget)
        setTimeout("widget.performTransition();", 0);

}

// Initialize the Dashboard event handlers
if (window.widget) {
    widget.onremove = remove;
    widget.onhide = hide;
    widget.onshow = show;
    widget.onsync = sync;
}


function goToSearchBar(event) {
    document.getElementById('searchBar').focus();
    document.getElementById('searchBar').select();
}

function checkForUpdate(event) {
    wau_check_for_update(
		function(a) { document.getElementById('glassbutton').childNodes[0].childNodes[1].innerHTML = 'Update Downloaded'; wau_def_new_update_callback(a) },
		function()  { document.getElementById('glassbutton').childNodes[0].childNodes[1].innerHTML = 'This Is The Latest'; },
		function()  { document.getElementById('glassbutton').childNodes[0].childNodes[1].innerHTML = 'Error, Try Later';   }
	);
}

function addToColleague(event) {
	if ( resultsArray && resultsArray[0] ) {
		var person = resultsArray[0];
		if ( person.key ) {
			sendFriendRequest(person.key, 'Default Message: Wanna be my colleague?!');
		}
	}
}

function openContactAdium(event) {
    var execStr = "/usr/bin/osascript adium.scpt " +
        quote('swillar@us.ibm.com') + " " + quote(document.getElementById('searchBar').value) + " ";
        alert (execStr );
	widget.system(execStr, null);
}


function testScrpt(event)
{
    widget.system( "/usr/bin/osascript testscrpt.scpt", null );
}
