/*
  Functions for parsing URL parameters
  Author: Joseph Pecoraro
  Date: Monday June 30, 2008
*/


//
// Function: parseUrlParams(url)
// This returns a hash of the params in key/value pairs.
// Note: I strip #anchors and I split on the '=' char
// because it must be encoded based on the URL RFC #1738
//
function parseUrlParams(url) {
	var hash = {};
	var regex = /[?&]/;
	url = url.replace(/#.*$/, '').replace(/\+/g, ' ');
	var arr = url.split(regex).splice(1);
	arr.forEach( function(pair) {
		var p = pair.split(/=/);
		hash[ decodeURIComponent(p[0]) ] = decodeURIComponent(p[1]);
	});
	return hash;
}


//
// Function getUrlValue(url, key)
// Returns the decoded url parameter value if found,
// null otherwise.  This should only be used if a single
// key is needed, otherwise use parseUrlParams to perform
// the parsing only a single time.
//
// Note: key should be encoded if you know the key will
// be encoded in the url.  This function does not encode
// or decode the given key.
//
// Very similiar to: lobo235's public domain script
// http://www.netlobo.com/url_query_string_javascript.html
//
function getUrlValue(url, key) {
	var regex_str = '[?&]' + key + '=([^&#]*)';
	var regex = new RegExp(regex_str);
	var results = regex.exec(url.replace(/\+/g, ' '));
	return results ? decodeURIComponent(results[1]) : null;
}
