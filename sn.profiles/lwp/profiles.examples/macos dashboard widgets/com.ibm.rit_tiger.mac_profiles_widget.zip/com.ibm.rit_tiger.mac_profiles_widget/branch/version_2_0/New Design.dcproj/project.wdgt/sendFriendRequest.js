/*
  Code to get information about the current user
  Author: Joseph Pecoraro
  Date: Tuesday July 1, 2008
*/

// -----------------------
//    Member Variables
// -----------------------

// Atom Constants
NAMESPACE_SNX = "http://www.ibm.com/xmlns/prod/sn";
NAMESPACE_OPENSEARCH = "http://a9.com/-/spec/opensearch/1.1/";

// Globals
var friendList = [];
var pendingList = [];
var req_friendList = null;
var req_addColleague = null;


// -----------------------
//    Util Functions
// -----------------------


//
// Function: searchListForObjectWithAttrVal(lst, attr, val)
// Scans an object array for an object with the given
// attribute/value pair
// NOTE: utility function
//
function searchListForObjectWithAttrVal(lst, attr, val) {
	if (lst && attr) {
		for (var i=0; i<lst.length; i++) {
			if (lst[i][attr] == val) {
				return lst[i];
			}
		}
	}
	return null;
}


// -----------------------
//       Niceties
// -----------------------
function getFriendByKey(k)   { return searchListForObjectWithAttrVal(friendList, 'key'  , k); }
function getFriendByEmail(e) { return searchListForObjectWithAttrVal(friendList, 'email', e); }


// -----------------------
//    Public Functions
// -----------------------


//
// Function: sendFriendRequest(personKey, msg)
// Sends a friend request!
//
// Example:
// http://profiles.tap.ibm.com/profiles/xml/friendrequest?targetKey=1434116d-d6da-4885-943e-f067a362228f&lastMod=1214836547851&msg=I%27d%20like%20to%20add%20you%20to%20my%20Connections%20colleagues%20list.
// http://profiles.tap.ibm.com/profiles/xml/friendrequest?targetKey=1434116d-d6da-4885-943e-f067a362228f&lastMod=1214836547851&msg=I%27d%20like
//
function sendFriendRequest(personKey, msg) {

	alert(personKey);
	
	// Make sure this person isn't already in your friend list
	if ( getFriendByKey(personKey) != null ) {
		alert('Whoa... This person is already your friend!');
		return;
	}
	
	// Default message
	if ( msg == null ) {
		msg = 'Invite from the widget!';
	}

	// URL for a friend request
	var url = SECURE_URL + FRIEND_REQUEST_URL;
	url += "?targetKey=" + personKey;
	url += "&lastMod=" + (new Date()).getTime();
	url += "&msg=" + encodeURIComponent(msg);
	alert(url);
	
	
	// Abort any pending request before starting a new one
	if (req_addColleague != null) {
		req_addColleague.abort();
		req_addColleague = null;
	}
	
    
    
	// Send the XMLHttpRequest
	req_addColleague = new XMLHttpRequest();
	req_addColleague.overrideMimeType("text/xml");
	req_addColleague.open("POST", url);
    
	var loginString = Base64.encode( getAuthString() );
	req_addColleague.setRequestHeader("Authorization", 'Basic ' + loginString);
	req_addColleague.setRequestHeader("Cache-Control", "no-cache");
	req_addColleague.onload = function(xml) {
	
		alert( req_addColleague.status );
		alert( req_addColleague.responseText );
		
		// Bad
		// Change this to the correct number!
		if ( req_addColleague.status < 200 || req_addColleague.status > 201 ) {
			alert('BAD REQUEST');
			return;
		}
		
		// Already invited response
		if ( req_addColleague.responseText.match(/\s*<error\s*code\s*=\s*.connection-exist.\s*\/>/) ) {
			alert('Already invited... Sorry, we couldn\'t tell!');
		}
		
		/*
		if ( req_addColleague.documentElement.nodeName == "error" &&
			req_addColleague.documentElement.getAttribute("code") == "connection-exist" ) {
			alert('Already invited... Sorry, we couldn\'t tell!');
		}
		*/
		
		// Complete
		else {
			alert('yippy');
		}
		
	}
	
	// Send
	req_addColleague.send(null);

};


//
// Function: getFriendsList()
// Gets the list of friends and populates friendList for the
// user identified by the give key.
//
// Example:
// http://profiles.tap.ibm.com/profiles/atom/colleagues.do?key=31929063-6e8a-419f-a0da-84fcdd0e6421&output=hcard&ps=50
//
function getFriendsList(userKey) {

	// Start by clearing the old list (always... in case the key is bad)
	friendList = [];
	
	// Bad key, quick return
	if ( userKey == null ) {
		alert('Key was null, not fetching friend list');
		return;
	}
	
	// Abort any pending request before starting a new one
	if (req_friendList != null) {
		req_friendList.abort();
		req_friendList = null;
	}
	
	// URL for a friend request
	var url = SERVER_URL + FRIEND_URL + userKey;

	// Recreate the XMLHttpRequest()
	req_friendList = new XMLHttpRequest();
	req_friendList.overrideMimeType("text/xml");
	req_friendList.open("GET", url);
	req_friendList.setRequestHeader("Cache-Control", "no-cache");
	req_friendList.onload = function(xml) {
    
		alert('FRIEND LIST RESPONSE: ' + req_friendList.status);

		// Bad Request
		if ( req_friendList.responseXML == null || req_friendList.status != 200) {
			alert('erroring out!');
			return;
		}
        
		// Get the root element (should be <feed> for an Atom Feed)
		var feedRootElement = null;
		if ( req_friendList.responseXML ) {
			feedRootElement = req_friendList.responseXML.documentElement;
		}
		
		// There is pagination, so send out as many requests as needed
		// This part is untested.
		/*
		var node = findChild(feedRootElement, 'totalResults', NAMESPACE_OPENSEARCH);
		var total = node ? parseFloat(allData(node)) : 0;
		node = findChild(feedRootElement, 'itemsPerPage', NAMESPACE_OPENSEARCH);
		var perpage = node ? parseFloat(allData(node)) : 1;
		var needed  = Math.floor(total / perpage); // floor, we got 1 already so we can round down!
		for (var i=1; i<=needed; i++) {
			// getFriendsListPage(friendFeed, i);
		}
		*/

		// Parse Friend Feed [page 0]
		parseFriendFeed(feedRootElement);

	}
    
	// Send
	req_friendList.send();

};


// -----------------------
//   Private Functions
// -----------------------


//
// Function: parseFriendFeed(feed)
// Parses out friends and adds them to the friendList
//
// <atom:feed snx:total-friends="1" snx:current-page="0">
//   ...
//   <atom:entry snx:key="..." snx:email="...">
//     <atom:title />
//     <atom:id />
//     <atom:link />
//   </atom:entry>
//   ...
// </atom:feed>
//
function parseFriendFeed(feed) {
	for (var item = feed.firstChild; item != null; item = item.nextSibling) {
		if (item.nodeName == "entry") {
			var content = findChild(item, 'content');
			if ( content ) {
				var card = parseHCard(content);
				friendList.push(card);
			}
		}
	}
}
